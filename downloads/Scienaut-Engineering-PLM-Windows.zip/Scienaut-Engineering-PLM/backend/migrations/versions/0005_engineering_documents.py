"""Add local engineering document attachments."""
from alembic import op
import sqlalchemy as sa

revision = "0005_engineering_documents"
down_revision = "0004_change_notices"
branch_labels = None
depends_on = None


def upgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    if "engineering_documents" not in tables:
        op.create_table(
            "engineering_documents",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("item_id", sa.String(36), sa.ForeignKey("items.id", ondelete="CASCADE"), nullable=False),
            sa.Column("revision_id", sa.String(36), sa.ForeignKey("item_revisions.id", ondelete="SET NULL")),
            sa.Column("original_name", sa.String(255), nullable=False),
            sa.Column("stored_name", sa.String(80), nullable=False, unique=True),
            sa.Column("media_type", sa.String(120), nullable=False, server_default="application/octet-stream"),
            sa.Column("size_bytes", sa.Integer(), nullable=False),
            sa.Column("data_bytes", sa.LargeBinary(), nullable=False),
            sa.Column("sha256", sa.String(64), nullable=False),
            sa.Column("description", sa.Text()),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.CheckConstraint("size_bytes >= 0"),
        )
        op.create_index("ix_engineering_documents_item_created", "engineering_documents", ["item_id", "created_at"])


def downgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    if "engineering_documents" in tables:
        op.drop_table("engineering_documents")
