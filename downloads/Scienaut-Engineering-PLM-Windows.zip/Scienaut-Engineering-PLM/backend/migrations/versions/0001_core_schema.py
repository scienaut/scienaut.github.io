"""Core item, revision, and assembly occurrence schema."""
from alembic import op
import sqlalchemy as sa

revision = "0001_core_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    connection = op.get_bind()
    existing = set(sa.inspect(connection).get_table_names())
    core_tables = {"scope_categories", "manufacturing_processes", "items", "item_revisions", "assembly_occurrences"}
    if existing & core_tables:
        if not core_tables.issubset(existing):
            raise RuntimeError("Found a partial PLM schema; refusing to overwrite or guess at existing data.")
        required_columns = {
            "scope_categories": {"id", "name", "active"},
            "manufacturing_processes": {"id", "name", "parent_id", "active"},
            "items": {"id", "item_number", "name", "item_type", "category", "owner", "created_at", "modified_at"},
            "item_revisions": {"id", "item_id", "revision_code", "iteration", "state", "description", "change_reason", "previous_revision_id", "scope_category_id", "manufacturing_process_id", "material_designation", "mass", "mass_source", "unit_cost", "uom", "remarks", "created_at", "released_at"},
            "assembly_occurrences": {"id", "parent_revision_id", "child_item_id", "child_revision_id", "bom_type", "find_number", "quantity", "uom", "sort_order", "effectivity_start", "effectivity_end", "remarks"},
        }
        for table, expected in required_columns.items():
            actual = {column["name"] for column in sa.inspect(connection).get_columns(table)}
            if not expected.issubset(actual):
                raise RuntimeError(f"Existing table {table} does not match the PLM schema; no data was changed.")
        _install_guards()
        _ensure_indexes(connection)
        return

    op.create_table("scope_categories",
        sa.Column("id", sa.String(36), primary_key=True), sa.Column("name", sa.String(100), nullable=False, unique=True),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()))
    op.create_table("manufacturing_processes",
        sa.Column("id", sa.String(36), primary_key=True), sa.Column("name", sa.String(120), nullable=False, unique=True),
        sa.Column("parent_id", sa.String(36), sa.ForeignKey("manufacturing_processes.id")),
        sa.Column("active", sa.Boolean(), nullable=False, server_default=sa.true()))
    op.create_table("items",
        sa.Column("id", sa.String(36), primary_key=True), sa.Column("item_number", sa.String(80), nullable=False, unique=True),
        sa.Column("name", sa.String(200), nullable=False), sa.Column("item_type", sa.String(40), nullable=False),
        sa.Column("category", sa.String(100)), sa.Column("owner", sa.String(120)),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("modified_at", sa.DateTime(timezone=True), nullable=False),
        sa.CheckConstraint("length(item_number) > 0"),
        sa.CheckConstraint("item_type IN ('MAIN PRODUCT','MAIN ASSEMBLY','SUB ASSEMBLY','CHILD ASSEMBLY','PART','STANDARD COMPONENT','FASTENER','BOUGHT-OUT COMPONENT')"))
    op.create_index("ix_items_type", "items", ["item_type"])
    op.create_table("item_revisions",
        sa.Column("id", sa.String(36), primary_key=True), sa.Column("item_id", sa.String(36), sa.ForeignKey("items.id", ondelete="CASCADE"), nullable=False),
        sa.Column("revision_code", sa.String(20), nullable=False), sa.Column("iteration", sa.Integer(), nullable=False),
        sa.Column("state", sa.String(20), nullable=False), sa.Column("description", sa.Text()), sa.Column("change_reason", sa.Text()),
        sa.Column("previous_revision_id", sa.String(36), sa.ForeignKey("item_revisions.id")),
        sa.Column("scope_category_id", sa.String(36), sa.ForeignKey("scope_categories.id")),
        sa.Column("manufacturing_process_id", sa.String(36), sa.ForeignKey("manufacturing_processes.id")),
        sa.Column("material_designation", sa.String(160)), sa.Column("mass", sa.Float()), sa.Column("mass_source", sa.String(30)),
        sa.Column("unit_cost", sa.Float()), sa.Column("uom", sa.String(20), nullable=False), sa.Column("remarks", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False), sa.Column("released_at", sa.DateTime(timezone=True)),
        sa.UniqueConstraint("item_id", "revision_code", "iteration", name="uq_item_revision_iteration"),
        sa.CheckConstraint("iteration > 0"), sa.CheckConstraint("mass IS NULL OR mass >= 0"),
        sa.CheckConstraint("unit_cost IS NULL OR unit_cost >= 0"),
        sa.CheckConstraint("state IN ('IN WORK','RELEASED','OBSOLETE')"))
    op.create_index("ix_item_revisions_item_state", "item_revisions", ["item_id", "state"])
    op.create_table("assembly_occurrences",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("parent_revision_id", sa.String(36), sa.ForeignKey("item_revisions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("child_item_id", sa.String(36), sa.ForeignKey("items.id"), nullable=False),
        sa.Column("child_revision_id", sa.String(36), sa.ForeignKey("item_revisions.id")),
        sa.Column("bom_type", sa.String(20), nullable=False), sa.Column("find_number", sa.String(40), nullable=False),
        sa.Column("quantity", sa.Float(), nullable=False), sa.Column("uom", sa.String(20), nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=False), sa.Column("effectivity_start", sa.DateTime(timezone=True)),
        sa.Column("effectivity_end", sa.DateTime(timezone=True)), sa.Column("remarks", sa.Text()),
        sa.UniqueConstraint("parent_revision_id", "find_number", name="uq_occurrence_find_number"),
        sa.CheckConstraint("quantity > 0"),
        sa.CheckConstraint("bom_type IN ('EBOM','MBOM','PROCUREMENT','SERVICE')"))
    op.create_index("ix_occurrences_parent_order", "assembly_occurrences", ["parent_revision_id", "sort_order"])
    op.create_index("ix_occurrences_child_item", "assembly_occurrences", ["child_item_id"])
    _install_guards()


def _ensure_indexes(connection):
    indexes = {
        "items": {index["name"] for index in sa.inspect(connection).get_indexes("items")},
        "item_revisions": {index["name"] for index in sa.inspect(connection).get_indexes("item_revisions")},
        "assembly_occurrences": {index["name"] for index in sa.inspect(connection).get_indexes("assembly_occurrences")},
    }
    for table, name, columns in (
        ("items", "ix_items_type", ["item_type"]),
        ("item_revisions", "ix_item_revisions_item_state", ["item_id", "state"]),
        ("assembly_occurrences", "ix_occurrences_parent_order", ["parent_revision_id", "sort_order"]),
        ("assembly_occurrences", "ix_occurrences_child_item", ["child_item_id"]),
    ):
        if name not in indexes[table]:
            op.create_index(name, table, columns)


def _install_guards():
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_released_revision_immutable_update BEFORE UPDATE ON item_revisions
        WHEN OLD.state = 'RELEASED' BEGIN SELECT RAISE(ABORT, 'released revisions are immutable'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_released_revision_immutable_delete BEFORE DELETE ON item_revisions
        WHEN OLD.state = 'RELEASED' BEGIN SELECT RAISE(ABORT, 'released revisions are immutable'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_released_occurrences_immutable_insert BEFORE INSERT ON assembly_occurrences
        WHEN (SELECT state FROM item_revisions WHERE id = NEW.parent_revision_id) = 'RELEASED'
        BEGIN SELECT RAISE(ABORT, 'released assembly structure is immutable'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_released_occurrences_immutable_update BEFORE UPDATE ON assembly_occurrences
        WHEN (SELECT state FROM item_revisions WHERE id = OLD.parent_revision_id) = 'RELEASED'
        BEGIN SELECT RAISE(ABORT, 'released assembly structure is immutable'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_released_occurrences_immutable_delete BEFORE DELETE ON assembly_occurrences
        WHEN (SELECT state FROM item_revisions WHERE id = OLD.parent_revision_id) = 'RELEASED'
        BEGIN SELECT RAISE(ABORT, 'released assembly structure is immutable'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_occurrence_child_revision_match_insert BEFORE INSERT ON assembly_occurrences
        WHEN NEW.child_revision_id IS NOT NULL AND
        (SELECT item_id FROM item_revisions WHERE id = NEW.child_revision_id) != NEW.child_item_id
        BEGIN SELECT RAISE(ABORT, 'child revision does not belong to child item'); END""")
    op.execute("""CREATE TRIGGER IF NOT EXISTS trg_occurrence_child_revision_match_update BEFORE UPDATE ON assembly_occurrences
        WHEN NEW.child_revision_id IS NOT NULL AND
        (SELECT item_id FROM item_revisions WHERE id = NEW.child_revision_id) != NEW.child_item_id
        BEGIN SELECT RAISE(ABORT, 'child revision does not belong to child item'); END""")


def downgrade():
    op.execute("DROP TRIGGER IF EXISTS trg_occurrence_child_revision_match_update")
    op.execute("DROP TRIGGER IF EXISTS trg_occurrence_child_revision_match_insert")
    op.execute("DROP TRIGGER IF EXISTS trg_released_occurrences_immutable_delete")
    op.execute("DROP TRIGGER IF EXISTS trg_released_occurrences_immutable_update")
    op.execute("DROP TRIGGER IF EXISTS trg_released_occurrences_immutable_insert")
    op.execute("DROP TRIGGER IF EXISTS trg_released_revision_immutable_delete")
    op.execute("DROP TRIGGER IF EXISTS trg_released_revision_immutable_update")
    op.drop_table("assembly_occurrences")
    op.drop_index("ix_item_revisions_item_state", table_name="item_revisions")
    op.drop_table("item_revisions")
    op.drop_index("ix_items_type", table_name="items")
    op.drop_table("items")
    op.drop_table("manufacturing_processes")
    op.drop_table("scope_categories")
