"""Add controlled engineering change notices."""
from alembic import op
import sqlalchemy as sa

revision = "0004_change_notices"
down_revision = "0003_audit_events"
branch_labels = None
depends_on = None


def upgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    if "change_notices" not in tables:
        op.create_table(
            "change_notices",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("ecn_number", sa.String(40), nullable=False),
            sa.Column("title", sa.String(200), nullable=False),
            sa.Column("reason", sa.Text(), nullable=False),
            sa.Column("status", sa.String(20), nullable=False, server_default="DRAFT"),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
            sa.Column("modified_at", sa.DateTime(timezone=True), nullable=False),
            sa.UniqueConstraint("ecn_number", name="uq_change_notice_number"),
        )
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    if "change_notice_items" not in tables:
        op.create_table(
            "change_notice_items",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("notice_id", sa.String(36), sa.ForeignKey("change_notices.id", ondelete="CASCADE"), nullable=False),
            sa.Column("item_id", sa.String(36), sa.ForeignKey("items.id"), nullable=False),
            sa.Column("baseline_revision_id", sa.String(36), sa.ForeignKey("item_revisions.id")),
            sa.Column("change_description", sa.Text(), nullable=False),
            sa.UniqueConstraint("notice_id", "item_id", name="uq_notice_affected_item"),
        )


def downgrade():
    tables = set(sa.inspect(op.get_bind()).get_table_names())
    if "change_notice_items" in tables:
        op.drop_table("change_notice_items")
    if "change_notices" in tables:
        op.drop_table("change_notices")
