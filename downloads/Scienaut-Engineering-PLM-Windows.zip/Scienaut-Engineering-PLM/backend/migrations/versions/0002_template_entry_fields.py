"""Add editable engineering management register fields."""
from alembic import op
import sqlalchemy as sa

revision = "0002_template_entry_fields"
down_revision = "0001_core_schema"
branch_labels = None
depends_on = None


def upgrade():
    connection = op.get_bind()
    item_revision_columns = {column["name"] for column in sa.inspect(connection).get_columns("item_revisions")}
    occurrence_columns = {column["name"] for column in sa.inspect(connection).get_columns("assembly_occurrences")}
    for column, kind in (
        ("manufacturing_methods", sa.String(160)),
        ("proprietary_classification", sa.String(80)),
        ("pdm_release_level", sa.String(80)),
        ("cad_release_status", sa.String(80)),
        ("manufacturer_part_number", sa.String(120)),
        ("purchase_reference_url", sa.String(500)),
        ("ecn_reference", sa.String(120)),
        ("supplier_name", sa.String(160)),
        ("lead_time", sa.String(60)),
    ):
        if column not in item_revision_columns:
            op.add_column("item_revisions", sa.Column(column, kind, nullable=True))
    if "system_name" not in occurrence_columns:
        op.add_column("assembly_occurrences", sa.Column("system_name", sa.String(120), nullable=True))
    if "coe_names" not in occurrence_columns:
        op.add_column("assembly_occurrences", sa.Column("coe_names", sa.String(160), nullable=True))


def downgrade():
    connection = op.get_bind()
    occurrence_columns = {column["name"] for column in sa.inspect(connection).get_columns("assembly_occurrences")}
    if "coe_names" in occurrence_columns:
        op.drop_column("assembly_occurrences", "coe_names")
    if "system_name" in occurrence_columns:
        op.drop_column("assembly_occurrences", "system_name")
    item_revision_columns = {column["name"] for column in sa.inspect(connection).get_columns("item_revisions")}
    for column in (
        "lead_time", "supplier_name", "ecn_reference", "purchase_reference_url",
        "manufacturer_part_number", "cad_release_status", "pdm_release_level",
        "proprietary_classification", "manufacturing_methods",
    ):
        if column in item_revision_columns:
            op.drop_column("item_revisions", column)
