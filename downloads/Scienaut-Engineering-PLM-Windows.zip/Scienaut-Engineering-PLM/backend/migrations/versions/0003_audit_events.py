"""Add durable local change history."""
from alembic import op
import sqlalchemy as sa

revision = "0003_audit_events"
down_revision = "0002_template_entry_fields"
branch_labels = None
depends_on = None


def upgrade():
    if "audit_events" not in sa.inspect(op.get_bind()).get_table_names():
        op.create_table(
            "audit_events",
            sa.Column("id", sa.String(36), primary_key=True),
            sa.Column("item_id", sa.String(36)),
            sa.Column("item_number", sa.String(80)),
            sa.Column("item_name", sa.String(200)),
            sa.Column("revision_id", sa.String(36)),
            sa.Column("revision_code", sa.String(20)),
            sa.Column("entity_type", sa.String(40), nullable=False),
            sa.Column("entity_id", sa.String(36), nullable=False),
            sa.Column("action", sa.String(40), nullable=False),
            sa.Column("field_name", sa.String(80)),
            sa.Column("old_value", sa.Text()),
            sa.Column("new_value", sa.Text()),
            sa.Column("summary", sa.Text(), nullable=False),
            sa.Column("actor", sa.String(120), nullable=False, server_default="Local user"),
            sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        )
    indexes = {row["name"] for row in sa.inspect(op.get_bind()).get_indexes("audit_events")}
    if "ix_audit_events_item_created" not in indexes:
        op.create_index("ix_audit_events_item_created", "audit_events", ["item_id", "created_at"])


def downgrade():
    if "audit_events" in sa.inspect(op.get_bind()).get_table_names():
        op.drop_index("ix_audit_events_item_created", table_name="audit_events")
        op.drop_table("audit_events")
