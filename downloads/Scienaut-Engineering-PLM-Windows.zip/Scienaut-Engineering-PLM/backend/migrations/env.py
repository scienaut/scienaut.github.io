from logging.config import fileConfig
import os
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

from app.core.config import database_url
from app.db import Base
from app import models  # noqa: F401

config = context.config
if os.environ.get("ENGINEERING_PLM_DATABASE_URL"):
    migration_url = os.environ["ENGINEERING_PLM_DATABASE_URL"]
elif os.environ.get("ENGINEERING_PLM_DATA_ROOT"):
    migration_url = database_url()
else:
    migration_url = config.get_main_option("sqlalchemy.url")
# ConfigParser treats percent signs in URL-escaped Windows paths as interpolation.
config.set_main_option("sqlalchemy.url", migration_url.replace("%", "%%"))
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
target_metadata = Base.metadata


def run_migrations_offline():
    context.configure(url=config.get_main_option("sqlalchemy.url"), target_metadata=target_metadata,
                      literal_binds=True, dialect_opts={"paramstyle": "named"},
                      compare_type=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    connectable = engine_from_config(config.get_section(config.config_ini_section), prefix="sqlalchemy.",
                                     poolclass=pool.NullPool)
    with connectable.connect() as connection:
        if connection.dialect.name == "sqlite":
            connection.exec_driver_sql("PRAGMA foreign_keys=ON")
            # SQLAlchemy 2 autobegins on PRAGMA; clear it so Alembic's own
            # transaction can commit DDL and version updates on SQLite.
            connection.commit()
        context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
