from __future__ import annotations

from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from sqlalchemy.orm import Session

from app.models import ItemRevision
from app.services import DomainError, hierarchy


HEADERS = [
    "Sr. No.", "System", "COE's", *[f"Level {level}" for level in range(1, 10)],
    "Part Number", "Revision#", "Part Name", "Quantity per Product",
    "Scope", "MATERIAL",
    "Proprietary (Part/Assy), STD part, Software, Miscellaneous (Consumables)",
    "Manufacturing Methods", "PDM Release Level", "Release/CAD Level Status",
    "Price Rs.", "MPN For BuyOut Items", "Purchase Link for Ref.", "CAD MASS [KG]",
    "Price Rs.", "ECN No With Revision", "Remarks", "Supplier Name",
    "Lead Time for Purchase",
]
LEVEL_COLOURS = ["D8A8BC", "FFE071", "80D19D", "15E3DF", "B7CEE8", "D5C2E7", "F5C8A8", "B8DDD8", "E5D8A9"]


def _safe_text(value) -> str:
    if value is None:
        return ""
    result = str(value)
    return "'" + result if result.startswith(("=", "+", "@")) else result


def build_engineering_management_workbook(session: Session, revision_id: str, title: str) -> BytesIO:
    tree = hierarchy(session, revision_id)
    root_revision = session.get(ItemRevision, revision_id)
    if not root_revision:
        raise DomainError("Revision not found")

    depth = _depth(tree)
    level_count = max(9, depth)
    headers = [HEADERS[0], HEADERS[1], HEADERS[2], *[f"Level {level}" for level in range(1, level_count + 1)], *HEADERS[12:]]
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Engineering BOM"
    last_column = len(headers)
    last_letter = get_column_letter(last_column)

    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_column)
    heading = sheet.cell(1, 1, _safe_text(title.strip() or "Retearn Engineering Management"))
    heading.font = Font(name="Arial", size=15, bold=True, color="FFFFFF")
    heading.fill = PatternFill("solid", fgColor="24364B")
    heading.alignment = Alignment(horizontal="left", vertical="center", indent=1)
    sheet.row_dimensions[1].height = 30

    metadata = [
        (("CREATED BY", ""), ("VENDOR", ""), ("BOM NUMBER", f"{tree['item']['item_number']}-EBOM-{tree['revision']}"), ("PAGE", "")),
        (("DATE", ""), ("MECHANICAL TEAM", ""), ("DOC. REV", ""), ("MATERIALS", "")),
        (("REV DATE", ""), ("TEAM MEMBERS", ""), ("RELEASE LEVEL", ""), ("PRODUCT", tree["item"]["name"])),
    ]
    meta_groups = [(1, 3, 4, 8), (9, 11, 12, 16), (17, 19, 20, 24), (25, 26, 27, last_column)]
    for row_idx, entries in enumerate(metadata, start=2):
        sheet.row_dimensions[row_idx].height = 22
        for (label, value), (label_start, label_end, value_start, value_end) in zip(entries, meta_groups):
            sheet.merge_cells(start_row=row_idx, start_column=label_start, end_row=row_idx, end_column=label_end)
            sheet.merge_cells(start_row=row_idx, start_column=value_start, end_row=row_idx, end_column=value_end)
            label_cell = sheet.cell(row_idx, label_start, label)
            value_cell = sheet.cell(row_idx, value_start, _safe_text(value))
            label_cell.font = Font(name="Arial", size=8, bold=True, color="435269")
            value_cell.font = Font(name="Arial", size=9, color="172333")
            label_cell.fill = PatternFill("solid", fgColor="EDF1F5")
            value_cell.fill = PatternFill("solid", fgColor="FFFFFF")
            label_cell.alignment = Alignment(vertical="center", wrap_text=True)
            value_cell.alignment = Alignment(vertical="center", wrap_text=True)
            for col in range(label_start, value_end + 1):
                sheet.cell(row_idx, col).border = Border(bottom=Side(style="thin", color="8290A1"))

    header_row = 6
    sheet.merge_cells(start_row=5, start_column=1, end_row=5, end_column=last_column)
    filter_hint = sheet.cell(5, 1, "Filter the header row below to focus the engineering register")
    filter_hint.font = Font(name="Arial", size=8, italic=True, color="53667D")
    filter_hint.alignment = Alignment(vertical="center")
    sheet.row_dimensions[5].height = 17
    for col, value in enumerate(headers, start=1):
        cell = sheet.cell(header_row, col, _safe_text(value))
        cell.font = Font(name="Arial", size=9, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="3D526C")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(bottom=Side(style="medium", color="172333"), right=Side(style="thin", color="BCC5D0"))
    sheet.row_dimensions[header_row].height = 42

    rows: list[tuple[dict, int, str, float]] = []

    def walk(node: dict, level: int, system_name: str, multiplier: float) -> None:
        current_system = system_name
        if level == 2:
            current_system = node["item"]["name"]
        if node.get("system_name"):
            current_system = node["system_name"]
        rows.append((node, level, current_system, multiplier))
        for child in node["children"]:
            walk(child, level + 1, current_system, multiplier * child["quantity"])

    walk(tree, 1, "", 1.0)
    for serial, (node, level, system_name, multiplier) in enumerate(rows):
        excel_row = header_row + serial + 1
        item = node["item"]
        revision = session.get(ItemRevision, node["revision_id"]) if node.get("revision_id") else None
        item_type = item["item_type"]
        if item_type in {"MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY"}:
            property_type = "Assy"
        elif item_type == "FASTENER" or item_type == "STANDARD COMPONENT":
            property_type = "STD part"
        elif item_type == "BOUGHT-OUT COMPONENT":
            property_type = "Child Part"
        else:
            property_type = "Part" if level <= 2 else "Child Part"

        cad_mass = ""
        unit_cost = None
        manufacturing_methods = ""
        scope = ""
        material = ""
        proprietary = ""
        pdm_level = node.get("state") or ""
        cad_status = ""
        mpn = ""
        purchase_reference = ""
        ecn_reference = ""
        supplier = ""
        lead_time = ""
        remarks = ""
        owner = ""
        if revision:
            cad_mass = revision.mass if revision.mass is not None and (revision.mass_source or "").upper().replace("-", "_") == "CAD_DERIVED" else ""
            unit_cost = revision.unit_cost
            manufacturing = revision.manufacturing_process.name if revision.manufacturing_process else ""
            manufacturing_methods = revision.manufacturing_methods or manufacturing
            scope = revision.scope_category.name if revision.scope_category else ""
            material = revision.material_designation or ""
            proprietary = revision.proprietary_classification or property_type
            pdm_level = revision.pdm_release_level or revision.state
            cad_status = revision.cad_release_status or ""
            mpn = revision.manufacturer_part_number or ""
            purchase_reference = revision.purchase_reference_url or ""
            ecn_reference = revision.ecn_reference or ""
            supplier = revision.supplier_name or ""
            lead_time = revision.lead_time or ""
            remarks = revision.remarks or ""
            owner = revision.item.owner or ""

        values = [serial, system_name, owner]
        level_cells = [""] * level_count
        level_cells[level - 1] = level
        values.extend(level_cells)
        values.extend([
            item["item_number"], node["revision"] or "", item["name"], multiplier,
            scope, material, proprietary, manufacturing_methods,
            pdm_level, cad_status, unit_cost if unit_cost is not None else "",
            mpn, purchase_reference, cad_mass, (unit_cost * multiplier) if unit_cost is not None else "",
            ecn_reference, remarks, supplier, lead_time,
        ])
        for col, value in enumerate(values, start=1):
            cell = sheet.cell(excel_row, col, _safe_text(value) if isinstance(value, str) else value)
            cell.font = Font(name="Arial", size=9, bold=(col == 1), color="172333")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = Border(bottom=Side(style="thin", color="9AA5B3"), right=Side(style="thin", color="C6CDD6"))
            cell.fill = PatternFill("solid", fgColor=LEVEL_COLOURS[(level - 1) % len(LEVEL_COLOURS)])
        for col in (16, 23, 25, 26):
            if col <= last_column:
                sheet.cell(excel_row, col).number_format = "0.###"
        sheet.row_dimensions[excel_row].height = 22

    final_row = header_row + len(rows)
    sheet.auto_filter.ref = f"A{header_row}:{last_letter}{final_row}"
    sheet.freeze_panes = "M7"
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.pageSetUpPr.fitToPage = True
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.paperSize = sheet.PAPERSIZE_A3
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.print_title_rows = f"1:{header_row}"
    sheet.print_area = f"A1:{last_letter}{final_row}"
    sheet.oddFooter.center.text = "Page &[Page] of &[Pages]"
    sheet.oddFooter.right.text = tree["item"]["item_number"]

    widths = {1: 9, 2: 22, 3: 22}
    for level_col in range(4, 4 + level_count):
        widths[level_col] = 5
    data_start = 4 + level_count
    tail_widths = [23, 11, 34, 16, 22, 24, 15, 34, 22, 18, 19, 18, 25, 26, 14, 16, 21, 30, 22, 21]
    for index, width in enumerate(tail_widths, start=data_start):
        widths[index] = width
    for col in range(1, last_column + 1):
        sheet.column_dimensions[get_column_letter(col)].width = widths.get(col, 16)

    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


def _depth(node: dict) -> int:
    return 1 + max(( _depth(child) for child in node["children"]), default=0)
