from __future__ import annotations

import hashlib
import re
from pathlib import Path
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import EngineeringDocument, Item, ItemRevision
from app.services import record_audit

MAX_DOCUMENT_BYTES = 100 * 1024 * 1024
ALLOWED_EXTENSIONS = {
    ".pdf", ".xlsx", ".xls", ".csv", ".docx", ".doc", ".txt", ".rtf",
    ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".step", ".stp",
    ".iges", ".igs", ".dxf", ".dwg", ".stl", ".3mf", ".zip",
}


class DocumentError(ValueError):
    pass


def _metadata(document: EngineeringDocument) -> dict:
    return {
        "id": document.id,
        "item_id": document.item_id,
        "revision_id": document.revision_id,
        "original_name": document.original_name,
        "media_type": document.media_type,
        "size_bytes": document.size_bytes,
        "sha256": document.sha256,
        "description": document.description,
        "created_at": document.created_at.isoformat(),
        "revision_code": document.revision.revision_code if document.revision else None,
    }


def list_documents(session: Session, item_id: str) -> list[dict]:
    if not session.get(Item, item_id):
        raise DocumentError("Item not found")
    documents = session.scalars(
        select(EngineeringDocument)
        .where(EngineeringDocument.item_id == item_id)
        .order_by(EngineeringDocument.created_at.desc(), EngineeringDocument.id)
    ).all()
    return [_metadata(document) for document in documents]


def save_document(session: Session, item_id: str, filename: str, content: bytes, media_type: str,
                  description: str | None = None, revision_id: str | None = None) -> dict:
    item = session.get(Item, item_id)
    if not item:
        raise DocumentError("Item not found")
    if not content:
        raise DocumentError("The selected file is empty")
    if len(content) > MAX_DOCUMENT_BYTES:
        raise DocumentError("Files must be 100 MB or smaller")
    safe_name = Path(filename.replace("\\", "/")).name.strip()
    if not safe_name or safe_name in {".", ".."} or len(safe_name) > 255:
        raise DocumentError("Enter a valid file name up to 255 characters")
    if Path(safe_name).suffix.lower() not in ALLOWED_EXTENSIONS:
        raise DocumentError("This file type is not supported for engineering attachments")
    if revision_id:
        revision = session.get(ItemRevision, revision_id)
        if not revision or revision.item_id != item_id:
            raise DocumentError("Selected revision does not belong to this item")
    if description and len(description) > 1000:
        raise DocumentError("Description must be 1000 characters or fewer")

    suffix = Path(safe_name).suffix.lower()
    stored_name = f"{uuid4().hex}{suffix}"
    document = EngineeringDocument(
        item_id=item_id, revision_id=revision_id, original_name=safe_name,
        stored_name=stored_name, media_type=(media_type or "application/octet-stream")[:120],
        size_bytes=len(content), data_bytes=content, sha256=hashlib.sha256(content).hexdigest(),
        description=description.strip() if description and description.strip() else None,
    )
    try:
        session.add(document)
        session.flush()
        record_audit(session, entity_type="DOCUMENT", entity_id=document.id, action="ATTACHED",
                     summary=f"Attached {safe_name} to {item.item_number}", item=item,
                     revision=session.get(ItemRevision, revision_id) if revision_id else None)
        session.commit()
    except Exception:
        session.rollback()
        raise
    return _metadata(document)


def get_document_file(session: Session, document_id: str):
    document = session.get(EngineeringDocument, document_id)
    if not document:
        raise DocumentError("Document not found")
    if not re.fullmatch(r"[0-9a-f]{32}\.[a-z0-9]{1,12}", document.stored_name):
        raise DocumentError("Stored document reference is invalid")
    if len(document.data_bytes) != document.size_bytes or hashlib.sha256(document.data_bytes).hexdigest() != document.sha256:
        raise DocumentError("Stored document failed its size or checksum validation")
    return document.data_bytes, document.original_name, document.media_type


def delete_document(session: Session, document_id: str) -> None:
    document = session.get(EngineeringDocument, document_id)
    if not document:
        raise DocumentError("Document not found")
    name = document.original_name
    item = document.item
    revision = document.revision
    record_audit(session, entity_type="DOCUMENT", entity_id=document.id, action="DELETED",
                 summary=f"Removed attachment {name} from {item.item_number}", item=item, revision=revision)
    session.delete(document)
    session.commit()
