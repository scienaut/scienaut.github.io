from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from uuid import uuid4

from sqlalchemy import (Boolean, CheckConstraint, DateTime, Float, ForeignKey, Index, LargeBinary,
                        Integer, String, Text, UniqueConstraint, func)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


def uuid_string() -> str:
    return str(uuid4())


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ItemType(StrEnum):
    MAIN_PRODUCT = "MAIN PRODUCT"
    MAIN_ASSEMBLY = "MAIN ASSEMBLY"
    SUB_ASSEMBLY = "SUB ASSEMBLY"
    CHILD_ASSEMBLY = "CHILD ASSEMBLY"
    PART = "PART"
    STANDARD_COMPONENT = "STANDARD COMPONENT"
    FASTENER = "FASTENER"
    BOUGHT_OUT_COMPONENT = "BOUGHT-OUT COMPONENT"


class RevisionState(StrEnum):
    IN_WORK = "IN WORK"
    RELEASED = "RELEASED"
    OBSOLETE = "OBSOLETE"


class BomType(StrEnum):
    EBOM = "EBOM"
    MBOM = "MBOM"
    PROCUREMENT = "PROCUREMENT"
    SERVICE = "SERVICE"


class ScopeCategory(Base):
    __tablename__ = "scope_categories"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)


class ManufacturingProcess(Base):
    __tablename__ = "manufacturing_processes"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    parent_id: Mapped[str | None] = mapped_column(ForeignKey("manufacturing_processes.id"))
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    parent: Mapped[ManufacturingProcess | None] = relationship(remote_side="ManufacturingProcess.id")


class Item(Base):
    __tablename__ = "items"
    __table_args__ = (
        CheckConstraint("length(item_number) > 0"),
        CheckConstraint("item_type IN ('MAIN PRODUCT','MAIN ASSEMBLY','SUB ASSEMBLY','CHILD ASSEMBLY','PART','STANDARD COMPONENT','FASTENER','BOUGHT-OUT COMPONENT')"),
        Index("ix_items_type", "item_type"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    item_number: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    item_type: Mapped[str] = mapped_column(String(40), nullable=False)
    category: Mapped[str | None] = mapped_column(String(100))
    owner: Mapped[str | None] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now)
    modified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now, onupdate=utc_now)
    revisions: Mapped[list[ItemRevision]] = relationship(back_populates="item", cascade="all, delete-orphan", order_by="ItemRevision.created_at")
    documents: Mapped[list[EngineeringDocument]] = relationship(back_populates="item", cascade="all, delete-orphan")


class ItemRevision(Base):
    __tablename__ = "item_revisions"
    __table_args__ = (
        UniqueConstraint("item_id", "revision_code", "iteration", name="uq_item_revision_iteration"),
        CheckConstraint("iteration > 0"),
        CheckConstraint("mass IS NULL OR mass >= 0"),
        CheckConstraint("unit_cost IS NULL OR unit_cost >= 0"),
        CheckConstraint("state IN ('IN WORK','RELEASED','OBSOLETE')"),
        Index("ix_item_revisions_item_state", "item_id", "state"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id", ondelete="CASCADE"), nullable=False)
    revision_code: Mapped[str] = mapped_column(String(20), nullable=False)
    iteration: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    state: Mapped[str] = mapped_column(String(20), nullable=False, default=RevisionState.IN_WORK.value)
    description: Mapped[str | None] = mapped_column(Text)
    change_reason: Mapped[str | None] = mapped_column(Text)
    previous_revision_id: Mapped[str | None] = mapped_column(ForeignKey("item_revisions.id"))
    scope_category_id: Mapped[str | None] = mapped_column(ForeignKey("scope_categories.id"))
    manufacturing_process_id: Mapped[str | None] = mapped_column(ForeignKey("manufacturing_processes.id"))
    manufacturing_methods: Mapped[str | None] = mapped_column(String(160))
    proprietary_classification: Mapped[str | None] = mapped_column(String(80))
    pdm_release_level: Mapped[str | None] = mapped_column(String(80))
    cad_release_status: Mapped[str | None] = mapped_column(String(80))
    material_designation: Mapped[str | None] = mapped_column(String(160))
    mass: Mapped[float | None] = mapped_column(Float)
    mass_source: Mapped[str | None] = mapped_column(String(30))
    unit_cost: Mapped[float | None] = mapped_column(Float)
    manufacturer_part_number: Mapped[str | None] = mapped_column(String(120))
    purchase_reference_url: Mapped[str | None] = mapped_column(String(500))
    ecn_reference: Mapped[str | None] = mapped_column(String(120))
    supplier_name: Mapped[str | None] = mapped_column(String(160))
    lead_time: Mapped[str | None] = mapped_column(String(60))
    uom: Mapped[str] = mapped_column(String(20), nullable=False, default="EA")
    remarks: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now)
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    item: Mapped[Item] = relationship(back_populates="revisions")
    previous_revision: Mapped[ItemRevision | None] = relationship(remote_side="ItemRevision.id", foreign_keys=[previous_revision_id])
    scope_category: Mapped[ScopeCategory | None] = relationship()
    manufacturing_process: Mapped[ManufacturingProcess | None] = relationship()


class AssemblyOccurrence(Base):
    __tablename__ = "assembly_occurrences"
    __table_args__ = (
        UniqueConstraint("parent_revision_id", "find_number", name="uq_occurrence_find_number"),
        CheckConstraint("quantity > 0"),
        CheckConstraint("bom_type IN ('EBOM','MBOM','PROCUREMENT','SERVICE')"),
        Index("ix_occurrences_parent_order", "parent_revision_id", "sort_order"),
        Index("ix_occurrences_child_item", "child_item_id"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    parent_revision_id: Mapped[str] = mapped_column(ForeignKey("item_revisions.id", ondelete="CASCADE"), nullable=False)
    child_item_id: Mapped[str] = mapped_column(ForeignKey("items.id"), nullable=False)
    child_revision_id: Mapped[str | None] = mapped_column(ForeignKey("item_revisions.id"))
    bom_type: Mapped[str] = mapped_column(String(20), nullable=False, default=BomType.EBOM.value)
    find_number: Mapped[str] = mapped_column(String(40), nullable=False)
    system_name: Mapped[str | None] = mapped_column(String(120))
    quantity: Mapped[float] = mapped_column(Float, nullable=False)
    uom: Mapped[str] = mapped_column(String(20), nullable=False, default="EA")
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    effectivity_start: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    effectivity_end: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    coe_names: Mapped[str | None] = mapped_column(String(160))
    remarks: Mapped[str | None] = mapped_column(Text)
    parent_revision: Mapped[ItemRevision] = relationship(foreign_keys=[parent_revision_id], backref="occurrences")
    child_item: Mapped[Item] = relationship(foreign_keys=[child_item_id])
    child_revision: Mapped[ItemRevision | None] = relationship(foreign_keys=[child_revision_id])


class AuditEvent(Base):
    __tablename__ = "audit_events"
    __table_args__ = (Index("ix_audit_events_item_created", "item_id", "created_at"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    item_id: Mapped[str | None] = mapped_column(String(36))
    item_number: Mapped[str | None] = mapped_column(String(80))
    item_name: Mapped[str | None] = mapped_column(String(200))
    revision_id: Mapped[str | None] = mapped_column(String(36))
    revision_code: Mapped[str | None] = mapped_column(String(20))
    entity_type: Mapped[str] = mapped_column(String(40), nullable=False)
    entity_id: Mapped[str] = mapped_column(String(36), nullable=False)
    action: Mapped[str] = mapped_column(String(40), nullable=False)
    field_name: Mapped[str | None] = mapped_column(String(80))
    old_value: Mapped[str | None] = mapped_column(Text)
    new_value: Mapped[str | None] = mapped_column(Text)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    actor: Mapped[str] = mapped_column(String(120), nullable=False, default="Local user")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now)


class ChangeNotice(Base):
    __tablename__ = "change_notices"
    __table_args__ = (UniqueConstraint("ecn_number", name="uq_change_notice_number"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    ecn_number: Mapped[str] = mapped_column(String(40), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="DRAFT")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now)
    modified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now, onupdate=utc_now)
    affected_items: Mapped[list[ChangeNoticeItem]] = relationship(back_populates="notice", cascade="all, delete-orphan")


class ChangeNoticeItem(Base):
    __tablename__ = "change_notice_items"
    __table_args__ = (UniqueConstraint("notice_id", "item_id", name="uq_notice_affected_item"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    notice_id: Mapped[str] = mapped_column(ForeignKey("change_notices.id", ondelete="CASCADE"), nullable=False)
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id"), nullable=False)
    baseline_revision_id: Mapped[str | None] = mapped_column(ForeignKey("item_revisions.id"))
    change_description: Mapped[str] = mapped_column(Text, nullable=False)
    notice: Mapped[ChangeNotice] = relationship(back_populates="affected_items")
    item: Mapped[Item] = relationship()
    baseline_revision: Mapped[ItemRevision | None] = relationship()


class EngineeringDocument(Base):
    __tablename__ = "engineering_documents"
    __table_args__ = (
        Index("ix_engineering_documents_item_created", "item_id", "created_at"),
        CheckConstraint("size_bytes >= 0"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=uuid_string)
    item_id: Mapped[str] = mapped_column(ForeignKey("items.id", ondelete="CASCADE"), nullable=False)
    revision_id: Mapped[str | None] = mapped_column(ForeignKey("item_revisions.id", ondelete="SET NULL"))
    original_name: Mapped[str] = mapped_column(String(255), nullable=False)
    stored_name: Mapped[str] = mapped_column(String(80), nullable=False, unique=True)
    media_type: Mapped[str] = mapped_column(String(120), nullable=False, default="application/octet-stream")
    size_bytes: Mapped[int] = mapped_column(Integer, nullable=False)
    data_bytes: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    sha256: Mapped[str] = mapped_column(String(64), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=utc_now)
    item: Mapped[Item] = relationship(back_populates="documents")
    revision: Mapped[ItemRevision | None] = relationship()

