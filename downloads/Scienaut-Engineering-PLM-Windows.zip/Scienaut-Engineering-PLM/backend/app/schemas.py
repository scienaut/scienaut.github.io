from pydantic import BaseModel, ConfigDict, Field


class ItemCreate(BaseModel):
    item_number: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    item_type: str
    revision_code: str = "A"
    description: str | None = None
    scope: str | None = None
    manufacturing_process: str | None = None
    mass: float | None = Field(default=None, ge=0)
    mass_source: str | None = None
    unit_cost: float | None = Field(default=None, ge=0)
    uom: str = "EA"


class ItemPatch(BaseModel):
    item_number: str = Field(min_length=1, max_length=80)


class OccurrenceCreate(BaseModel):
    parent_revision_id: str
    child_item_id: str
    child_revision_id: str | None = None
    find_number: str
    quantity: float = Field(gt=0)
    uom: str = "EA"
    bom_type: str = "EBOM"
    sort_order: int = 0
    remarks: str | None = None
    system_name: str | None = None
    coe_names: str | None = None


class OccurrencePatch(BaseModel):
    quantity: float | None = Field(default=None, gt=0)
    find_number: str | None = Field(default=None, min_length=1, max_length=40)
    remarks: str | None = None
    system_name: str | None = None
    coe_names: str | None = None


class OccurrenceMove(BaseModel):
    parent_revision_id: str = Field(min_length=1)


class BomImportRow(BaseModel):
    source_row: int = Field(ge=1)
    level: int = Field(ge=2, le=99)
    find_number: str | None = Field(default=None, max_length=40)
    item_number: str = Field(min_length=1, max_length=80)
    name: str = Field(min_length=1, max_length=200)
    revision_code: str | None = Field(default=None, max_length=20)
    item_type: str | None = Field(default=None, max_length=40)
    classification: str | None = Field(default=None, max_length=80)
    quantity: float = Field(gt=0)
    uom: str = Field(default="EA", min_length=1, max_length=20)
    system_name: str | None = Field(default=None, max_length=120)
    coe_names: str | None = Field(default=None, max_length=160)
    scope: str | None = Field(default=None, max_length=100)
    material_designation: str | None = Field(default=None, max_length=160)
    manufacturing_methods: str | None = Field(default=None, max_length=160)
    pdm_release_level: str | None = Field(default=None, max_length=80)
    cad_release_status: str | None = Field(default=None, max_length=80)
    unit_cost: float | None = Field(default=None, ge=0)
    manufacturer_part_number: str | None = Field(default=None, max_length=120)
    purchase_reference_url: str | None = Field(default=None, max_length=500)
    mass: float | None = Field(default=None, ge=0)
    ecn_reference: str | None = Field(default=None, max_length=120)
    remarks: str | None = None
    supplier_name: str | None = Field(default=None, max_length=160)
    lead_time: str | None = Field(default=None, max_length=60)


class BomImportRequest(BaseModel):
    root_revision_id: str = Field(min_length=1)
    rows: list[BomImportRow] = Field(min_length=1, max_length=10000)


class ChangeNoticeItemCreate(BaseModel):
    item_id: str = Field(min_length=1)
    change_description: str = Field(min_length=1, max_length=2000)


class ChangeNoticeCreate(BaseModel):
    ecn_number: str = Field(min_length=1, max_length=40)
    title: str = Field(min_length=1, max_length=200)
    reason: str = Field(min_length=1, max_length=5000)
    affected_items: list[ChangeNoticeItemCreate] = Field(min_length=1, max_length=500)


class ChangeNoticeTransition(BaseModel):
    status: str = Field(min_length=1, max_length=20)


class ItemRevisionPatch(BaseModel):
    scope: str | None = None
    manufacturing_process: str | None = None
    manufacturing_methods: str | None = Field(default=None, max_length=160)
    proprietary_classification: str | None = Field(default=None, max_length=80)
    pdm_release_level: str | None = Field(default=None, max_length=80)
    cad_release_status: str | None = Field(default=None, max_length=80)
    material_designation: str | None = Field(default=None, max_length=160)
    mass: float | None = Field(default=None, ge=0)
    mass_source: str | None = Field(default=None, max_length=30)
    unit_cost: float | None = Field(default=None, ge=0)
    manufacturer_part_number: str | None = Field(default=None, max_length=120)
    purchase_reference_url: str | None = Field(default=None, max_length=500)
    ecn_reference: str | None = Field(default=None, max_length=120)
    supplier_name: str | None = Field(default=None, max_length=160)
    lead_time: str | None = Field(default=None, max_length=60)
    remarks: str | None = None


class ItemRevisionCreate(BaseModel):
    revision_code: str = Field(min_length=1, max_length=20)
    description: str | None = Field(default=None, max_length=2000)
    change_reason: str | None = Field(default=None, max_length=2000)


class ItemOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    item_number: str
    name: str
    item_type: str

