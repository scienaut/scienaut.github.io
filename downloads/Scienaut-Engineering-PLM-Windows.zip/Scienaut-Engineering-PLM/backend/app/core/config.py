from __future__ import annotations

import os
from pathlib import Path


def data_root() -> Path:
    """Return configurable local data root, defaulting beside backend source."""
    configured = os.environ.get("ENGINEERING_PLM_DATA_ROOT")
    root = Path(configured).expanduser() if configured else Path(__file__).resolve().parents[3] / "local_data"
    return root.resolve()


def database_url() -> str:
    configured_url = os.environ.get("ENGINEERING_PLM_DATABASE_URL")
    if configured_url:
        return configured_url
    db_file = data_root() / "Database" / "engineering_plm.sqlite3"
    db_file.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{db_file.as_posix()}"
