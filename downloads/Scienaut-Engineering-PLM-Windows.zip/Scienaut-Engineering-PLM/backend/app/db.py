from __future__ import annotations

from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.core.config import database_url


class Base(DeclarativeBase):
    pass


def make_engine(url: str | None = None):
    target = url or database_url()
    kwargs = {"check_same_thread": False} if target.startswith("sqlite") else {}
    engine = create_engine(target, future=True, connect_args=kwargs)
    if target.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def enable_foreign_keys(dbapi_connection, _connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    return engine


engine = make_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def get_session():
    with SessionLocal() as session:
        yield session
