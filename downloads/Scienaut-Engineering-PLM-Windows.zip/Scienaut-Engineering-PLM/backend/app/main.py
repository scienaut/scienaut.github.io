from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.responses import Response, StreamingResponse
from urllib.parse import quote
from pathlib import Path
from alembic import command as alembic_command
from alembic.config import Config as AlembicConfig
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.backups import BackupError, create_backup, list_backups, restore_backup
from app.db import engine, get_session
from app.documents import (MAX_DOCUMENT_BYTES, DocumentError, delete_document,
                           get_document_file, list_documents, save_document)
from app.exports import build_engineering_management_workbook
from app.models import Item, ItemRevision
from app.schemas import (BomImportRequest, ChangeNoticeCreate, ChangeNoticeTransition,
                         ItemCreate, ItemPatch, ItemRevisionCreate, ItemRevisionPatch, OccurrenceCreate,
                         OccurrenceMove, OccurrencePatch)
from app.services import (DomainError, add_occurrence, change_occurrence, create_item,
                          delete_product_workspace, hierarchy, multilevel_bom, remove_occurrence,
                          audit_history, compare_revisions, create_change_notice,
                          import_bom_rows, list_change_notices, move_occurrence,
                          reusable_proprietary_classifications,
                          transition_change_notice, update_item_number, create_working_revision,
                          release_revision,
                          update_revision_data, used_system_names, where_used)

app = FastAPI(title="Scienaut Engineering PLM Solutions Local API", version="0.1.0", docs_url="/api/v1/docs")


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "storage": "local"}


@app.get("/api/v1/items")
def list_items(search: str | None = Query(default=None), session: Session = Depends(get_session)):
    query = select(Item).order_by(Item.item_number)
    if search:
        pattern = f"%{search.strip()}%"
        query = query.where(Item.item_number.ilike(pattern) | Item.name.ilike(pattern))
    rows = session.scalars(query).all()
    result = []
    for item in rows:
        revisions = session.scalars(select(ItemRevision).where(ItemRevision.item_id == item.id)
                                    .order_by(ItemRevision.created_at.desc())).all()
        result.append({"id": item.id, "item_number": item.item_number, "name": item.name,
                       "item_type": item.item_type,
                       "revisions": [{"id": rev.id, "revision_code": rev.revision_code,
                                      "iteration": rev.iteration, "state": rev.state}
                                     for rev in revisions]})
    return result


@app.get("/api/v1/options/proprietary-classifications")
def list_reusable_proprietary_classifications(session: Session = Depends(get_session)):
    return reusable_proprietary_classifications(session)


@app.get("/api/v1/options/system-names")
def list_used_system_names(session: Session = Depends(get_session)):
    return used_system_names(session)


@app.get("/api/v1/audit")
def get_audit_history(item_id: str | None = None, limit: int = Query(default=200, ge=1, le=500),
                      session: Session = Depends(get_session)):
    return audit_history(session, item_id, limit)


@app.get("/api/v1/change-notices")
def get_change_notices(session: Session = Depends(get_session)):
    return list_change_notices(session)


@app.get("/api/v1/backups")
def get_backups():
    try:
        return list_backups()
    except BackupError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/v1/items/{item_id}/documents")
def get_item_documents(item_id: str, session: Session = Depends(get_session)):
    try:
        return list_documents(session, item_id)
    except DocumentError as exc:
        raise HTTPException(status_code=404 if str(exc) == "Item not found" else 409, detail=str(exc)) from exc


@app.post("/api/v1/items/{item_id}/documents")
async def post_item_document(item_id: str, request: Request,
                             filename: str = Query(min_length=1, max_length=255),
                             revision_id: str | None = None,
                             description: str | None = Query(default=None, max_length=1000),
                             session: Session = Depends(get_session)):
    content_length = request.headers.get("content-length")
    if content_length and content_length.isdigit() and int(content_length) > MAX_DOCUMENT_BYTES:
        raise HTTPException(status_code=413, detail="Files must be 100 MB or smaller")
    try:
        content = await request.body()
        return save_document(session, item_id, filename, content,
                             request.headers.get("content-type", "application/octet-stream"),
                             description, revision_id)
    except DocumentError as exc:
        raise HTTPException(status_code=404 if str(exc) == "Item not found" else 409, detail=str(exc)) from exc


@app.get("/api/v1/documents/{document_id}/download")
def download_document(document_id: str, session: Session = Depends(get_session)):
    try:
        content, filename, media_type = get_document_file(session, document_id)
        return Response(content=content, media_type=media_type,
                        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(filename)}"})
    except DocumentError as exc:
        raise HTTPException(status_code=404 if str(exc) == "Document not found" else 409,
                            detail=str(exc)) from exc


@app.delete("/api/v1/documents/{document_id}", status_code=204)
def remove_document(document_id: str, session: Session = Depends(get_session)):
    try:
        delete_document(session, document_id)
    except DocumentError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.post("/api/v1/backups")
def post_backup():
    try:
        return create_backup()
    except BackupError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/v1/backups/{backup_name}/restore")
def post_restore_backup(backup_name: str, session: Session = Depends(get_session)):
    session.close()
    engine.dispose()
    try:
        restored = restore_backup(backup_name)
        backend_dir = Path(__file__).resolve().parents[1]
        config = AlembicConfig(str(backend_dir / "alembic.ini"))
        config.set_main_option("script_location", str(backend_dir / "migrations"))
        alembic_command.upgrade(config, "head")
        return restored
    except BackupError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/v1/change-notices")
def post_change_notice(payload: ChangeNoticeCreate, session: Session = Depends(get_session)):
    try:
        return create_change_notice(session, payload)
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/v1/change-notices/{notice_id}/transition")
def post_change_notice_transition(notice_id: str, payload: ChangeNoticeTransition,
                                 session: Session = Depends(get_session)):
    try:
        return transition_change_notice(session, notice_id, payload.status)
    except DomainError as exc:
        status = 404 if str(exc) == "Change notice not found" else 409
        raise HTTPException(status_code=status, detail=str(exc)) from exc


@app.post("/api/v1/bom/import")
def post_bom_import(payload: BomImportRequest, session: Session = Depends(get_session)):
    try:
        return import_bom_rows(session, payload.root_revision_id, payload.rows)
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/v1/items")
def post_item(payload: ItemCreate, session: Session = Depends(get_session)):
    try:
        item, revision = create_item(session, **payload.model_dump())
        return {"item": {"id": item.id, "item_number": item.item_number, "name": item.name,
                          "item_type": item.item_type},
                "revision": {"id": revision.id, "revision_code": revision.revision_code,
                             "state": revision.state}}
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch("/api/v1/items/{item_id}")
def patch_item(item_id: str, payload: ItemPatch, session: Session = Depends(get_session)):
    try:
        item = update_item_number(session, item_id, payload.item_number)
        return {"id": item.id, "item_number": item.item_number}
    except DomainError as exc:
        status = 404 if str(exc) == "Item not found" else 409
        raise HTTPException(status_code=status, detail=str(exc)) from exc


@app.get("/api/v1/items/{item_id}/where-used")
def get_where_used(item_id: str, session: Session = Depends(get_session)):
    try:
        return where_used(session, item_id)
    except DomainError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.delete("/api/v1/items/{item_id}", status_code=204)
def delete_product(item_id: str, session: Session = Depends(get_session)):
    try:
        delete_product_workspace(session, item_id)
    except DomainError as exc:
        status = 404 if str(exc) == "Product BOM not found" else 409
        raise HTTPException(status_code=status, detail=str(exc)) from exc


@app.post("/api/v1/occurrences")
def post_occurrence(payload: OccurrenceCreate, session: Session = Depends(get_session)):
    try:
        row = add_occurrence(session, **payload.model_dump())
        return {"id": row.id, "find_number": row.find_number, "quantity": row.quantity}
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch("/api/v1/occurrences/{occurrence_id}")
def patch_occurrence(occurrence_id: str, payload: OccurrencePatch, session: Session = Depends(get_session)):
    try:
        row = change_occurrence(session, occurrence_id, **payload.model_dump(exclude_unset=True))
        return {"id": row.id, "find_number": row.find_number, "quantity": row.quantity}
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch("/api/v1/occurrences/{occurrence_id}/move")
def patch_occurrence_move(occurrence_id: str, payload: OccurrenceMove, session: Session = Depends(get_session)):
    try:
        row = move_occurrence(session, occurrence_id, payload.parent_revision_id)
        return {"id": row.id, "parent_revision_id": row.parent_revision_id,
                "find_number": row.find_number, "sort_order": row.sort_order}
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.delete("/api/v1/occurrences/{occurrence_id}", status_code=204)
def delete_occurrence(occurrence_id: str, session: Session = Depends(get_session)):
    try:
        remove_occurrence(session, occurrence_id)
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/api/v1/revisions/{revision_id}/hierarchy")
def get_hierarchy(revision_id: str, session: Session = Depends(get_session)):
    try:
        return hierarchy(session, revision_id)
    except DomainError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/v1/revisions/compare")
def get_revision_comparison(left: str, right: str, session: Session = Depends(get_session)):
    try:
        return compare_revisions(session, left, right)
    except DomainError as exc:
        raise HTTPException(status_code=404 if str(exc) == "Revision not found" else 409, detail=str(exc)) from exc


@app.patch("/api/v1/revisions/{revision_id}")
def patch_revision(revision_id: str, payload: ItemRevisionPatch, session: Session = Depends(get_session)):
    try:
        revision = update_revision_data(session, revision_id, payload.model_dump(exclude_unset=True))
        return {"id": revision.id, "revision_code": revision.revision_code, "state": revision.state}
    except DomainError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post("/api/v1/items/{item_id}/revisions")
def post_working_revision(item_id: str, payload: ItemRevisionCreate,
                          session: Session = Depends(get_session)):
    try:
        revision = create_working_revision(session, item_id, **payload.model_dump())
        return {"id": revision.id, "item_id": revision.item_id,
                "revision_code": revision.revision_code, "iteration": revision.iteration,
                "state": revision.state}
    except DomainError as exc:
        status = 404 if str(exc) == "Item not found" else 409
        raise HTTPException(status_code=status, detail=str(exc)) from exc


@app.post("/api/v1/revisions/{revision_id}/release")
def post_release_revision(revision_id: str, session: Session = Depends(get_session)):
    try:
        revision = release_revision(session, revision_id)
        return {"id": revision.id, "revision_code": revision.revision_code, "state": revision.state}
    except DomainError as exc:
        status = 404 if str(exc) == "Revision not found" else 409
        raise HTTPException(status_code=status, detail=str(exc)) from exc


@app.get("/api/v1/revisions/{revision_id}/bom/multilevel")
def get_multilevel_bom(revision_id: str, session: Session = Depends(get_session)):
    try:
        return multilevel_bom(session, revision_id)
    except DomainError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@app.get("/api/v1/revisions/{revision_id}/exports/engineering-management")
def export_engineering_management(
    revision_id: str,
    title: str = Query(default="Retearn Engineering Management", max_length=100),
    session: Session = Depends(get_session),
):
    try:
        workbook = build_engineering_management_workbook(session, revision_id, title)
        revision = session.get(ItemRevision, revision_id)
        if not revision:
            raise DomainError("Revision not found")
        filename = f"{revision.item.item_number}_engineering_management.xlsx"
        return StreamingResponse(
            workbook,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except DomainError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

