from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.models import (AssemblyOccurrence, AuditEvent, BomType, ChangeNotice,
                        ChangeNoticeItem, Item, ItemRevision, ManufacturingProcess,
                        RevisionState, ScopeCategory)
from app.schemas import BomImportRow, ChangeNoticeCreate


class DomainError(ValueError):
    pass


def record_audit(session: Session, *, entity_type: str, entity_id: str, action: str,
                 summary: str, item: Item | None = None, revision: ItemRevision | None = None,
                 field_name: str | None = None, old_value=None, new_value=None) -> None:
    session.add(AuditEvent(
        item_id=item.id if item else (revision.item_id if revision else None),
        item_number=item.item_number if item else (revision.item.item_number if revision else None),
        item_name=item.name if item else (revision.item.name if revision else None),
        revision_id=revision.id if revision else None,
        revision_code=revision.revision_code if revision else None,
        entity_type=entity_type, entity_id=entity_id, action=action,
        field_name=field_name,
        old_value=None if old_value is None else str(old_value),
        new_value=None if new_value is None else str(new_value),
        summary=summary,
    ))


def reusable_proprietary_classifications(session: Session) -> list[str]:
    """Return custom classifications used by at least three BOM occurrences."""
    values = session.scalars(
        select(ItemRevision.proprietary_classification)
        .join(AssemblyOccurrence, AssemblyOccurrence.child_revision_id == ItemRevision.id)
        .where(ItemRevision.proprietary_classification.is_not(None),
               ItemRevision.proprietary_classification != "")
        .group_by(ItemRevision.proprietary_classification)
        .having(func.count(AssemblyOccurrence.id) >= 3)
        .order_by(ItemRevision.proprietary_classification)
    ).all()
    return [value for value in values if value]


def used_system_names(session: Session) -> list[str]:
    values = session.scalars(
        select(AssemblyOccurrence.system_name)
        .where(AssemblyOccurrence.system_name.is_not(None), AssemblyOccurrence.system_name != "")
        .group_by(AssemblyOccurrence.system_name)
        .order_by(AssemblyOccurrence.system_name)
    ).all()
    return [value for value in values if value]


def ensure_masters(session: Session) -> None:
    scopes = ["Vendor", "Company E-Kit", "Company Bought Out", "Fasteners",
              "In-house Manufacturing", "Customer Supplied", "Standard Purchased Components"]
    processes = ["Machining", "Turning", "Milling", "Drilling", "Sheet Metal",
                 "Laser cutting", "Bending", "Welding", "Assembly", "Inspection"]
    for value in scopes:
        if not session.scalar(select(ScopeCategory).where(ScopeCategory.name == value)):
            session.add(ScopeCategory(name=value))
    for value in processes:
        if not session.scalar(select(ManufacturingProcess).where(ManufacturingProcess.name == value)):
            session.add(ManufacturingProcess(name=value))
    session.commit()


def create_item(session: Session, *, item_number: str, name: str, item_type: str,
                revision_code: str = "A", description: str | None = None,
                scope: str | None = None, manufacturing_process: str | None = None,
                mass: float | None = None, mass_source: str | None = None,
                unit_cost: float | None = None, uom: str = "EA") -> tuple[Item, ItemRevision]:
    if session.scalar(select(Item).where(Item.item_number == item_number)):
        raise DomainError(f"Item number already exists: {item_number}")
    scope_row = session.scalar(select(ScopeCategory).where(ScopeCategory.name == scope)) if scope else None
    process_row = session.scalar(select(ManufacturingProcess).where(ManufacturingProcess.name == manufacturing_process)) if manufacturing_process else None
    if scope and not scope_row:
        raise DomainError(f"Unknown scope category: {scope}")
    if manufacturing_process and not process_row:
        raise DomainError(f"Unknown manufacturing process: {manufacturing_process}")
    item = Item(item_number=item_number, name=name, item_type=item_type)
    revision = ItemRevision(revision_code=revision_code, description=description,
                            scope_category=scope_row, manufacturing_process=process_row,
                            mass=mass, mass_source=mass_source, unit_cost=unit_cost, uom=uom)
    item.revisions.append(revision)
    session.add(item)
    session.flush()
    record_audit(session, entity_type="ITEM", entity_id=item.id, action="CREATED",
                 summary=f"Created {item.item_type.lower()} {item_number}", item=item, revision=revision)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not create item {item_number}: {exc.orig}") from exc
    return item, revision


def update_item_number(session: Session, item_id: str, item_number: str) -> Item:
    item = session.get(Item, item_id)
    if not item:
        raise DomainError("Item not found")
    corrected_number = item_number.strip()
    if not corrected_number:
        raise DomainError("Part number cannot be empty")
    duplicate = session.scalar(select(Item).where(
        Item.item_number == corrected_number, Item.id != item_id))
    if duplicate:
        raise DomainError(f"Part number already exists: {corrected_number}")
    previous_number = item.item_number
    item.item_number = corrected_number
    record_audit(session, entity_type="ITEM", entity_id=item.id, action="UPDATED",
                 summary=f"Changed item number from {previous_number} to {corrected_number}",
                 item=item, field_name="item_number", old_value=previous_number, new_value=corrected_number)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not update part number: {exc.orig}") from exc
    return item


def delete_product_workspace(session: Session, item_id: str) -> str:
    item = session.get(Item, item_id)
    if not item:
        raise DomainError("Product BOM not found")
    if item.item_type != "MAIN PRODUCT":
        raise DomainError("Only a main product workspace can be deleted here")
    external_use = session.scalar(select(AssemblyOccurrence.id).where(
        AssemblyOccurrence.child_item_id == item_id).limit(1))
    if external_use:
        raise DomainError("This product is referenced by another BOM and cannot be deleted")
    revision_ids = select(ItemRevision.id).where(ItemRevision.item_id == item_id)
    external_revision_link = session.scalar(select(ItemRevision.id).where(
        ItemRevision.previous_revision_id.in_(revision_ids), ItemRevision.item_id != item_id).limit(1))
    if external_revision_link:
        raise DomainError("This product revision is referenced by another item and cannot be deleted")
    item_number = item.item_number
    record_audit(session, entity_type="ITEM", entity_id=item.id, action="DELETED",
                 summary=f"Deleted local Product BOM {item.item_number}", item=item)
    revisions = session.scalars(select(ItemRevision).where(ItemRevision.item_id == item_id)).all()
    for revision in revisions:
        revision.previous_revision_id = None
    occurrences = session.scalars(select(AssemblyOccurrence).where(
        AssemblyOccurrence.parent_revision_id.in_(revision_ids))).all()
    for occurrence in occurrences:
        session.delete(occurrence)
    session.flush()
    session.delete(item)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError("This Product BOM is still referenced elsewhere and was not deleted") from exc
    return item_number


def _would_create_cycle(session: Session, parent_item_id: str, child_item_id: str) -> bool:
    if parent_item_id == child_item_id:
        return True
    stack = [child_item_id]
    seen: set[str] = set()
    while stack:
        current = stack.pop()
        if current in seen:
            continue
        seen.add(current)
        current_revisions = select(ItemRevision.id).where(ItemRevision.item_id == current)
        child_ids = session.scalars(select(AssemblyOccurrence.child_item_id).where(
            AssemblyOccurrence.parent_revision_id.in_(current_revisions))).all()
        if parent_item_id in child_ids:
            return True
        stack.extend(child_ids)
    return False


def add_occurrence(session: Session, *, parent_revision_id: str, child_item_id: str,
                   find_number: str, quantity: float, uom: str = "EA", bom_type: str = "EBOM",
                   child_revision_id: str | None = None, sort_order: int = 0,
                   remarks: str | None = None, system_name: str | None = None,
                   coe_names: str | None = None) -> AssemblyOccurrence:
    parent = session.get(ItemRevision, parent_revision_id)
    child = session.get(Item, child_item_id)
    if not parent or not child:
        raise DomainError("Parent revision or child item does not exist")
    if parent.state != RevisionState.IN_WORK.value:
        raise DomainError("Occurrences can only be changed on an in-work parent revision")
    if parent.item.item_type not in {"MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY"}:
        raise DomainError("Only a product or assembly can contain BOM occurrences")
    if quantity <= 0:
        raise DomainError("Occurrence quantity must be greater than zero")
    if _would_create_cycle(session, parent.item_id, child_item_id):
        raise DomainError("Occurrence would create a circular assembly reference")
    if child_revision_id:
        pinned = session.get(ItemRevision, child_revision_id)
        if not pinned or pinned.item_id != child_item_id:
            raise DomainError("Pinned revision must belong to the selected child item")
    row = AssemblyOccurrence(parent_revision_id=parent_revision_id, child_item_id=child_item_id,
                             child_revision_id=child_revision_id, find_number=find_number,
                             quantity=quantity, uom=uom, bom_type=bom_type,
                             sort_order=sort_order, remarks=remarks, system_name=system_name,
                             coe_names=coe_names)
    session.add(row)
    session.flush()
    record_audit(session, entity_type="OCCURRENCE", entity_id=row.id, action="ADDED",
                 summary=f"Added {child.item_number} to {parent.item.item_number} (find {find_number}, qty {quantity:g})",
                 item=child, revision=session.get(ItemRevision, child_revision_id) if child_revision_id else None,
                 field_name="quantity", new_value=quantity)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not add occurrence: {exc.orig}") from exc
    return row


_VALID_ITEM_TYPES = {
    "MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY",
    "PART", "STANDARD COMPONENT", "FASTENER", "BOUGHT-OUT COMPONENT",
}
_ASSEMBLY_TYPES = {"MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY"}


def _import_item_type(row: BomImportRow) -> str:
    value = (row.item_type or "").strip().upper()
    if value in _VALID_ITEM_TYPES:
        if value == "MAIN PRODUCT":
            raise DomainError(f"Row {row.source_row}: a Product BOM cannot be nested as a component")
        return value
    classification = (row.classification or "").strip().upper()
    if classification in {"MAIN ASSY", "MAIN ASSEMBLY"}:
        return "MAIN ASSEMBLY"
    if classification == "CHILD ASSEMBLY":
        return "CHILD ASSEMBLY"
    if classification in {"ASSEMBLY", "ASSY", "SUB ASSEMBLY"}:
        return "MAIN ASSEMBLY" if row.level == 2 else "SUB ASSEMBLY"
    if classification in {"STD PART", "STANDARD PART", "STANDARD COMPONENT"}:
        return "STANDARD COMPONENT"
    if classification in {"FASTENER", "FASTENERS"}:
        return "FASTENER"
    scope = (row.scope or "").strip().lower()
    if scope in {"vendor", "company bought out", "customer supplied", "standard purchased components"}:
        return "BOUGHT-OUT COMPONENT"
    return "PART"


def import_bom_rows(session: Session, root_revision_id: str,
                    rows: list[BomImportRow]) -> dict:
    """Import a flattened level-marked BOM in one transaction, preserving item identity."""
    root = session.get(ItemRevision, root_revision_id)
    if not root:
        raise DomainError("Product revision not found")
    if root.item.item_type != "MAIN PRODUCT":
        raise DomainError("Excel BOM import must target a main Product BOM revision")
    if root.state != RevisionState.IN_WORK.value:
        raise DomainError("Excel BOM import is only allowed on an in-work Product BOM")

    ordered_rows = sorted(rows, key=lambda row: row.source_row)
    if len({row.source_row for row in ordered_rows}) != len(ordered_rows):
        raise DomainError("Import contains duplicate source row numbers")
    parent_by_level: dict[int, ItemRevision] = {1: root}
    item_cache: dict[str, tuple[Item, ItemRevision]] = {}
    created_items = linked_occurrences = 0
    last_level = 1
    preflight_parent_levels: dict[int, bool] = {1: True}

    # Resolve all item types and graph positions before creating anything.
    normalized: list[tuple[BomImportRow, str]] = []
    for row in ordered_rows:
        if not row.item_number.strip() or not row.name.strip():
            raise DomainError(f"Row {row.source_row}: part number and part name are required")
        if row.level > last_level + 1:
            raise DomainError(f"Row {row.source_row}: Level {row.level} skips a parent level")
        if not preflight_parent_levels.get(row.level - 1):
            raise DomainError(f"Row {row.source_row}: no preceding assembly exists at Level {row.level - 1}")
        inferred_type = _import_item_type(row)
        normalized.append((row, inferred_type))
        for level in [level for level in preflight_parent_levels if level >= row.level]:
            preflight_parent_levels.pop(level, None)
        if inferred_type in _ASSEMBLY_TYPES:
            preflight_parent_levels[row.level] = True
        last_level = row.level

    try:
        for row, inferred_type in normalized:
            parent = parent_by_level[row.level - 1]
            if parent.state != RevisionState.IN_WORK.value:
                raise DomainError(f"Row {row.source_row}: parent assembly {parent.item.item_number} is released or obsolete")
            item_number = row.item_number.strip()
            item_pair = item_cache.get(item_number)
            if item_pair is None:
                item = session.scalar(select(Item).where(Item.item_number == item_number))
                if item:
                    if inferred_type in _ASSEMBLY_TYPES and item.item_type not in _ASSEMBLY_TYPES:
                        raise DomainError(f"Row {row.source_row}: {item_number} exists as {item.item_type}, not an assembly")
                    if inferred_type not in _ASSEMBLY_TYPES and item.item_type in _ASSEMBLY_TYPES:
                        raise DomainError(f"Row {row.source_row}: {item_number} exists as an assembly; check its classification")
                    if row.revision_code:
                        child_revision = session.scalar(select(ItemRevision).where(
                            ItemRevision.item_id == item.id,
                            ItemRevision.revision_code == row.revision_code.strip()).order_by(ItemRevision.iteration.desc()))
                        if not child_revision:
                            raise DomainError(f"Row {row.source_row}: revision {row.revision_code} for {item_number} was not found")
                    else:
                        child_revision = session.scalar(select(ItemRevision).where(
                            ItemRevision.item_id == item.id).order_by(ItemRevision.created_at.desc(), ItemRevision.iteration.desc()))
                    if not child_revision:
                        raise DomainError(f"Row {row.source_row}: {item_number} has no revision to link")
                else:
                    scope_row = session.scalar(select(ScopeCategory).where(ScopeCategory.name == row.scope.strip())) if row.scope and row.scope.strip() else None
                    if row.scope and row.scope.strip() and not scope_row:
                        raise DomainError(f"Row {row.source_row}: unknown scope '{row.scope}'")
                    revision = ItemRevision(
                        revision_code=(row.revision_code or "A").strip() or "A",
                        state=RevisionState.IN_WORK.value,
                        scope_category=scope_row,
                        manufacturing_methods=row.manufacturing_methods,
                        proprietary_classification=row.classification,
                        pdm_release_level=row.pdm_release_level,
                        cad_release_status=row.cad_release_status,
                        material_designation=row.material_designation,
                        mass=row.mass,
                        mass_source="USER_ENTERED" if row.mass is not None else None,
                        unit_cost=row.unit_cost,
                        manufacturer_part_number=row.manufacturer_part_number,
                        purchase_reference_url=row.purchase_reference_url,
                        ecn_reference=row.ecn_reference,
                        supplier_name=row.supplier_name,
                        lead_time=row.lead_time,
                        remarks=row.remarks,
                        uom=row.uom.strip() or "EA",
                    )
                    item = Item(item_number=item_number, name=row.name.strip(), item_type=inferred_type)
                    item.revisions.append(revision)
                    session.add(item)
                    session.flush()
                    child_revision = revision
                    record_audit(session, entity_type="ITEM", entity_id=item.id, action="IMPORTED",
                                 summary=f"Created {item.item_type.lower()} {item_number} from Excel BOM",
                                 item=item, revision=revision)
                    created_items += 1
                item_pair = (item, child_revision)
                item_cache[item_number] = item_pair
            item, child_revision = item_pair

            if _would_create_cycle(session, parent.item_id, item.id):
                raise DomainError(f"Row {row.source_row}: linking {item.item_number} would create a circular assembly relationship")

            # A shared assembly master may appear more than once; each occurrence
            # still gets its own BOM line while its revision remains the same.
            if item.item_type in _ASSEMBLY_TYPES:
                parent_by_level[row.level] = child_revision
            else:
                parent_by_level.pop(row.level, None)
            for level in [level for level in parent_by_level if level > row.level]:
                parent_by_level.pop(level, None)

            find_number = (row.find_number or str(row.source_row * 10)).strip()
            existing_find = session.scalar(select(AssemblyOccurrence.id).where(
                AssemblyOccurrence.parent_revision_id == parent.id,
                AssemblyOccurrence.find_number == find_number))
            if existing_find:
                raise DomainError(f"Row {row.source_row}: find number {find_number} already exists under {parent.item.item_number}; import stopped without saving")
            session.add(AssemblyOccurrence(
                parent_revision_id=parent.id,
                child_item_id=item.id,
                child_revision_id=child_revision.id,
                bom_type=BomType.EBOM.value,
                find_number=find_number,
                system_name=row.system_name,
                coe_names=row.coe_names,
                quantity=row.quantity,
                uom=row.uom.strip() or "EA",
                sort_order=row.source_row,
                remarks=row.remarks,
            ))
            session.flush()
            imported_occurrence = session.scalar(select(AssemblyOccurrence).where(
                AssemblyOccurrence.parent_revision_id == parent.id,
                AssemblyOccurrence.find_number == find_number))
            record_audit(session, entity_type="OCCURRENCE", entity_id=imported_occurrence.id,
                         action="IMPORTED", summary=f"Imported {item.item_number} into {parent.item.item_number} from Excel row {row.source_row}",
                         item=item, revision=child_revision, field_name="quantity", new_value=row.quantity)
            linked_occurrences += 1
        session.commit()
    except Exception:
        session.rollback()
        raise
    return {"created_items": created_items, "linked_occurrences": linked_occurrences}


def change_occurrence(session: Session, occurrence_id: str, *, quantity: float | None = None,
                      find_number: str | None = None, remarks: str | None = None,
                      system_name: str | None = None, coe_names: str | None = None) -> AssemblyOccurrence:
    row = session.get(AssemblyOccurrence, occurrence_id)
    if not row:
        raise DomainError("BOM occurrence not found")
    parent = session.get(ItemRevision, row.parent_revision_id)
    if parent.state != RevisionState.IN_WORK.value:
        raise DomainError("Occurrences can only be changed on an in-work parent revision")
    previous = {"quantity": row.quantity, "find_number": row.find_number,
                "remarks": row.remarks, "system_name": row.system_name, "coe_names": row.coe_names}
    if quantity is not None:
        if quantity <= 0:
            raise DomainError("Occurrence quantity must be greater than zero")
        row.quantity = quantity
    if find_number is not None:
        row.find_number = find_number
    if remarks is not None:
        row.remarks = remarks
    if system_name is not None:
        row.system_name = system_name
    if coe_names is not None:
        row.coe_names = coe_names
    current = {"quantity": row.quantity, "find_number": row.find_number,
               "remarks": row.remarks, "system_name": row.system_name, "coe_names": row.coe_names}
    for field, new_value in current.items():
        if previous[field] != new_value:
            record_audit(session, entity_type="OCCURRENCE", entity_id=row.id, action="UPDATED",
                         summary=f"Changed {field} on {row.child_item.item_number} under {parent.item.item_number}",
                         item=row.child_item, revision=row.child_revision, field_name=field,
                         old_value=previous[field], new_value=new_value)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not update occurrence: {exc.orig}") from exc
    return row


def move_occurrence(session: Session, occurrence_id: str, new_parent_revision_id: str) -> AssemblyOccurrence:
    row = session.get(AssemblyOccurrence, occurrence_id)
    new_parent = session.get(ItemRevision, new_parent_revision_id)
    if not row:
        raise DomainError("BOM occurrence not found")
    if not new_parent:
        raise DomainError("Target assembly revision not found")
    old_parent = session.get(ItemRevision, row.parent_revision_id)
    if old_parent.state != RevisionState.IN_WORK.value or new_parent.state != RevisionState.IN_WORK.value:
        raise DomainError("Move items only between in-work assemblies")
    if new_parent.item.item_type not in {"MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY"}:
        raise DomainError("The target level must belong to an assembly")
    if row.parent_revision_id == new_parent_revision_id:
        return row
    previous_parent_name = old_parent.item.item_number
    previous_find_number = row.find_number
    if _would_create_cycle(session, new_parent.item_id, row.child_item_id):
        raise DomainError("Moving this item would create a circular assembly reference")

    siblings = session.scalars(select(AssemblyOccurrence).where(
        AssemblyOccurrence.parent_revision_id == new_parent_revision_id)).all()
    used_find_numbers = {sibling.find_number for sibling in siblings}
    new_find_number = row.find_number
    if new_find_number in used_find_numbers:
        numeric_find_numbers = [int(value) for value in used_find_numbers if value.isdigit()]
        next_number = max(numeric_find_numbers, default=0) + 10
        new_find_number = str(next_number).zfill(2)
        while new_find_number in used_find_numbers:
            next_number += 10
            new_find_number = str(next_number).zfill(2)
    row.parent_revision_id = new_parent_revision_id
    row.find_number = new_find_number
    row.sort_order = max((sibling.sort_order for sibling in siblings), default=0) + 10
    try:
        record_audit(session, entity_type="OCCURRENCE", entity_id=row.id, action="MOVED",
                     summary=f"Moved {row.child_item.item_number} from {previous_parent_name} to {new_parent.item.item_number}",
                     item=row.child_item, revision=row.child_revision,
                     field_name="parent", old_value=f"{previous_parent_name} / {previous_find_number}",
                     new_value=f"{new_parent.item.item_number} / {new_find_number}")
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not move BOM occurrence: {exc.orig}") from exc
    return row


def remove_occurrence(session: Session, occurrence_id: str) -> None:
    row = session.get(AssemblyOccurrence, occurrence_id)
    if not row:
        raise DomainError("BOM occurrence not found")
    parent = session.get(ItemRevision, row.parent_revision_id)
    if parent.state != RevisionState.IN_WORK.value:
        raise DomainError("Occurrences can only be changed on an in-work parent revision")
    record_audit(session, entity_type="OCCURRENCE", entity_id=row.id, action="REMOVED",
                 summary=f"Removed {row.child_item.item_number} from {parent.item.item_number} (find {row.find_number})",
                 item=row.child_item, revision=row.child_revision,
                 field_name="quantity", old_value=row.quantity)
    session.delete(row)
    session.commit()


def update_revision_data(session: Session, revision_id: str, updates: dict) -> ItemRevision:
    revision = session.get(ItemRevision, revision_id)
    if not revision:
        raise DomainError("Revision not found")
    if revision.state != RevisionState.IN_WORK.value:
        raise DomainError("Released or obsolete revisions cannot be edited. Create a working revision first.")
    updates = dict(updates)
    requested_updates = dict(updates)
    def read_value(field: str):
        if field == "scope":
            return revision.scope_category.name if revision.scope_category else None
        if field == "manufacturing_process":
            return revision.manufacturing_process.name if revision.manufacturing_process else None
        return getattr(revision, field, None)
    old_values = {field: read_value(field) for field in requested_updates}
    if "scope" in updates:
        scope_name = updates.pop("scope")
        scope = session.scalar(select(ScopeCategory).where(ScopeCategory.name == scope_name)) if scope_name else None
        if scope_name and not scope:
            raise DomainError(f"Unknown scope category: {scope_name}")
        revision.scope_category = scope
    if "manufacturing_process" in updates:
        process_name = updates.pop("manufacturing_process")
        process = session.scalar(select(ManufacturingProcess).where(ManufacturingProcess.name == process_name)) if process_name else None
        if process_name and not process:
            raise DomainError(f"Unknown manufacturing process: {process_name}")
        revision.manufacturing_process = process
    editable_fields = {
        "manufacturing_methods", "proprietary_classification", "pdm_release_level",
        "cad_release_status", "material_designation", "mass", "mass_source", "unit_cost",
        "manufacturer_part_number", "purchase_reference_url", "ecn_reference",
        "supplier_name", "lead_time", "remarks",
    }
    unknown = set(updates) - editable_fields
    if unknown:
        raise DomainError(f"Unsupported revision field: {sorted(unknown)[0]}")
    for key, value in updates.items():
        setattr(revision, key, value)
    for field in requested_updates:
        old_value = old_values[field]
        new_value = read_value(field)
        if old_value != new_value:
            record_audit(session, entity_type="REVISION", entity_id=revision.id, action="UPDATED",
                         summary=f"Changed {field.replace('_', ' ')} on {revision.item.item_number} Rev {revision.revision_code}",
                         revision=revision, field_name=field, old_value=old_value, new_value=new_value)
    try:
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not update revision: {exc.orig}") from exc
    return revision


def release_revision(session: Session, revision_id: str) -> ItemRevision:
    revision = session.get(ItemRevision, revision_id)
    if not revision:
        raise DomainError("Revision not found")
    if revision.state != RevisionState.IN_WORK.value:
        raise DomainError("Only an in-work revision can be released")
    occurrences = session.scalars(select(AssemblyOccurrence).where(
        AssemblyOccurrence.parent_revision_id == revision_id)).all()
    for occurrence in occurrences:
        child_revision = session.get(ItemRevision, occurrence.child_revision_id) if occurrence.child_revision_id else None
        if not child_revision or child_revision.item_id != occurrence.child_item_id or child_revision.state != RevisionState.RELEASED.value:
            raise DomainError(f"Occurrence {occurrence.find_number} must reference a released child revision")
    revision.state = RevisionState.RELEASED.value
    revision.released_at = datetime.now(timezone.utc)
    record_audit(session, entity_type="REVISION", entity_id=revision.id, action="RELEASED",
                 summary=f"Released {revision.item.item_number} Rev {revision.revision_code}",
                 revision=revision, field_name="state", old_value=RevisionState.IN_WORK.value,
                 new_value=RevisionState.RELEASED.value)
    session.commit()
    return revision


def create_working_revision(session: Session, item_id: str, *, revision_code: str,
                            description: str | None = None, change_reason: str | None = None) -> ItemRevision:
    item = session.get(Item, item_id)
    if not item:
        raise DomainError("Item not found")
    if session.scalar(select(ItemRevision.id).where(
            ItemRevision.item_id == item_id,
            ItemRevision.state == RevisionState.IN_WORK.value).limit(1)):
        raise DomainError("Release the current in-work revision before creating another")
    prior = session.scalar(select(ItemRevision).where(ItemRevision.item_id == item_id,
                                                        ItemRevision.state == RevisionState.RELEASED.value)
                           .order_by(ItemRevision.created_at.desc()))
    row = ItemRevision(item_id=item_id, revision_code=revision_code,
                       previous_revision_id=prior.id if prior else None,
                       description=description if description is not None else (prior.description if prior else None),
                       change_reason=change_reason,
                       scope_category_id=prior.scope_category_id if prior else None,
                       manufacturing_process_id=prior.manufacturing_process_id if prior else None,
                       manufacturing_methods=prior.manufacturing_methods if prior else None,
                       proprietary_classification=prior.proprietary_classification if prior else None,
                       pdm_release_level=prior.pdm_release_level if prior else None,
                       cad_release_status=prior.cad_release_status if prior else None,
                       material_designation=prior.material_designation if prior else None,
                       mass=prior.mass if prior else None, mass_source=prior.mass_source if prior else None,
                       unit_cost=prior.unit_cost if prior else None,
                       manufacturer_part_number=prior.manufacturer_part_number if prior else None,
                       purchase_reference_url=prior.purchase_reference_url if prior else None,
                       ecn_reference=prior.ecn_reference if prior else None,
                       supplier_name=prior.supplier_name if prior else None,
                       lead_time=prior.lead_time if prior else None,
                       uom=prior.uom if prior else "EA",
                       remarks=prior.remarks if prior else None)
    session.add(row)
    try:
        session.flush()
        if prior:
            prior_occurrences = session.scalars(select(AssemblyOccurrence).where(
                AssemblyOccurrence.parent_revision_id == prior.id).order_by(
                    AssemblyOccurrence.sort_order, AssemblyOccurrence.find_number)).all()
            for occurrence in prior_occurrences:
                session.add(AssemblyOccurrence(
                    parent_revision_id=row.id, child_item_id=occurrence.child_item_id,
                    child_revision_id=occurrence.child_revision_id, bom_type=occurrence.bom_type,
                    find_number=occurrence.find_number, system_name=occurrence.system_name,
                    quantity=occurrence.quantity, uom=occurrence.uom,
                    sort_order=occurrence.sort_order,
                    effectivity_start=occurrence.effectivity_start,
                    effectivity_end=occurrence.effectivity_end,
                    coe_names=occurrence.coe_names, remarks=occurrence.remarks,
                ))
        record_audit(session, entity_type="REVISION", entity_id=row.id, action="CREATED",
                     summary=f"Created working revision {item.item_number} Rev {revision_code}",
                     revision=row, field_name="previous_revision_id", old_value=None,
                     new_value=prior.revision_code if prior else None)
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"Could not create working revision: {exc.orig}") from exc
    return row


def compare_revisions(session: Session, left_revision_id: str, right_revision_id: str) -> dict:
    left = session.get(ItemRevision, left_revision_id)
    right = session.get(ItemRevision, right_revision_id)
    if not left or not right:
        raise DomainError("Revision not found")
    if left.item_id != right.item_id:
        raise DomainError("Choose two revisions belonging to the same item")

    def revision_fields(revision: ItemRevision) -> dict:
        return {
            "description": revision.description or "",
            "change_reason": revision.change_reason or "",
            "state": revision.state,
            "scope": revision.scope_category.name if revision.scope_category else "",
            "manufacturing_methods": revision.manufacturing_methods or "",
            "proprietary_classification": revision.proprietary_classification or "",
            "pdm_release_level": revision.pdm_release_level or "",
            "cad_release_status": revision.cad_release_status or "",
            "material_designation": revision.material_designation or "",
            "mass": revision.mass,
            "unit_cost": revision.unit_cost,
            "manufacturer_part_number": revision.manufacturer_part_number or "",
            "purchase_reference_url": revision.purchase_reference_url or "",
            "ecn_reference": revision.ecn_reference or "",
            "supplier_name": revision.supplier_name or "",
            "lead_time": revision.lead_time or "",
            "uom": revision.uom,
            "remarks": revision.remarks or "",
        }

    left_fields, right_fields = revision_fields(left), revision_fields(right)
    metadata_changes = [
        {"field": field, "left": left_fields[field], "right": right_fields[field]}
        for field in left_fields if left_fields[field] != right_fields[field]
    ]

    def bom_lines(root_revision: ItemRevision) -> dict[str, dict]:
        result: dict[str, dict] = {}
        def walk(parent_revision: ItemRevision, parent_key: str) -> None:
            occurrences = session.scalars(select(AssemblyOccurrence).where(
                AssemblyOccurrence.parent_revision_id == parent_revision.id).order_by(
                    AssemblyOccurrence.sort_order, AssemblyOccurrence.find_number)).all()
            for occurrence in occurrences:
                child = occurrence.child_item
                child_revision = session.get(ItemRevision, occurrence.child_revision_id) if occurrence.child_revision_id else None
                key = f"{parent_key}/{occurrence.find_number}:{child.id}"
                result[key] = {
                    "key": key, "parent_item_number": parent_revision.item.item_number,
                    "find_number": occurrence.find_number, "item_id": child.id,
                    "item_number": child.item_number, "name": child.name,
                    "item_type": child.item_type, "revision": child_revision.revision_code if child_revision else "",
                    "quantity": occurrence.quantity, "uom": occurrence.uom,
                    "system_name": occurrence.system_name or "",
                }
                if child_revision and child.item_type in _ASSEMBLY_TYPES:
                    walk(child_revision, key)
        walk(root_revision, root_revision.item_id)
        return result

    left_lines, right_lines = bom_lines(left), bom_lines(right)
    added = [right_lines[key] for key in right_lines.keys() - left_lines.keys()]
    removed = [left_lines[key] for key in left_lines.keys() - right_lines.keys()]
    changed = []
    for key in left_lines.keys() & right_lines.keys():
        before, after = left_lines[key], right_lines[key]
        differences = {field: {"left": before[field], "right": after[field]}
                       for field in before if field not in {"key", "item_id"} and before[field] != after[field]}
        if differences:
            changed.append({"left": before, "right": after, "differences": differences})
    return {
        "item": {"id": left.item.id, "item_number": left.item.item_number, "name": left.item.name},
        "left": {"id": left.id, "revision_code": left.revision_code, "iteration": left.iteration, "state": left.state},
        "right": {"id": right.id, "revision_code": right.revision_code, "iteration": right.iteration, "state": right.state},
        "metadata_changes": metadata_changes,
        "bom_changes": {"added": sorted(added, key=lambda row: row["key"]),
                        "removed": sorted(removed, key=lambda row: row["key"]),
                        "changed": sorted(changed, key=lambda row: row["left"]["key"])},
    }


def audit_history(session: Session, item_id: str | None = None, limit: int = 200) -> list[dict]:
    query = select(AuditEvent).order_by(AuditEvent.created_at.desc(), AuditEvent.id.desc())
    if item_id:
        query = query.where(AuditEvent.item_id == item_id)
    events = session.scalars(query.limit(max(1, min(limit, 500)))).all()
    return [{"id": event.id, "item_id": event.item_id, "item_number": event.item_number,
             "item_name": event.item_name, "revision_id": event.revision_id,
             "revision_code": event.revision_code, "entity_type": event.entity_type,
             "entity_id": event.entity_id, "action": event.action,
             "field_name": event.field_name, "old_value": event.old_value,
             "new_value": event.new_value, "summary": event.summary,
             "actor": event.actor,
             "created_at": event.created_at.isoformat() if event.created_at else None}
            for event in events]


def _change_notice_data(notice: ChangeNotice) -> dict:
    return {
        "id": notice.id, "ecn_number": notice.ecn_number, "title": notice.title,
        "reason": notice.reason, "status": notice.status,
        "created_at": notice.created_at.isoformat() if notice.created_at else None,
        "modified_at": notice.modified_at.isoformat() if notice.modified_at else None,
        "affected_items": [{
            "id": affected.id, "item_id": affected.item_id,
            "item_number": affected.item.item_number, "item_name": affected.item.name,
            "item_type": affected.item.item_type,
            "baseline_revision_id": affected.baseline_revision_id,
            "baseline_revision": affected.baseline_revision.revision_code if affected.baseline_revision else None,
            "change_description": affected.change_description,
        } for affected in notice.affected_items],
    }


def list_change_notices(session: Session) -> list[dict]:
    notices = session.scalars(select(ChangeNotice).order_by(ChangeNotice.created_at.desc())).all()
    return [_change_notice_data(notice) for notice in notices]


def create_change_notice(session: Session, payload: ChangeNoticeCreate) -> dict:
    if len({row.item_id for row in payload.affected_items}) != len(payload.affected_items):
        raise DomainError("Each affected item can appear only once in a change notice")
    notice = ChangeNotice(ecn_number=payload.ecn_number.strip(), title=payload.title.strip(),
                          reason=payload.reason.strip(), status="DRAFT")
    if not notice.ecn_number or not notice.title or not notice.reason:
        raise DomainError("ECN number, title, and reason are required")
    try:
        for row in payload.affected_items:
            item = session.get(Item, row.item_id)
            if not item:
                raise DomainError(f"Affected item {row.item_id} was not found")
            baseline = session.scalar(select(ItemRevision).where(
                ItemRevision.item_id == item.id,
                ItemRevision.state == RevisionState.RELEASED.value).order_by(ItemRevision.created_at.desc()))
            notice.affected_items.append(ChangeNoticeItem(
                item=item, baseline_revision=baseline,
                change_description=row.change_description.strip()))
        session.add(notice)
        session.flush()
        record_audit(session, entity_type="CHANGE_NOTICE", entity_id=notice.id, action="CREATED",
                     summary=f"Created change notice {notice.ecn_number}: {notice.title}")
        session.commit()
    except IntegrityError as exc:
        session.rollback()
        raise DomainError(f"ECN number already exists or affected items are invalid: {exc.orig}") from exc
    return _change_notice_data(notice)


def transition_change_notice(session: Session, notice_id: str, status: str) -> dict:
    notice = session.get(ChangeNotice, notice_id)
    if not notice:
        raise DomainError("Change notice not found")
    target = status.strip().upper()
    valid_next = {
        "DRAFT": {"IN REVIEW", "CANCELLED"},
        "IN REVIEW": {"APPROVED", "CANCELLED"},
        "APPROVED": {"IMPLEMENTED", "CANCELLED"},
        "IMPLEMENTED": set(), "CANCELLED": set(),
    }
    if target not in valid_next.get(notice.status, set()):
        raise DomainError(f"Change notice cannot move from {notice.status} to {target}")
    if target == "IMPLEMENTED" and not notice.affected_items:
        raise DomainError("An implemented change notice must identify affected items")
    if target == "IMPLEMENTED":
        for affected in notice.affected_items:
            latest_released = session.scalar(select(ItemRevision).where(
                ItemRevision.item_id == affected.item_id,
                ItemRevision.state == RevisionState.RELEASED.value).order_by(ItemRevision.created_at.desc()))
            if not latest_released:
                raise DomainError(f"{affected.item.item_number} has no released revision. Release the approved change before marking this notice implemented.")
            if affected.baseline_revision_id and latest_released.id == affected.baseline_revision_id:
                raise DomainError(f"{affected.item.item_number} has no newer released revision than the change notice baseline.")
    previous = notice.status
    notice.status = target
    notice.modified_at = datetime.now(timezone.utc)
    record_audit(session, entity_type="CHANGE_NOTICE", entity_id=notice.id, action="STATUS CHANGED",
                 summary=f"Change notice {notice.ecn_number} moved from {previous} to {target}",
                 field_name="status", old_value=previous, new_value=target)
    session.commit()
    return _change_notice_data(notice)


def where_used(session: Session, item_id: str) -> dict:
    item = session.get(Item, item_id)
    if not item:
        raise DomainError("Item not found")
    uses: list[dict] = []

    def ascend(current_item_id: str, multiplier: float, path_up: list[dict], visited: frozenset[tuple[str, str]]) -> None:
        occurrences = session.scalars(select(AssemblyOccurrence).where(
            AssemblyOccurrence.child_item_id == current_item_id).order_by(
                AssemblyOccurrence.parent_revision_id, AssemblyOccurrence.sort_order,
                AssemblyOccurrence.find_number)).all()
        for occurrence in occurrences:
            parent_revision = session.get(ItemRevision, occurrence.parent_revision_id)
            if not parent_revision:
                continue
            parent_item = parent_revision.item
            identity = (parent_item.id, parent_revision.id)
            if identity in visited:
                continue
            segment = {"item_id": parent_item.id, "item_number": parent_item.item_number,
                       "name": parent_item.name, "item_type": parent_item.item_type,
                       "revision": parent_revision.revision_code,
                       "revision_state": parent_revision.state,
                       "find_number": occurrence.find_number,
                       "quantity": occurrence.quantity}
            next_path = path_up + [segment]
            next_multiplier = multiplier * occurrence.quantity
            if parent_item.item_type == "MAIN PRODUCT":
                parents_root_first = list(reversed(next_path))
                target = {"item_id": item.id, "item_number": item.item_number,
                          "name": item.name, "item_type": item.item_type}
                visible_path = [{key: value for key, value in parents_root_first[0].items()
                                 if key not in {"find_number", "quantity"}}]
                for index, parent in enumerate(parents_root_first):
                    child = parents_root_first[index + 1] if index + 1 < len(parents_root_first) else target
                    visible_path.append({key: value for key, value in child.items()
                                         if key not in {"find_number", "quantity"}} | {
                        "find_number": parent["find_number"], "quantity": parent["quantity"]})
                uses.append({"product": {"item_id": parent_item.id,
                                          "item_number": parent_item.item_number,
                                          "name": parent_item.name,
                                          "revision": parent_revision.revision_code,
                                          "revision_state": parent_revision.state},
                             "quantity_per_product": next_multiplier,
                             "path": visible_path})
            elif parent_item.item_type in _ASSEMBLY_TYPES:
                ascend(parent_item.id, next_multiplier, next_path, visited | {identity})

    ascend(item.id, 1.0, [], frozenset())
    uses.sort(key=lambda usage: (usage["product"]["item_number"],
                                 tuple(part.get("find_number", "") for part in usage["path"])))
    return {"item": {"id": item.id, "item_number": item.item_number,
                     "name": item.name, "item_type": item.item_type},
            "use_count": len(uses), "uses": uses}


def hierarchy(session: Session, revision_id: str) -> dict:
    root = session.get(ItemRevision, revision_id)
    if not root:
        raise DomainError("Revision not found")

    def details(revision: ItemRevision | None) -> dict:
        if not revision:
            return {}
        return {
            "scope": revision.scope_category.name if revision.scope_category else "",
            "manufacturing_process": revision.manufacturing_process.name if revision.manufacturing_process else "",
            "manufacturing_methods": revision.manufacturing_methods or "",
            "material_designation": revision.material_designation or "",
            "proprietary_classification": revision.proprietary_classification or "",
            "pdm_release_level": revision.pdm_release_level or revision.state,
            "cad_release_status": revision.cad_release_status or "",
            "unit_cost": revision.unit_cost,
            "mass": revision.mass,
            "mass_source": revision.mass_source or "",
            "manufacturer_part_number": revision.manufacturer_part_number or "",
            "purchase_reference_url": revision.purchase_reference_url or "",
            "ecn_reference": revision.ecn_reference or "",
            "supplier_name": revision.supplier_name or "",
            "lead_time": revision.lead_time or "",
            "remarks": revision.remarks or "",
            "owner": revision.item.owner or "",
        }

    def build(revision: ItemRevision, path: tuple[str, ...], mult: float, item_path: str) -> dict:
        if revision.item_id in path:
            raise DomainError("Stored assembly structure contains a cycle")
        item = revision.item
        occurrences = session.scalars(select(AssemblyOccurrence).where(
            AssemblyOccurrence.parent_revision_id == revision.id).order_by(AssemblyOccurrence.sort_order, AssemblyOccurrence.find_number)).all()
        children = []
        for occ in occurrences:
            child_revision = session.get(ItemRevision, occ.child_revision_id) if occ.child_revision_id else None
            child_path = f"{item_path}/{occ.child_item.item_number}"
            is_assembly = occ.child_item.item_type in {
                "MAIN PRODUCT", "MAIN ASSEMBLY", "SUB ASSEMBLY", "CHILD ASSEMBLY"
            }
            nested = build(child_revision, path + (revision.item_id,), mult * occ.quantity, child_path) \
                if child_revision and is_assembly else None
            children.append({"occurrence_id": occ.id, "find_number": occ.find_number,
                             "quantity": occ.quantity, "uom": occ.uom, "bom_type": occ.bom_type,
                             "path": child_path,
                             "item": {"id": occ.child_item.id, "item_number": occ.child_item.item_number,
                                      "name": occ.child_item.name, "item_type": occ.child_item.item_type},
                             "revision_id": child_revision.id if child_revision else None,
                             "revision": child_revision.revision_code if child_revision else None,
                             "state": child_revision.state if child_revision else None,
                             "engineering": details(child_revision),
                             "system_name": occ.system_name or "",
                             "coe_names": occ.coe_names or "",
                             "children": nested["children"] if nested else []})
        return {"revision_id": revision.id,
                "item": {"id": item.id, "item_number": item.item_number,
                          "name": item.name, "item_type": item.item_type},
                "revision": revision.revision_code, "iteration": revision.iteration,
                "state": revision.state, "engineering": details(revision),
                "quantity_from_root": mult, "children": children}

    return build(root, (), 1.0, root.item.item_number)


def multilevel_bom(session: Session, revision_id: str) -> list[dict]:
    tree = hierarchy(session, revision_id)
    totals: dict[str, dict] = {}

    def visit(node: dict, multiplier: float = 1):
        for child in node["children"]:
            qty = multiplier * child["quantity"]
            key = child["item"]["id"]
            row = totals.setdefault(key, {**child["item"], "revision": child["revision"], "total_quantity": 0.0})
            row["total_quantity"] += qty
            if child["children"]:
                visit(child, qty)
    visit(tree)
    return sorted(totals.values(), key=lambda row: row["item_number"])

