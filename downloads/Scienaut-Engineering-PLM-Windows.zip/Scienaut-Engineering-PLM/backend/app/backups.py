from __future__ import annotations

import re
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

from sqlalchemy.engine import make_url

from app.core.config import database_url


BACKUP_PATTERN = re.compile(r"^scienaut-backup-\d{8}-\d{6}(?:-\d+)?\.sqlite3$")
REQUIRED_TABLES = {
    "items", "item_revisions", "assembly_occurrences", "alembic_version",
    "audit_events", "change_notices", "change_notice_items",
}


class BackupError(ValueError):
    pass


def live_database_path() -> Path:
    url = make_url(database_url())
    if url.get_backend_name() != "sqlite" or not url.database or url.database == ":memory:":
        raise BackupError("Backup and restore currently require a file-based SQLite database")
    return Path(url.database).resolve()


def backup_directory(db_path: Path | None = None) -> Path:
    return ((db_path or live_database_path()).parent / "Backups").resolve()


def _next_backup_path(directory: Path, when: datetime | None = None) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    stamp = (when or datetime.now()).strftime("%Y%m%d-%H%M%S")
    base = f"scienaut-backup-{stamp}"
    path = directory / f"{base}.sqlite3"
    suffix = 1
    while path.exists():
        path = directory / f"{base}-{suffix}.sqlite3"
        suffix += 1
    return path


def _sqlite_backup(source_path: Path, destination_path: Path) -> None:
    if not source_path.is_file():
        raise BackupError("The local database file was not found")
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with closing(sqlite3.connect(str(source_path), timeout=30)) as source:
            with closing(sqlite3.connect(str(destination_path), timeout=30)) as destination:
                source.backup(destination)
                check = destination.execute("PRAGMA integrity_check").fetchone()
                if not check or check[0] != "ok":
                    raise BackupError("SQLite could not verify the created backup")
                destination.commit()
    except sqlite3.Error as exc:
        destination_path.unlink(missing_ok=True)
        raise BackupError(f"Could not copy the SQLite database: {exc}") from exc


def create_backup(db_path: Path | None = None, directory: Path | None = None) -> dict:
    source = (db_path or live_database_path()).resolve()
    target_dir = (directory or backup_directory(source)).resolve()
    target = _next_backup_path(target_dir)
    _sqlite_backup(source, target)
    return {"name": target.name, "path": str(target), "size_bytes": target.stat().st_size,
            "created_at": datetime.fromtimestamp(target.stat().st_mtime).astimezone().isoformat()}


def list_backups(directory: Path | None = None, db_path: Path | None = None) -> list[dict]:
    target_dir = (directory or backup_directory(db_path)).resolve()
    if not target_dir.exists():
        return []
    files = [path for path in target_dir.iterdir() if path.is_file() and BACKUP_PATTERN.fullmatch(path.name)]
    files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return [{"name": path.name, "size_bytes": path.stat().st_size,
             "created_at": datetime.fromtimestamp(path.stat().st_mtime).astimezone().isoformat()}
            for path in files]


def validate_backup_file(path: Path) -> None:
    if not path.is_file() or path.name != Path(path.name).name:
        raise BackupError("Backup file was not found")
    try:
        with closing(sqlite3.connect(f"file:{path.as_posix()}?mode=ro", uri=True, timeout=15)) as connection:
            integrity = connection.execute("PRAGMA integrity_check").fetchone()
            if not integrity or integrity[0] != "ok":
                raise BackupError("Backup failed SQLite integrity validation")
            foreign_key_errors = connection.execute("PRAGMA foreign_key_check").fetchall()
            if foreign_key_errors:
                raise BackupError("Backup contains broken item or BOM references")
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            missing = REQUIRED_TABLES - tables
            if missing:
                raise BackupError(f"Backup is missing required PLM data tables: {', '.join(sorted(missing))}")
    except sqlite3.Error as exc:
        raise BackupError(f"Could not read this backup: {exc}") from exc


def restore_backup(name: str, db_path: Path | None = None, directory: Path | None = None) -> dict:
    if not BACKUP_PATTERN.fullmatch(name):
        raise BackupError("Choose a backup from the local backup list")
    target_db = (db_path or live_database_path()).resolve()
    target_dir = (directory or backup_directory(target_db)).resolve()
    source = (target_dir / name).resolve()
    if source.parent != target_dir or not source.is_file():
        raise BackupError("Backup file was not found in the local backup folder")
    validate_backup_file(source)
    safety = create_backup(target_db, target_dir)
    try:
        with closing(sqlite3.connect(str(source), timeout=30)) as backup_connection:
            with closing(sqlite3.connect(str(target_db), timeout=30)) as live_connection:
                backup_connection.backup(live_connection)
                integrity = live_connection.execute("PRAGMA integrity_check").fetchone()
                if not integrity or integrity[0] != "ok":
                    raise BackupError("Restored database failed the integrity check")
                live_connection.commit()
    except (sqlite3.Error, BackupError) as exc:
        safety_path = target_dir / safety["name"]
        try:
            _sqlite_backup(safety_path, target_db)
        except BackupError as recovery_error:
            raise BackupError(
                f"Restore failed and automatic recovery also failed. The safety backup "
                f"{safety['name']} is preserved for manual restore. Details: {recovery_error}"
            ) from exc
        raise BackupError(
            f"Restore did not complete. The database was recovered from safety backup {safety['name']}."
        ) from exc
    return {"restored": name, "safety_backup": safety["name"]}
