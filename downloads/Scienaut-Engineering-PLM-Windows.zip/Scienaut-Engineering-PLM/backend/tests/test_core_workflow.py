import os
import tempfile
import unittest
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, event, inspect, select
from sqlalchemy.orm import Session

from app.db import Base
from app.backups import create_backup, list_backups, restore_backup
from app.models import AssemblyOccurrence, Item, ItemRevision, RevisionState
from app.documents import DocumentError, delete_document, get_document_file, list_documents, save_document
from app.schemas import BomImportRow, ChangeNoticeCreate, ChangeNoticeItemCreate
from app.services import (DomainError, add_occurrence, create_item, ensure_masters,
                          audit_history, compare_revisions, create_change_notice,
                          create_working_revision, hierarchy, import_bom_rows, multilevel_bom, release_revision,
                          transition_change_notice, update_revision_data, where_used)


class CoreWorkflowTests(unittest.TestCase):
    def setUp(self):
        backend_dir = Path(__file__).resolve().parents[1]
        handle, self.db_path = tempfile.mkstemp(suffix=".sqlite3", dir=backend_dir)
        os.close(handle)
        alembic_cfg = Config(str(backend_dir / "alembic.ini"))
        alembic_cfg.set_main_option("script_location", str(backend_dir / "migrations"))
        alembic_cfg.set_main_option("sqlalchemy.url", f"sqlite:///{self.db_path.replace(os.sep, '/')}")
        self.engine = create_engine(f"sqlite:///{self.db_path.replace(os.sep, '/')}", connect_args={"check_same_thread": False})
        @event.listens_for(self.engine, "connect")
        def fk_on(connection, _):
            connection.execute("PRAGMA foreign_keys=ON")
        Base.metadata.create_all(self.engine)
        command.upgrade(alembic_cfg, "head")
        self.session = Session(self.engine, expire_on_commit=False)
        ensure_masters(self.session)

    def tearDown(self):
        self.session.close()
        self.engine.dispose()
        os.unlink(self.db_path)

    def make(self, number, name, kind, **kwargs):
        return create_item(self.session, item_number=number, name=name, item_type=kind, **kwargs)

    def test_demo_multilevel_workflow_reuse_and_quantity_rollup(self):
        root, root_rev = self.make("DEMO-001", "Workshop Demonstrator", "MAIN PRODUCT")
        conveyor, conveyor_rev = self.make("DEMO-ASM-001", "Conveyor Assembly", "MAIN ASSEMBLY")
        drive, drive_rev = self.make("DEMO-SUB-001", "Drive Subassembly", "SUB ASSEMBLY")
        mount, mount_rev = self.make("DEMO-SUB-002", "Motor Mount Child Assembly", "CHILD ASSEMBLY")
        bracket, bracket_rev = self.make("DEMO-PRT-001", "Motor Bracket", "PART", scope="In-house Manufacturing", manufacturing_process="Machining", mass=2.5, mass_source="USER_ENTERED", unit_cost=20)
        gearbox, gearbox_rev = self.make("DEMO-BO-001", "Gearbox", "BOUGHT-OUT COMPONENT", scope="Vendor", unit_cost=150)
        bolt, bolt_rev = self.make("DEMO-FST-001", "M6 Bolt", "FASTENER", scope="Fasteners", unit_cost=0.2)
        add_occurrence(self.session, parent_revision_id=root_rev.id, child_item_id=conveyor.id, child_revision_id=conveyor_rev.id, find_number="10", quantity=1)
        add_occurrence(self.session, parent_revision_id=conveyor_rev.id, child_item_id=drive.id, child_revision_id=drive_rev.id, find_number="10", quantity=2)
        add_occurrence(self.session, parent_revision_id=drive_rev.id, child_item_id=mount.id, child_revision_id=mount_rev.id, find_number="10", quantity=1)
        add_occurrence(self.session, parent_revision_id=drive_rev.id, child_item_id=gearbox.id, child_revision_id=gearbox_rev.id, find_number="20", quantity=1)
        add_occurrence(self.session, parent_revision_id=mount_rev.id, child_item_id=bracket.id, child_revision_id=bracket_rev.id, find_number="10", quantity=1)
        add_occurrence(self.session, parent_revision_id=mount_rev.id, child_item_id=bolt.id, child_revision_id=bolt_rev.id, find_number="20", quantity=4)
        add_occurrence(self.session, parent_revision_id=drive_rev.id, child_item_id=bolt.id, child_revision_id=bolt_rev.id, find_number="30", quantity=2)
        tree = hierarchy(self.session, root_rev.id)
        self.assertEqual(tree["children"][0]["item"]["item_number"], "DEMO-ASM-001")
        rows = {row["item_number"]: row["total_quantity"] for row in multilevel_bom(self.session, root_rev.id)}
        self.assertEqual(rows["DEMO-PRT-001"], 2)
        self.assertEqual(rows["DEMO-BO-001"], 2)
        self.assertEqual(rows["DEMO-FST-001"], 12)
        with self.assertRaises(DomainError):
            self.make("DEMO-PRT-001", "Duplicate", "PART")

    def test_cycle_is_rejected(self):
        first, first_rev = self.make("ASM-1", "First", "MAIN ASSEMBLY")
        second, second_rev = self.make("ASM-2", "Second", "SUB ASSEMBLY")
        add_occurrence(self.session, parent_revision_id=first_rev.id, child_item_id=second.id,
                       child_revision_id=second_rev.id, find_number="1", quantity=1)
        with self.assertRaisesRegex(DomainError, "circular"):
            add_occurrence(self.session, parent_revision_id=second_rev.id, child_item_id=first.id,
                           child_revision_id=first_rev.id, find_number="1", quantity=1)

    def test_release_requires_child_release_then_freezes_parent(self):
        parent, parent_rev = self.make("ASM-1", "Parent", "MAIN ASSEMBLY")
        child, child_rev = self.make("PART-1", "Child", "PART")
        add_occurrence(self.session, parent_revision_id=parent_rev.id, child_item_id=child.id,
                       child_revision_id=child_rev.id, find_number="1", quantity=1)
        with self.assertRaisesRegex(DomainError, "released child revision"):
            release_revision(self.session, parent_rev.id)
        release_revision(self.session, child_rev.id)
        release_revision(self.session, parent_rev.id)
        with self.assertRaisesRegex(DomainError, "in-work parent"):
            add_occurrence(self.session, parent_revision_id=parent_rev.id, child_item_id=child.id,
                           find_number="2", quantity=1)
        parent_rev.description = "mutated"
        with self.assertRaises(Exception):
            self.session.commit()
        self.session.rollback()

    def test_new_working_revision_copies_revision_data_and_exact_bom_relationships(self):
        assembly, assembly_rev = self.make("CLONE-ASM", "Clone Assembly", "MAIN ASSEMBLY")
        assembly_rev.remarks = "Keep note"
        self.session.commit()
        part, part_rev = self.make("CLONE-PART", "Child Part", "PART")
        add_occurrence(self.session, parent_revision_id=assembly_rev.id, child_item_id=part.id,
                       child_revision_id=part_rev.id, find_number="20", quantity=3, system_name="MECHANICAL SYSTEM")
        release_revision(self.session, part_rev.id)
        release_revision(self.session, assembly_rev.id)
        new_revision = create_working_revision(self.session, assembly.id, revision_code="B",
                                               change_reason="Improve bracket")
        self.assertEqual(new_revision.remarks, "Keep note")
        self.assertEqual(new_revision.change_reason, "Improve bracket")
        copied = self.session.scalar(select(AssemblyOccurrence).where(
            AssemblyOccurrence.parent_revision_id == new_revision.id))
        self.assertEqual((copied.child_item_id, copied.child_revision_id, copied.find_number,
                          copied.quantity, copied.system_name),
                         (part.id, part_rev.id, "20", 3, "MECHANICAL SYSTEM"))
        with self.assertRaisesRegex(DomainError, "current in-work revision"):
            create_working_revision(self.session, assembly.id, revision_code="C")

    def test_excel_bom_import_preserves_level_relationships_and_rolls_back_conflicts(self):
        root, root_rev = self.make("IMPORT-ROOT", "Import Root", "MAIN PRODUCT")
        result = import_bom_rows(self.session, root_rev.id, [
            BomImportRow(source_row=7, level=2, item_number="IMPORT-ASM", name="Drive Assembly",
                         classification="Assy", quantity=1),
            BomImportRow(source_row=8, level=3, item_number="IMPORT-PART", name="Bracket",
                         classification="PARTS", quantity=2),
        ])
        self.assertEqual(result, {"created_items": 2, "linked_occurrences": 2})
        tree = hierarchy(self.session, root_rev.id)
        assembly_node = tree["children"][0]
        self.assertEqual(assembly_node["item"]["item_number"], "IMPORT-ASM")
        self.assertEqual(assembly_node["children"][0]["item"]["item_number"], "IMPORT-PART")
        totals = {row["item_number"]: row["total_quantity"] for row in multilevel_bom(self.session, root_rev.id)}
        self.assertEqual(totals["IMPORT-PART"], 2)

        add_occurrence(self.session, parent_revision_id=root_rev.id, child_item_id=assembly_node["item"]["id"],
                       child_revision_id=assembly_node["revision_id"], find_number="100", quantity=1)
        with self.assertRaisesRegex(DomainError, "already exists"):
            import_bom_rows(self.session, root_rev.id, [
                BomImportRow(source_row=10, level=2, item_number="ROLLBACK-ITEM", name="Must Not Persist",
                             classification="PARTS", quantity=1),
            ])
        self.session.expire_all()
        self.assertIsNone(self.session.scalar(select(Item).where(Item.item_number == "ROLLBACK-ITEM")))

    def test_revision_comparison_and_audit_history_capture_relationship_changes(self):
        root, rev_a = self.make("COMPARE-ROOT", "Compare Root", "MAIN PRODUCT")
        part_a, part_a_rev = self.make("COMPARE-P1", "Part One", "PART")
        part_b, part_b_rev = self.make("COMPARE-P2", "Part Two", "PART")
        add_occurrence(self.session, parent_revision_id=rev_a.id, child_item_id=part_a.id,
                       child_revision_id=part_a_rev.id, find_number="10", quantity=1)
        rev_b = ItemRevision(item_id=root.id, revision_code="B", previous_revision_id=rev_a.id,
                             description="Changed design")
        self.session.add(rev_b)
        self.session.flush()
        add_occurrence(self.session, parent_revision_id=rev_b.id, child_item_id=part_b.id,
                       child_revision_id=part_b_rev.id, find_number="10", quantity=2)
        update_revision_data(self.session, rev_b.id, {"manufacturer_part_number": "UPDATED-MPN"})

        comparison = compare_revisions(self.session, rev_a.id, rev_b.id)
        self.assertEqual(comparison["left"]["revision_code"], "A")
        self.assertEqual(comparison["right"]["revision_code"], "B")
        self.assertEqual(len(comparison["bom_changes"]["added"]), 1)
        self.assertEqual(len(comparison["bom_changes"]["removed"]), 1)
        self.assertIn("manufacturer_part_number", {row["field"] for row in comparison["metadata_changes"]})
        events = audit_history(self.session)
        self.assertTrue(any(event["action"] == "UPDATED" for event in events))
        self.assertTrue(any(event["action"] == "ADDED" for event in events))

    def test_audit_migration_preserves_existing_item_data(self):
        handle, path = tempfile.mkstemp(suffix=".sqlite3", dir=Path(__file__).resolve().parents[1])
        os.close(handle)
        url = f"sqlite:///{path.replace(os.sep, '/')}"
        engine = create_engine(url)
        try:
            Base.metadata.create_all(engine)
            with engine.begin() as connection:
                connection.exec_driver_sql("INSERT INTO items (id, item_number, name, item_type, created_at, modified_at) VALUES ('keep-id', 'KEEP-001', 'Keep me', 'PART', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)")
                connection.exec_driver_sql("DROP TABLE audit_events")
                connection.exec_driver_sql("CREATE TABLE alembic_version (version_num VARCHAR(32) NOT NULL)")
                connection.exec_driver_sql("INSERT INTO alembic_version (version_num) VALUES ('0002_template_entry_fields')")
            backend_dir = Path(__file__).resolve().parents[1]
            config = Config(str(backend_dir / "alembic.ini"))
            config.set_main_option("script_location", str(backend_dir / "migrations"))
            config.set_main_option("sqlalchemy.url", url)
            command.upgrade(config, "head")
            self.assertIn("audit_events", inspect(engine).get_table_names())
            with engine.connect() as connection:
                self.assertEqual(connection.scalar(select(Item.item_number).where(Item.id == "keep-id")), "KEEP-001")
        finally:
            engine.dispose()
            os.unlink(path)

    def test_engineering_document_migration_adds_storage_without_losing_items(self):
        handle, path = tempfile.mkstemp(suffix=".sqlite3", dir=Path(__file__).resolve().parents[1])
        os.close(handle)
        url = f"sqlite:///{path.replace(os.sep, '/')}"
        backend_dir = Path(__file__).resolve().parents[1]
        config = Config(str(backend_dir / "alembic.ini"))
        config.set_main_option("script_location", str(backend_dir / "migrations"))
        config.set_main_option("sqlalchemy.url", url)
        engine = create_engine(url)
        prior_database_url = os.environ.get("ENGINEERING_PLM_DATABASE_URL")
        os.environ["ENGINEERING_PLM_DATABASE_URL"] = url
        try:
            command.upgrade(config, "0004_change_notices")
            with engine.begin() as connection:
                connection.exec_driver_sql("INSERT INTO items (id, item_number, name, item_type, created_at, modified_at) VALUES ('legacy-doc-id', 'LEGACY-DOC', 'Legacy item', 'PART', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)")
            self.assertNotIn("engineering_documents", inspect(engine).get_table_names())
            command.upgrade(config, "head")
            columns = {column["name"] for column in inspect(engine).get_columns("engineering_documents")}
            self.assertIn("data_bytes", columns)
            with engine.connect() as connection:
                self.assertEqual(connection.scalar(select(Item.item_number).where(Item.id == "legacy-doc-id")), "LEGACY-DOC")
        finally:
            if prior_database_url is None:
                os.environ.pop("ENGINEERING_PLM_DATABASE_URL", None)
            else:
                os.environ["ENGINEERING_PLM_DATABASE_URL"] = prior_database_url
            engine.dispose()
            os.unlink(path)

    def test_change_notice_requires_scope_and_a_released_change(self):
        item, revision = self.make("ECN-PART", "ECN Part", "PART")
        notice = create_change_notice(self.session, ChangeNoticeCreate(
            ecn_number="ECN-TEST-001", title="Improve bracket strength",
            reason="The current bracket has insufficient load margin.",
            affected_items=[ChangeNoticeItemCreate(item_id=item.id,
                                                   change_description="Increase bracket thickness")],
        ))
        self.assertEqual(notice["status"], "DRAFT")
        notice = transition_change_notice(self.session, notice["id"], "IN REVIEW")
        notice = transition_change_notice(self.session, notice["id"], "APPROVED")
        with self.assertRaisesRegex(DomainError, "no released revision"):
            transition_change_notice(self.session, notice["id"], "IMPLEMENTED")
        release_revision(self.session, revision.id)
        notice = transition_change_notice(self.session, notice["id"], "IMPLEMENTED")
        self.assertEqual(notice["status"], "IMPLEMENTED")
        with self.assertRaisesRegex(DomainError, "cannot move"):
            transition_change_notice(self.session, notice["id"], "DRAFT")

    def test_where_used_traces_reused_parts_and_rolls_quantity_to_each_product(self):
        root, root_rev = self.make("WHERE-ROOT", "Where Root", "MAIN PRODUCT")
        assembly_a, rev_a = self.make("WHERE-A", "Assembly A", "MAIN ASSEMBLY")
        assembly_b, rev_b = self.make("WHERE-B", "Assembly B", "SUB ASSEMBLY")
        part, part_rev = self.make("WHERE-PART", "Shared Bearing", "PART")
        add_occurrence(self.session, parent_revision_id=root_rev.id, child_item_id=assembly_a.id,
                       child_revision_id=rev_a.id, find_number="10", quantity=2)
        add_occurrence(self.session, parent_revision_id=root_rev.id, child_item_id=assembly_b.id,
                       child_revision_id=rev_b.id, find_number="20", quantity=3)
        add_occurrence(self.session, parent_revision_id=rev_a.id, child_item_id=part.id,
                       child_revision_id=part_rev.id, find_number="10", quantity=4)
        add_occurrence(self.session, parent_revision_id=rev_b.id, child_item_id=part.id,
                       child_revision_id=part_rev.id, find_number="10", quantity=1)
        add_occurrence(self.session, parent_revision_id=root_rev.id, child_item_id=part.id,
                       child_revision_id=part_rev.id, find_number="30", quantity=1)

        result = where_used(self.session, part.id)
        self.assertEqual(result["use_count"], 3)
        self.assertEqual(sorted(use["quantity_per_product"] for use in result["uses"]), [1, 3, 8])
        self.assertTrue(all(use["path"][0]["item_number"] == root.item_number for use in result["uses"]))

    def test_engineering_documents_are_revision_linked_checksummed_and_backup_ready(self):
        item, revision = self.make("DOC-PART", "Drawing Part", "PART")
        payload = b"sample engineering drawing bytes"
        document = save_document(self.session, item.id, "..\\released drawing.pdf", payload,
                                 "application/pdf", "Released manufacturing drawing", revision.id)
        self.assertEqual(document["original_name"], "released drawing.pdf")
        self.assertEqual(document["revision_code"], "A")
        self.assertEqual(document["size_bytes"], len(payload))
        self.assertEqual(len(document["sha256"]), 64)
        self.assertEqual(len(list_documents(self.session, item.id)), 1)
        content, filename, media_type = get_document_file(self.session, document["id"])
        self.assertEqual((content, filename, media_type), (payload, "released drawing.pdf", "application/pdf"))
        delete_document(self.session, document["id"])
        self.assertEqual(list_documents(self.session, item.id), [])
        with self.assertRaisesRegex(DocumentError, "not found"):
            get_document_file(self.session, document["id"])
        with self.assertRaisesRegex(DocumentError, "not supported"):
            save_document(self.session, item.id, "unsafe.exe", b"bad", "application/octet-stream")

    def test_backup_restore_keeps_snapshot_and_creates_safety_copy(self):
        self.make("BACKUP-KEEP", "Saved Item", "PART")
        backup_dir = Path(self.db_path).parent / f"{Path(self.db_path).stem}-Backups"
        backup = create_backup(Path(self.db_path), backup_dir)
        self.make("BACKUP-LATER", "Later Item", "PART")
        self.session.close()

        restored = restore_backup(backup["name"], Path(self.db_path), backup_dir)
        self.session = Session(self.engine, expire_on_commit=False)
        numbers = set(self.session.scalars(select(Item.item_number)).all())
        self.assertIn("BACKUP-KEEP", numbers)
        self.assertNotIn("BACKUP-LATER", numbers)
        self.assertNotEqual(restored["safety_backup"], backup["name"])
        self.assertEqual(len(list_backups(backup_dir)), 2)


if __name__ == "__main__":
    unittest.main()
