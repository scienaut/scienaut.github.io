"""Run the loopback API and Vite UI together; Ctrl+C stops both processes."""
from __future__ import annotations

import os
import subprocess
import sys
import socket
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path


BACKEND = Path(__file__).resolve().parents[1]
PROJECT = BACKEND.parent
FRONTEND = PROJECT / "frontend"
DATA_ROOT = Path(os.environ.get("ENGINEERING_PLM_DATA_ROOT", PROJECT / "local_data"))
LOG_DIR = DATA_ROOT / "Logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)


def ready(url: str, process: subprocess.Popen, label: str, timeout: float = 35) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(f"{label} stopped during startup. Check {LOG_DIR} logs.")
        try:
            with urllib.request.urlopen(url, timeout=1) as response:
                if response.status < 400:
                    return
        except (urllib.error.URLError, TimeoutError):
            time.sleep(0.35)
    raise RuntimeError(f"{label} did not become ready. Check {LOG_DIR} logs.")


def available_port(start: int, stop: int) -> int:
    for port in range(start, stop):
        with socket.socket() as candidate:
            try:
                candidate.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError(f"No free local port found in range {start}-{stop - 1}")


def main() -> int:
    env = os.environ.copy()
    backend_log = (LOG_DIR / "backend.log").open("a", encoding="utf-8")
    frontend_log = (LOG_DIR / "frontend.log").open("a", encoding="utf-8")
    processes: list[subprocess.Popen] = []
    api_port = available_port(8765, 8780)
    ui_port = available_port(5173, 5190)
    env["VITE_API_TARGET"] = f"http://127.0.0.1:{api_port}"
    try:
        api = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", str(api_port)],
            cwd=BACKEND, env=env, stdout=backend_log, stderr=subprocess.STDOUT,
        )
        processes.append(api)
        ui = subprocess.Popen(
            ["cmd", "/c", f"npm run dev -- --host 127.0.0.1 --port {ui_port} --strictPort"],
            cwd=FRONTEND, env=env, stdout=frontend_log, stderr=subprocess.STDOUT,
        )
        processes.append(ui)
        ready(f"http://127.0.0.1:{api_port}/api/v1/health", api, "Local API")
        ready(f"http://127.0.0.1:{ui_port}", ui, "Engineering workspace")
        print(f"Scienaut Engineering PLM Solutions is running at http://127.0.0.1:{ui_port}")
        print(f"Local API docs are at http://127.0.0.1:{api_port}/api/v1/docs")
        print(f"Logs: {LOG_DIR}")
        webbrowser.open(f"http://127.0.0.1:{ui_port}")
        while all(process.poll() is None for process in processes):
            time.sleep(0.5)
        raise RuntimeError("A local app service stopped. Check the logs directory for details.")
    except KeyboardInterrupt:
        print("Stopping local application…")
        return 0
    except Exception as exc:
        print(f"Could not start the local application: {exc}")
        return 1
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
        for process in reversed(processes):
            if process.poll() is None:
                try:
                    process.wait(timeout=6)
                except subprocess.TimeoutExpired:
                    process.kill()
        backend_log.close()
        frontend_log.close()


if __name__ == "__main__":
    raise SystemExit(main())
