"""Create a small, synthetic engineering BOM in local SQLite for new databases."""
from sqlalchemy import select

from app.db import SessionLocal
from app.models import Item
from app.services import add_occurrence, create_item, ensure_masters


def seed():
    with SessionLocal() as session:
        ensure_masters(session)
        if session.scalar(select(Item.id).where(Item.item_type == "MAIN PRODUCT")):
            print("A product already exists; leaving the existing workspace unchanged")
            return
        def make(number, name, kind, **kwargs):
            return create_item(session, item_number=number, name=name, item_type=kind, **kwargs)
        product, product_r = make("DEMO-001", "Workshop Demonstrator", "MAIN PRODUCT")
        conveyor, conveyor_r = make("DEMO-ASM-001", "Conveyor Assembly", "MAIN ASSEMBLY")
        drive, drive_r = make("DEMO-SUB-001", "Drive Subassembly", "SUB ASSEMBLY")
        mount, mount_r = make("DEMO-CHD-001", "Motor Mount Child Assembly", "CHILD ASSEMBLY")
        bracket, bracket_r = make("DEMO-PRT-001", "Motor Bracket", "PART", scope="In-house Manufacturing", manufacturing_process="Machining", mass=2.5, mass_source="USER_ENTERED", unit_cost=20)
        plate, plate_r = make("DEMO-PRT-002", "Mounting Plate", "PART", scope="In-house Manufacturing", manufacturing_process="Sheet Metal", mass=1.2, mass_source="USER_ENTERED", unit_cost=12)
        gearbox, gearbox_r = make("DEMO-BO-001", "Gearbox", "BOUGHT-OUT COMPONENT", scope="Vendor", unit_cost=150)
        bolt, bolt_r = make("DEMO-FST-001", "M6 Bolt", "FASTENER", scope="Fasteners", unit_cost=0.2)
        nut, nut_r = make("DEMO-FST-002", "M6 Nut", "FASTENER", scope="Fasteners", unit_cost=0.1)
        uses = [(product_r, conveyor, conveyor_r, "10", 1),
                (conveyor_r, drive, drive_r, "10", 2),
                (drive_r, mount, mount_r, "10", 1),
                (drive_r, gearbox, gearbox_r, "20", 1),
                (mount_r, bracket, bracket_r, "10", 1),
                (mount_r, plate, plate_r, "20", 1),
                (mount_r, bolt, bolt_r, "30", 4),
                (mount_r, nut, nut_r, "40", 4),
                (drive_r, bolt, bolt_r, "30", 2)]
        for parent_r, child, child_r, find, qty in uses:
            add_occurrence(session, parent_revision_id=parent_r.id, child_item_id=child.id,
                           child_revision_id=child_r.id, find_number=find, quantity=qty)
        print("Created a generic demonstrator BOM. Sample mass/cost values are illustrative, not engineering references.")


if __name__ == "__main__":
    seed()
