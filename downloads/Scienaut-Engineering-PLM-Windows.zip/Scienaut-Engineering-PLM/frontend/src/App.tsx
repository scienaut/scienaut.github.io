import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import * as XLSX from 'xlsx'
import {
  BookOpen, Boxes, BoxSelect, ChevronDown, ChevronRight, ClipboardList, Component,
  Database, Download, FileBox, FileDown, FileSpreadsheet, FileText, FolderTree, Gauge, GitBranch,
  Layers3, LayoutDashboard, Network, Package, Plus, Search, Settings2, ShieldCheck,
  Trash2, Upload, X,
} from 'lucide-react'

type Revision = { id: string; revision_code: string; iteration: number; state: string }
type Item = { id: string; item_number: string; name: string; item_type: string; revisions: Revision[] }
type TreeNode = {
  revision_id: string | null
  item: { id: string; item_number: string; name: string; item_type: string }
  revision: string | null
  state?: string
  quantity?: number
  uom?: string
  occurrence_id?: string
  find_number?: string
  path?: string
  system_name?: string
  coe_names?: string
  engineering?: {
    owner?: string
    scope?: string
    manufacturing_process?: string
    manufacturing_methods?: string
    material_designation?: string
    proprietary_classification?: string
    pdm_release_level?: string
    cad_release_status?: string
    unit_cost?: number | null
    mass?: number | null
    mass_source?: string
    manufacturer_part_number?: string
    purchase_reference_url?: string
    ecn_reference?: string
    supplier_name?: string
    lead_time?: string
    remarks?: string
  }
  children: TreeNode[]
}
type View = 'overview' | 'structure' | 'items' | 'bom' | 'mindmap' | 'revisions' | 'changes' | 'whereused' | 'backups' | 'documents' | 'manual'
type AuditRow = {id: string; item_number?: string; item_name?: string; revision_code?: string; action: string; field_name?: string; old_value?: string; new_value?: string; summary: string; actor: string; created_at?: string}
type ChangeNotice = {id: string; ecn_number: string; title: string; reason: string; status: string; created_at?: string; affected_items: {id: string; item_id: string; item_number: string; item_name: string; item_type: string; baseline_revision?: string; change_description: string}[]}
type WhereUsedResult = {
  item: {item_number: string; name: string; item_type: string}; use_count: number;
  uses: {product: {item_number: string; name: string; revision: string; revision_state: string}; quantity_per_product: number;
    path: {item_number: string; name: string; item_type?: string; revision?: string; revision_state?: string; find_number?: string; quantity?: number}[]}[]
}
type BackupInfo = {name: string; size_bytes: number; created_at: string}
type EngineeringDocument = {id: string; item_id: string; revision_id?: string | null; revision_code?: string | null; original_name: string; media_type: string; size_bytes: number; sha256: string; description?: string | null; created_at: string}
type ExcelImportRow = {
  source_row: number; level: number; find_number?: string; item_number: string; name: string; revision_code?: string;
  item_type?: string; classification?: string; quantity: number; uom?: string; system_name?: string;
  coe_names?: string; scope?: string; material_designation?: string; manufacturing_methods?: string;
  pdm_release_level?: string; cad_release_status?: string; unit_cost?: number | null;
  manufacturer_part_number?: string; purchase_reference_url?: string; mass?: number | null;
  ecn_reference?: string; remarks?: string; supplier_name?: string; lead_time?: string;
}

const api = '/api/v1'
const kinds = ['MAIN PRODUCT', 'MAIN ASSEMBLY', 'SUB ASSEMBLY', 'CHILD ASSEMBLY', 'PART', 'STANDARD COMPONENT', 'FASTENER', 'BOUGHT-OUT COMPONENT']
const scopes = ['Vendor', 'Company E-Kit', 'Company Bought Out', 'Fasteners', 'In-house Manufacturing', 'Customer Supplied', 'Standard Purchased Components']
const processes = ['Machining', 'Turning', 'Milling', 'Drilling', 'Sheet Metal', 'Laser cutting', 'Bending', 'Welding', 'Assembly', 'Inspection']
const manufacturingMethods = [...processes, 'Fabrication', 'Sheetmetal', 'Mech_Bought out', 'Fasteners']
const proprietaryClassifications = ['MAIN ASSY', 'ASSEMBLY', 'CHILD ASSEMBLY', 'PARTS', 'MOTORS / ACTUATORS', 'SENSORS', 'GASKETS', 'Child Part', 'STD part', 'Software', 'Miscellaneous (Consumables)']
const systemNames = ['MECHANICAL SYSTEM', 'ELECTRICAL/ELECTRONICS', 'AI SYSTEM', 'QA SYSTEM', 'PRODUCT MANAGEMENT']

function normalizeClassification(value: string) {
  const key = value.trim().toLowerCase()
  if (key === 'assy' || key === 'assembly') return 'ASSEMBLY'
  if (key === 'part' || key === 'parts') return 'PARTS'
  return value
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${api}${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
  })
  if (!response.ok) {
    const body = await response.json().catch(() => null)
    throw new Error(body?.detail || `Request failed (${response.status})`)
  }
  return response.status === 204 ? undefined as T : response.json()
}

function App() {
  const [view, setView] = useState<View>('structure')
  const [items, setItems] = useState<Item[]>([])
  const [tree, setTree] = useState<TreeNode | null>(null)
  const [customClassifications, setCustomClassifications] = useState<string[]>([])
  const [customSystemNames, setCustomSystemNames] = useState<string[]>(() => {
    try {
      const saved: unknown = JSON.parse(localStorage.getItem('scienaut-custom-system-names') ?? '[]')
      return Array.isArray(saved) ? saved.filter((value): value is string => typeof value === 'string') : []
    } catch { return [] }
  })
  const [selected, setSelected] = useState<TreeNode | null>(null)
  const [activeProductId, setActiveProductId] = useState(() => {
    try { return localStorage.getItem('engineering-plm-active-product') ?? '' } catch { return '' }
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [showCreateItem, setShowCreateItem] = useState(false)
  const [showExisting, setShowExisting] = useState(false)
  const [showExportOptions, setShowExportOptions] = useState(false)
  const [showNewProject, setShowNewProject] = useState(false)
  const [showDeleteWorkspace, setShowDeleteWorkspace] = useState(false)
  const [showExcelImport, setShowExcelImport] = useState(false)
  const [dark, setDark] = useState(false)
  const [treeQuery, setTreeQuery] = useState('')

  const refreshItems = useCallback(async () => {
    const rows = await request<Item[]>('/items')
    setItems(rows)
    return rows
  }, [])

  const refreshCustomClassifications = useCallback(async () => {
    const values = await request<string[]>('/options/proprietary-classifications')
    setCustomClassifications(values)
  }, [])

  const refreshSystemNames = useCallback(async () => {
    const values = await request<string[]>('/options/system-names')
    setCustomSystemNames((current) => {
      const next = [...new Set([...current, ...values])]
      try { localStorage.setItem('scienaut-custom-system-names', JSON.stringify(next)) } catch { /* Database-backed options remain available next time. */ }
      return next
    })
  }, [])

  const loadRoot = useCallback(async (rows?: Item[], preferredProductId?: string) => {
    const data = rows ?? await refreshItems()
    const products = data.filter((item) => item.item_type === 'MAIN PRODUCT')
    const preferredId = preferredProductId ?? activeProductId
    const product = products.find((item) => item.id === preferredId)
      ?? data.find((item) => item.item_type === 'MAIN PRODUCT')
    if (!product || product.revisions.length === 0) {
      setTree(null)
      setSelected(null)
      setActiveProductId('')
      try { localStorage.removeItem('engineering-plm-active-product') } catch { /* No active product selection is still valid for this session. */ }
      return
    }
    const revision = product.revisions[0]
    const hierarchy = await request<TreeNode>(`/revisions/${revision.id}/hierarchy`)
    setTree(hierarchy)
    setActiveProductId(product.id)
    try { localStorage.setItem('engineering-plm-active-product', product.id) } catch { /* The current session remains usable without browser storage. */ }
    setSelected((current) => current ? findNode(hierarchy, current.item.id) ?? hierarchy : hierarchy)
  }, [activeProductId, refreshItems])

  const refresh = useCallback(async () => {
    setError('')
    try {
      const rows = await refreshItems()
      await loadRoot(rows)
      await Promise.all([refreshCustomClassifications(), refreshSystemNames()])
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not load local engineering data')
    }
  }, [loadRoot, refreshItems, refreshCustomClassifications, refreshSystemNames])

  useEffect(() => {
    void (async () => {
      try {
        const rows = await refreshItems()
        await loadRoot(rows)
        await Promise.all([refreshCustomClassifications(), refreshSystemNames()])
      } catch (reason) {
        setError(reason instanceof Error ? reason.message : 'Could not connect to the local PLM service')
      } finally {
        setLoading(false)
      }
    })()
  }, [loadRoot, refreshItems, refreshCustomClassifications, refreshSystemNames])

  const filteredItems = useMemo(() => items.filter((item) =>
    `${item.item_number} ${item.name} ${item.item_type}`.toLowerCase().includes(search.toLowerCase())), [items, search])
  const assemblyCount = items.filter((item) => item.item_type.includes('ASSEMBLY') || item.item_type === 'MAIN PRODUCT').length
  const canEditBom = Boolean(selected && isAssembly(selected.item.item_type) && selected.state === 'IN WORK')
  const products = items.filter((item) => item.item_type === 'MAIN PRODUCT')

  function rememberCustomSystem(value: string) {
    const name = value.trim()
    if (!name) return
    setCustomSystemNames((current) => {
      const next = [...new Set([...current, name])]
      try { localStorage.setItem('scienaut-custom-system-names', JSON.stringify(next)) } catch { /* Keep it in this session if browser storage is unavailable. */ }
      return next
    })
  }

  async function selectProduct(itemId: string) {
    setLoading(true)
    setError('')
    try {
      const rows = await refreshItems()
      await loadRoot(rows, itemId)
      setView('structure')
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not open product BOM')
    } finally { setLoading(false) }
  }

  async function createProject(itemNumber: string, name: string) {
    const created = await request<{item: {id: string; item_number: string; name: string}; revision: {id: string}}>('/items', {
      method: 'POST', body: JSON.stringify({ item_number: itemNumber, name, item_type: 'MAIN PRODUCT', revision_code: 'A' }),
    })
    const rows = await refreshItems()
    await loadRoot(rows, created.item.id)
    setView('structure')
    setShowNewProject(false)
    setNotice(`Product BOM created for ${created.item.name}`)
  }

  async function deleteCurrentProduct() {
    if (!tree) return
    const productName = tree.item.name
    try {
      await request(`/items/${tree.item.id}`, { method: 'DELETE' })
      const rows = await refreshItems()
      await loadRoot(rows, '')
      setShowDeleteWorkspace(false)
      setView('structure')
      setNotice(`Deleted local Product BOM: ${productName}`)
    } catch (reason) {
      setShowDeleteWorkspace(false)
      setError(reason instanceof Error ? reason.message : 'Could not delete Product BOM')
    }
  }

  async function patchOccurrence(node: TreeNode, patch: Record<string, unknown>) {
    if (!node.occurrence_id) return
    try {
      await request(`/occurrences/${node.occurrence_id}`, { method: 'PATCH', body: JSON.stringify(patch) })
      await refresh()
      setNotice('BOM row saved')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not save BOM row') }
  }

  async function moveOccurrence(node: TreeNode, parentRevisionId: string) {
    if (!node.occurrence_id) return
    try {
      await request(`/occurrences/${node.occurrence_id}/move`, {
        method: 'PATCH', body: JSON.stringify({ parent_revision_id: parentRevisionId }),
      })
      await refresh()
      setNotice(`${node.item.name} moved to the selected BOM level`)
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not move BOM item') }
  }

  async function patchRevision(revisionId: string, patch: Record<string, unknown>) {
    try {
      await request(`/revisions/${revisionId}`, { method: 'PATCH', body: JSON.stringify(patch) })
      await refresh()
      setNotice('Engineering data saved')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not save engineering data') }
  }

  async function patchItemNumber(itemId: string, itemNumber: string) {
    try {
      await request(`/items/${itemId}`, { method: 'PATCH', body: JSON.stringify({ item_number: itemNumber }) })
      await refresh()
      setNotice('Part number corrected')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not update part number') }
  }

  async function importExcelBom(rows: ExcelImportRow[]) {
    if (!tree?.revision_id) throw new Error('Select a Product BOM before importing')
    const result = await request<{created_items: number; linked_occurrences: number}>('/bom/import', {
      method: 'POST',
      body: JSON.stringify({ root_revision_id: tree.revision_id, rows }),
    })
    await refresh()
    setShowExcelImport(false)
    setNotice(`Imported ${result.linked_occurrences} BOM rows and created ${result.created_items} item masters`)
  }

  async function addExisting(item: Item, revisionId: string, quantity: number) {
    if (!selected?.revision_id) throw new Error('Select a working assembly before adding components')
    await request('/occurrences', { method: 'POST', body: JSON.stringify({
      parent_revision_id: selected.revision_id, child_item_id: item.id, child_revision_id: revisionId,
      find_number: nextFindNumber(selected), quantity, uom: 'EA', bom_type: 'EBOM',
    }) })
    setShowAdd(false); setShowExisting(false)
    await refresh()
    setNotice(`${item.item_number} added to ${selected.item.name}`)
  }

  async function createAndAdd(payload: Record<string, unknown>, quantity: number) {
    if (!selected?.revision_id) throw new Error('Select a working assembly before adding components')
    const result = await request<{item: {id: string; item_number: string}; revision: {id: string}}>('/items', {
      method: 'POST', body: JSON.stringify(payload),
    })
    await request('/occurrences', { method: 'POST', body: JSON.stringify({
      parent_revision_id: selected.revision_id, child_item_id: result.item.id,
      child_revision_id: result.revision.id, find_number: nextFindNumber(selected), quantity,
      uom: 'EA', bom_type: 'EBOM',
    }) })
    setShowAdd(false); setShowCreateItem(false)
    await refresh()
    setNotice(`${result.item.item_number} created and added`)
  }

  async function updateQuantity(node: TreeNode, quantity: number) {
    if (!node.occurrence_id || quantity <= 0) return
    try {
      await request(`/occurrences/${node.occurrence_id}`, { method: 'PATCH', body: JSON.stringify({ quantity }) })
      await refresh()
      setNotice('BOM quantity updated')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Update failed') }
  }

  async function removeNode(node: TreeNode) {
    if (!node.occurrence_id || !window.confirm(`Remove ${node.item.item_number} from this BOM? The item master will remain.`)) return
    try {
      await request(`/occurrences/${node.occurrence_id}`, { method: 'DELETE' })
      setSelected(tree)
      await refresh()
      setNotice('BOM occurrence removed')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Remove failed') }
  }

  async function createStandalone(payload: Record<string, unknown>) {
    try {
      await request('/items', { method: 'POST', body: JSON.stringify(payload) })
      setShowCreateItem(false)
      await refresh()
      setNotice('Item created')
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not create item') }
  }

  function exportExcel() {
    if (!tree) return
    const lines: Record<string, string | number>[] = []
    function addLines(parent: TreeNode, parentMultiplier = 1) {
      for (const node of parent.children ?? []) {
        const extendedQuantity = parentMultiplier * (node.quantity ?? 0)
        lines.push({
          Level: Math.max(1, (node.path?.split('/').length ?? 1) - 1),
          'Parent Item': parent.item.item_number,
          'Find No.': node.find_number ?? '',
          'Item Number': node.item.item_number,
          'Item Name': node.item.name,
          'Item Type': node.item.item_type,
          Revision: node.revision ?? '',
          'Qty per Parent': node.quantity ?? 0,
          'Extended Qty': extendedQuantity,
          UOM: node.uom ?? 'EA',
          'BOM Type': 'EBOM',
          'Hierarchy Path': node.path ?? node.item.item_number,
        })
        addLines(node, extendedQuantity)
      }
    }
    addLines(tree)
    const book = XLSX.utils.book_new()
    const productSheet = XLSX.utils.aoa_to_sheet([
      ['Product', tree.item.name],
      ['Item Number', tree.item.item_number],
      ['Revision', tree.revision ?? ''],
      ['Revision State', tree.state ?? ''],
      ['BOM Type', 'EBOM'],
      ['Generated At', new Date().toLocaleString()],
      ['Quantity Method', 'Extended Qty multiplies each occurrence quantity along the path from the product root.'],
    ])
    productSheet['!cols'] = [{ wch: 22 }, { wch: 78 }]
    const columns = ['Level', 'Parent Item', 'Find No.', 'Item Number', 'Item Name', 'Item Type', 'Revision', 'Qty per Parent', 'Extended Qty', 'UOM', 'BOM Type', 'Hierarchy Path']
    const bomSheet = XLSX.utils.json_to_sheet(lines, { header: columns })
    bomSheet['!cols'] = [9, 18, 12, 20, 32, 24, 10, 16, 14, 10, 14, 62].map((wch) => ({ wch }))
    bomSheet['!autofilter'] = { ref: bomSheet['!ref'] ?? 'A1:L1' }
    XLSX.utils.book_append_sheet(book, productSheet, 'Product')
    XLSX.utils.book_append_sheet(book, bomSheet, 'Multi-level EBOM')
    const safeName = tree.item.item_number.replace(/[^a-zA-Z0-9_-]/g, '_')
    XLSX.writeFile(book, `${safeName}_EBOM_${tree.revision ?? 'working'}.xlsx`)
    setNotice('Excel BOM exported')
  }

  async function exportManagementExcel(templateTitle: string) {
    if (!tree?.revision_id) return
    try {
      const response = await fetch(`${api}/revisions/${tree.revision_id}/exports/engineering-management?title=${encodeURIComponent(templateTitle)}`)
      if (!response.ok) {
        const body = await response.json().catch(() => null)
        throw new Error(body?.detail || `Export failed (${response.status})`)
      }
      const blob = await response.blob()
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `${tree.item.item_number}_engineering_management.xlsx`
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.setTimeout(() => URL.revokeObjectURL(url), 1000)
      setShowExportOptions(false)
      setNotice('Engineering Management workbook exported')
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not export workbook')
    }
  }

  return (
    <div className={dark ? 'app-shell dark' : 'app-shell'}>
      <aside className="sidebar">
        <div className="brand"><div className="brand-mark"><Component size={20} /></div><div><strong>SCIENAUT</strong><span className="brand-caption">ENGINEERING PLM SOLUTIONS · OPEN SOURCE</span></div></div>
        <div className="workspace-label">WORKSPACE <ChevronDown size={14} /></div>
        <div className="workspace-card"><div className="workspace-avatar">{tree?.item.name.slice(0, 1) ?? 'P'}</div><div className="workspace-project"><select className="project-select" aria-label="Choose product BOM" value={activeProductId} onChange={(event) => void selectProduct(event.target.value)}><option value="" disabled>Select product BOM</option>{products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}</select><span>{tree?.item.item_number ?? 'Local product'}</span></div><div className="workspace-actions"><button className="new-project-mini" title="Create new Product BOM / Project" aria-label="Create new Product BOM / Project" onClick={() => setShowNewProject(true)}><Plus size={16}/></button><button className="delete-project-mini" title="Delete selected local Product BOM" aria-label="Delete selected local Product BOM" disabled={!tree} onClick={() => setShowDeleteWorkspace(true)}><Trash2 size={14}/></button></div></div>
        <div className="nav-label">ENGINEERING</div>
        <nav className="nav-list">
          <NavButton active={view === 'overview'} icon={<LayoutDashboard size={17}/>} label="Overview" onClick={() => setView('overview')} />
          <NavButton active={view === 'structure'} icon={<FolderTree size={17}/>} label="Product structure" onClick={() => setView('structure')} badge={tree ? '1' : undefined} />
          <NavButton active={view === 'mindmap'} icon={<Network size={17}/>} label="BOM mind map" onClick={() => setView('mindmap')} />
          <NavButton active={view === 'items'} icon={<Boxes size={17}/>} label="Item master" onClick={() => setView('items')} />
        <NavButton active={view === 'whereused'} icon={<Search size={17}/>} label="Where used" onClick={() => setView('whereused')} />
        </nav>
        <div className="nav-label nav-label-spaced">DATA MANAGEMENT</div>
        <NavButton active={view === 'bom'} icon={<ClipboardList size={17}/>} label="BOM data entry" onClick={() => setView('bom')} />
        <NavButton active={view === 'revisions'} icon={<GitBranch size={17}/>} label="Revisions & changes" onClick={() => setView('revisions')} />
        <NavButton active={view === 'changes'} icon={<FileBox size={17}/>} label="Change notices" onClick={() => setView('changes')} />
        <NavButton active={view === 'backups'} icon={<ShieldCheck size={17}/>} label="Backup & restore" onClick={() => setView('backups')} />
        <NavButton active={view === 'documents'} icon={<FileText size={17}/>} label="Engineering documents" onClick={() => setView('documents')} />
        <NavButton active={view === 'manual'} icon={<BookOpen size={17}/>} label="User manual" onClick={() => setView('manual')} />
        <div className="nav-static"><FileBox size={17}/> CAD vault <span className="soon-dot"/></div>
        <div className="sidebar-bottom">
          <div className="local-status"><span className="green-dot"/><div><strong>Local database</strong><span>Connected · SQLite</span></div><ShieldCheck size={16}/></div>
          <button className="profile-row" onClick={() => setDark(!dark)}><div className="profile-avatar">H</div><div><strong>Local workspace</strong><span>Click to toggle theme</span></div><Settings2 size={17}/></button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumbs"><span>{tree?.item.name ?? 'Product'}</span><ChevronRight size={14}/><strong>{view === 'structure' ? 'Product structure' : view === 'items' ? 'Item master' : view === 'bom' ? 'BOM data entry' : view === 'mindmap' ? 'BOM mind map' : view === 'revisions' ? 'Revisions & changes' : view === 'changes' ? 'Change notices' : view === 'whereused' ? 'Where used' : view === 'backups' ? 'Backup & restore' : view === 'documents' ? 'Engineering documents' : view === 'manual' ? 'User manual' : 'Overview'}</strong></div>
          <div className="topbar-right"><div className="server-chip"><span className="green-dot"/>LOCAL</div><div className="top-user">H</div></div>
        </header>
        {error && <div className="alert error-alert"><span>{error}</span><button onClick={() => setError('')}><X size={16}/></button></div>}
        {notice && <div className="alert success-alert"><span>{notice}</span><button onClick={() => setNotice('')}><X size={16}/></button></div>}

        {view === 'structure' && <StructureView tree={tree} selected={selected} setSelected={setSelected} loading={loading} canEditBom={canEditBom} treeQuery={treeQuery} setTreeQuery={setTreeQuery} onAdd={() => setShowAdd(true)} onExportExcel={() => setShowExportOptions(true)} onUpdateQuantity={updateQuantity} onRemove={removeNode} onCreateProduct={() => setShowNewProject(true)} />}
        {view === 'overview' && <Overview items={items} assemblies={assemblyCount} root={tree} onStructure={() => setView('structure')} onItems={() => setView('items')} />}
        {view === 'items' && <ItemsView items={filteredItems} search={search} setSearch={setSearch} onCreate={() => setShowCreateItem(true)} />}
        {view === 'bom' && <BOMEntryView tree={tree} loading={loading} customClassifications={customClassifications} customSystemNames={customSystemNames} onRememberCustomSystem={rememberCustomSystem} onAdd={() => setShowAdd(true)} onExport={() => setShowExportOptions(true)} onImport={() => setShowExcelImport(true)} onPatchOccurrence={patchOccurrence} onPatchRevision={patchRevision} onPatchItemNumber={patchItemNumber} onMoveOccurrence={moveOccurrence} onLevelError={setError} />}
        {view === 'mindmap' && <BOMMindMapView tree={tree} loading={loading} />}
        {view === 'revisions' && <RevisionHistoryView items={items} initialItemId={tree?.item.id ?? ''} onError={setError} onUpdated={refresh} />}
        {view === 'changes' && <ChangeNoticesView items={items} onError={setError} />}
        {view === 'whereused' && <WhereUsedView items={items} onError={setError} />}
        {view === 'backups' && <BackupView onError={setError} onRestored={async () => { await refresh(); setView('structure'); setNotice('Database restored. A pre-restore safety backup was created.') }} />}
        {view === 'documents' && <EngineeringDocumentsView items={items} onError={setError} onNotice={setNotice} />}
        {view === 'manual' && <ManualView />}
      </main>

      {showAdd && <AddMenu onExisting={() => {setShowAdd(false); setShowExisting(true)}} onNew={() => {setShowAdd(false); setShowCreateItem(true)}} onClose={() => setShowAdd(false)} />}
      {showExisting && <ExistingModal items={items} onClose={() => setShowExisting(false)} onAdd={addExisting} />}
      {showCreateItem && <CreateItemModal onClose={() => setShowCreateItem(false)} onCreate={createAndAdd} onCreateOnly={createStandalone} asChild={(view === 'structure' || view === 'bom') && canEditBom} />}
      {showNewProject && <NewProjectModal onClose={() => setShowNewProject(false)} onCreate={createProject} />}
      {showDeleteWorkspace && tree && <Modal title="Delete local Product BOM?" subtitle="This action removes the selected workspace from this computer's SQLite database." onClose={() => setShowDeleteWorkspace(false)}><div className="delete-workspace-warning"><strong>{tree.item.name} · {tree.item.item_number}</strong><p>This permanently deletes the main product, its revisions, and its BOM occurrence structure. Component item master records are retained.</p><p>If this product is referenced by another BOM, deletion will be blocked to protect that relationship.</p></div><div className="modal-actions"><button className="secondary-button" onClick={() => setShowDeleteWorkspace(false)}>Cancel</button><button className="danger-button" onClick={() => void deleteCurrentProduct()}><Trash2 size={14}/> Delete Product BOM</button></div></Modal>}
      {showExportOptions && <ExcelExportModal onClose={() => setShowExportOptions(false)} onStandard={() => {setShowExportOptions(false); exportExcel()}} onManagement={exportManagementExcel} />}
      {showExcelImport && tree && <ExcelImportModal rootItemNumber={tree.item.item_number} onClose={() => setShowExcelImport(false)} onImport={importExcelBom} />}
    </div>
  )
}

function findNode(root: TreeNode, itemId: string): TreeNode | null {
  if (root.item.id === itemId) return root
  for (const child of root.children ?? []) {
    const found = findNode(child, itemId)
    if (found) return found
  }
  return null
}

function nextFindNumber(parent: TreeNode) {
  const values = (parent.children ?? []).map((child) => Number.parseInt(child.find_number ?? '', 10)).filter(Number.isFinite)
  return String((Math.max(0, ...values) + 10)).padStart(2, '0')
}

function isAssembly(itemType: string) {
  return ['MAIN PRODUCT', 'MAIN ASSEMBLY', 'SUB ASSEMBLY', 'CHILD ASSEMBLY'].includes(itemType)
}

function NavButton({ active, icon, label, onClick, badge }: {active: boolean; icon: React.ReactNode; label: string; onClick: () => void; badge?: string}) {
  return <button className={active ? 'nav-button active' : 'nav-button'} onClick={onClick}>{icon}<span>{label}</span>{badge && <small>{badge}</small>}</button>
}

function StructureView({ tree, selected, setSelected, loading, canEditBom, treeQuery, setTreeQuery, onAdd, onExportExcel, onUpdateQuantity, onRemove, onCreateProduct }: {
  tree: TreeNode | null; selected: TreeNode | null; setSelected: (node: TreeNode) => void; loading: boolean;
  canEditBom: boolean;
  treeQuery: string; setTreeQuery: (value: string) => void;
  onAdd: () => void; onExportExcel: () => void; onUpdateQuantity: (node: TreeNode, quantity: number) => void;
  onRemove: (node: TreeNode) => void; onCreateProduct: () => void;
}) {
  if (loading) return <div className="loading-state"><div className="spinner"/>Loading local engineering data…</div>
  if (!tree) return <div className="empty-workspace"><div className="empty-icon"><Package size={28}/></div><h2>No product structure yet</h2><p>Create a main product to start building your engineering BOM.</p><button className="primary-button" onClick={onCreateProduct}><Plus size={16}/> Create main product</button></div>
  return <div className="page-content structure-page">
    <div className="page-heading"><div><div className="eyebrow">PRODUCT DEFINITION <span className="separator">/</span> ENGINEERING BOM</div><h1>Product structure</h1><p>Define assemblies, parts, and their relationships.</p></div><div className="heading-actions"><button className="secondary-button" onClick={onCreateProduct}><Plus size={15}/> New Product BOM</button><button className="secondary-button" onClick={() => window.print()}><FileDown size={15}/> Save as PDF</button><button className="secondary-button" onClick={onExportExcel}><FileSpreadsheet size={15}/> Export Excel</button><button className="primary-button" onClick={onAdd} disabled={!canEditBom} title={canEditBom ? 'Add to selected assembly' : 'Select an in-work assembly first'}><Plus size={16}/> Add component</button></div></div>
    <div className="product-strip"><div className="product-glyph"><Package size={20}/></div><div className="product-main"><strong>{tree.item.name}</strong><span>{tree.item.item_number} <i/> {tree.item.item_type}</span></div><div className="strip-divider"/><div className="strip-data"><span>REVISION</span><strong>{tree.revision ?? '—'} <em className="status-pill">{tree.state ?? 'IN WORK'}</em></strong></div><div className="strip-divider"/><div className="strip-data"><span>STRUCTURE DEPTH</span><strong>{treeDepth(tree)} levels</strong></div><div className="strip-divider"/><div className="strip-data"><span>CONFIGURATION</span><strong>EBOM · Working</strong></div></div>
    <div className="structure-workspace">
      <section className="panel tree-panel">
        <div className="panel-header"><div><strong>Assembly tree</strong><span>{countTree(tree)} items · expanded</span></div></div>
        <div className="tree-search"><Search size={15}/><input placeholder="Find an item…" value={treeQuery} onChange={(event) => setTreeQuery(event.target.value)}/></div>
        <div className="tree-scroll"><TreeRow node={tree} depth={0} selectedItemId={selected?.item.id ?? ''} search={treeQuery} onSelect={setSelected}/></div>
        <div className="tree-footer"><span><i className="legend-assembly"/>Assembly</span><span><i className="legend-part"/>Part</span><span><i className="legend-buy"/>Purchased</span></div>
      </section>
      <section className="panel bom-panel">
        <div className="bom-titlebar"><div><div className="bom-title"><h2>{selected?.item.name ?? tree.item.name}</h2><span className="type-tag">{selected?.item.item_type ?? tree.item.item_type}</span></div><div className="bom-subtitle">{selected?.path ?? tree.item.item_number} <span>·</span> Rev {selected?.revision ?? tree.revision ?? '—'}</div></div></div>
        <div className="table-toolbar"><div className="table-tabs"><span className="selected-tab">EBOM <span>{selected?.children.length ?? 0}</span></span></div><span className="read-write">{canEditBom ? <><span className="green-dot"/> Editable · In Work</> : 'Select an in-work assembly to edit'}</span></div>
        <div className="table-scroll"><table className="bom-table"><thead><tr><th className="find-col">FIND NO.</th><th>ITEM / DESCRIPTION</th><th>TYPE</th><th>REV</th><th className="qty-col">QTY</th><th>UOM</th><th></th></tr></thead><tbody>
          {(selected?.children ?? []).map((node) => <BomRow key={node.occurrence_id} node={node} onSelect={setSelected} onUpdateQuantity={onUpdateQuantity} onRemove={onRemove}/>) }
          {!selected?.children.length && <tr><td colSpan={7}><div className="table-empty"><BoxSelect size={22}/><span>No child components</span><small>Add an existing item or create a new one.</small></div></td></tr>}
        </tbody></table></div>
        <div className="table-bottom"><span>Showing <strong>{selected?.children.length ?? 0}</strong> components</span>{canEditBom && <button className="add-row-button" onClick={onAdd}><Plus size={15}/> Add line</button>}</div>
        <div className="bom-summary"><div><span>DIRECT COMPONENTS</span><strong>{selected?.children.length ?? 0}</strong></div><div><span>QTY IN PARENT</span><strong>{(selected?.children ?? []).reduce((sum, child) => sum + (child.quantity ?? 0), 0).toLocaleString()}</strong></div><div><span>STRUCTURE STATE</span><strong>{selected?.state ?? 'IN WORK'}</strong></div></div>
      </section>
      <section className="panel properties-panel">
        <div className="panel-header"><div><strong>Properties</strong><span>Selected item</span></div></div>
        {selected ? <><div className="property-hero"><div className="property-glyph">{selected.item.item_type.includes('ASSEMBLY') || selected.item.item_type === 'MAIN PRODUCT' ? <Layers3 size={22}/> : <Component size={22}/>}</div><h3>{selected.item.name}</h3><span>{selected.item.item_type}</span></div>
          <div className="property-section"><div className="section-label">IDENTIFICATION</div><Property label="Item number" value={selected.item.item_number}/><Property label="Revision" value={selected.revision ?? 'Unresolved'}/><Property label="Lifecycle" value={selected.state ?? 'IN WORK'} status/></div>
          <div className="property-section"><div className="section-label">ENGINEERING</div><Property label="Quantity in parent" value={selected.quantity ? `${selected.quantity} ${selected.uom ?? 'EA'}` : '—'}/><Property label="Find number" value={selected.find_number ?? '—'}/><Property label="BOM type" value="EBOM"/></div>
          <div className="property-section"><div className="section-label">HIERARCHY PATH</div><div className="path-box">{selected.path ?? selected.item.item_number}</div></div>
          <div className="property-note"><ShieldCheck size={16}/><span>Item master is shared. Removing a BOM line never deletes the item.</span></div>
        </> : <div className="property-empty">Select an item in the tree to view its properties.</div>}
      </section>
    </div>
    <div className="bottom-tabs"><span className="bottom-tab active"><ClipboardList size={15}/> Engineering BOM</span><div className="bottom-tab-help">BOM changes are saved to the local database as you edit.</div></div>
  </div>
}

function TreeRow({ node, depth, selectedItemId, search, onSelect }: {node: TreeNode; depth: number; selectedItemId: string; search: string; onSelect: (node: TreeNode) => void}) {
  const [expanded, setExpanded] = useState(true)
  const hasChildren = (node.children?.length ?? 0) > 0
  const normalized = search.trim().toLowerCase()
  const matches = (candidate: TreeNode): boolean => `${candidate.item.item_number} ${candidate.item.name} ${candidate.item.item_type}`.toLowerCase().includes(normalized) || (candidate.children ?? []).some(matches)
  if (normalized && !matches(node)) return null
  const isExpanded = normalized ? true : expanded
  const iconClass = node.item.item_type.includes('ASSEMBLY') || node.item.item_type === 'MAIN PRODUCT' ? 'tree-icon assembly' : node.item.item_type.includes('BOUGHT') ? 'tree-icon bought' : node.item.item_type === 'FASTENER' ? 'tree-icon fastener' : 'tree-icon part'
  return <div className="tree-node"><button className={selectedItemId === node.item.id ? 'tree-row selected' : 'tree-row'} style={{ paddingLeft: 10 + depth * 18 }} onClick={() => onSelect(node)}>
    <span className="tree-caret" onClick={(event) => { event.stopPropagation(); if (hasChildren) setExpanded(!expanded) }}>{hasChildren ? isExpanded ? <ChevronDown size={14}/> : <ChevronRight size={14}/> : <span className="caret-spacer"/>}</span>
    <span className={iconClass}>{node.item.item_type.includes('ASSEMBLY') || node.item.item_type === 'MAIN PRODUCT' ? <Layers3 size={14}/> : node.item.item_type.includes('BOUGHT') ? <Package size={14}/> : <Component size={14}/>}</span>
    <span className="tree-name">{node.item.name}</span><span className="tree-number">{node.item.item_number}</span>
  </button>{isExpanded && hasChildren && node.children.map((child) => <TreeRow key={child.occurrence_id} node={child} depth={depth + 1} selectedItemId={selectedItemId} search={search} onSelect={onSelect}/>)}</div>
}

function BomRow({ node, onSelect, onUpdateQuantity, onRemove }: {node: TreeNode; onSelect: (node: TreeNode) => void; onUpdateQuantity: (node: TreeNode, quantity: number) => void; onRemove: (node: TreeNode) => void}) {
  const [quantity, setQuantity] = useState(String(node.quantity ?? 1))
  useEffect(() => setQuantity(String(node.quantity ?? 1)), [node.quantity])
  return <tr className="bom-row" onClick={() => onSelect(node)}>
    <td className="find-col"><span className="find-badge">{node.find_number}</span></td>
    <td><div className="bom-item-cell"><span className={`mini-item-icon ${node.item.item_type.includes('ASSEMBLY') ? 'blue' : node.item.item_type.includes('BOUGHT') ? 'orange' : 'gray'}`}>{node.item.item_type.includes('ASSEMBLY') ? <Layers3 size={15}/> : <Component size={15}/>}</span><span><strong>{node.item.name}</strong><small>{node.item.item_number}</small></span></div></td>
    <td><span className="type-cell">{node.item.item_type}</span></td><td><span className="rev-cell">{node.revision ?? '—'}</span></td>
    <td className="qty-col"><input aria-label={`Quantity for ${node.item.item_number}`} className="qty-input" type="number" min="0.001" step="any" value={quantity} onClick={(e) => e.stopPropagation()} onChange={(e) => setQuantity(e.target.value)} onBlur={() => {const value=Number(quantity); if(value > 0 && value !== node.quantity) onUpdateQuantity(node,value); else setQuantity(String(node.quantity ?? 1))}} onKeyDown={(e) => {if(e.key==='Enter') e.currentTarget.blur()}}/></td><td><span className="uom-cell">{node.uom ?? 'EA'}</span></td>
    <td><button className="row-delete" aria-label={`Remove ${node.item.item_number}`} title="Remove BOM line" onClick={(e) => {e.stopPropagation(); onRemove(node)}}><Trash2 size={15}/></button></td>
  </tr>
}

function Property({ label, value, status }: {label: string; value: string; status?: boolean}) {
  return <div className="property-row"><span>{label}</span>{status ? <strong className="property-status"><i/> {value}</strong> : <strong>{value}</strong>}</div>
}

function countTree(node: TreeNode): number { return 1 + (node.children ?? []).reduce((sum, child) => sum + countTree(child), 0) }
function treeDepth(node: TreeNode): number { return 1 + Math.max(0, ...(node.children ?? []).map(treeDepth)) }

function Overview({ items, assemblies, root, onStructure, onItems }: {items: Item[]; assemblies: number; root: TreeNode | null; onStructure: () => void; onItems: () => void}) {
  return <div className="page-content overview-page">
    <div className="page-heading"><div><div className="eyebrow">ENGINEERING WORKSPACE <span className="separator">/</span> LOCAL DATABASE</div><h1>Overview</h1><p>Local engineering product data and structures.</p></div><div className="heading-actions"><button className="primary-button" onClick={onStructure}><FolderTree size={16}/> Open structure</button></div></div>
    <div className="metric-grid"><Metric icon={<Package size={18}/>} label="Engineering items" value={items.length} note="Unique item master records"/><Metric icon={<Layers3 size={18}/>} label="Assemblies" value={assemblies} note="Products and assembly levels"/><Metric icon={<ClipboardList size={18}/>} label="BOM occurrences" value={root ? countTree(root)-1 : 0} note="Placed components in structure"/><Metric icon={<Gauge size={18}/>} label="Database" value="Local" note="SQLite · stored on this computer"/></div>
    <div className="overview-columns"><section className="panel overview-card"><div className="panel-header"><div><strong>Active product</strong><span>Engineering definition</span></div><span className="status-pill">IN WORK</span></div><div className="active-product"><div className="product-glyph"><Package size={23}/></div><div><h2>{root?.item.name ?? 'No product created'}</h2><p>{root?.item.item_number ?? 'Create a main product to begin'}</p></div></div><div className="overview-detail-grid"><div><span>REVISION</span><strong>{root?.revision ?? '—'}</strong></div><div><span>ASSEMBLY LEVELS</span><strong>5</strong></div><div><span>STRUCTURE ITEMS</span><strong>{root ? countTree(root) - 1 : 0}</strong></div></div><button className="card-action" onClick={onStructure}>View product structure <ChevronRight size={16}/></button></section>
      <section className="panel overview-card"><div className="panel-header"><div><strong>Recently updated items</strong><span>From local item master</span></div><button className="text-button" onClick={onItems}>View all</button></div><div className="recent-list">{items.slice(0,5).map((item) => <div className="recent-item" key={item.id}><div className="mini-item-icon blue"><Component size={15}/></div><div><strong>{item.name}</strong><span>{item.item_number}</span></div><span className="recent-type">{item.item_type}</span></div>)}</div></section></div>
  </div>
}

function Metric({ icon, label, value, note }: {icon: React.ReactNode; label: string; value: string | number; note: string}) {
  return <div className="panel metric-card"><div className="metric-icon">{icon}</div><span className="metric-label">{label}</span><strong className="metric-value">{value}</strong><span className="metric-note">{note}</span></div>
}

function ItemsView({ items, search, setSearch, onCreate }: {items: Item[]; search: string; setSearch: (value: string) => void; onCreate: () => void}) {
  return <div className="page-content items-page"><div className="page-heading"><div><div className="eyebrow">DATA MANAGEMENT <span className="separator">/</span> ITEM MASTER</div><h1>Engineering items</h1><p>One shared record for every designed or procured component.</p></div><button className="primary-button" onClick={onCreate}><Plus size={16}/> Create item</button></div>
    <section className="panel items-panel"><div className="items-toolbar"><div className="search-box"><Search size={16}/><input placeholder="Search item number, name, or type…" value={search} onChange={(e) => setSearch(e.target.value)}/></div><span className="item-total">{items.length} items</span></div><div className="table-scroll"><table className="bom-table items-table"><thead><tr><th>ITEM NUMBER</th><th>NAME</th><th>TYPE</th><th>REVISION</th><th>STATUS</th><th>UOM</th></tr></thead><tbody>{items.map((item) => <tr key={item.id}><td><strong className="code-cell">{item.item_number}</strong></td><td>{item.name}</td><td><span className="type-cell">{item.item_type}</span></td><td>{item.revisions[0]?.revision_code ?? '—'}</td><td><span className="status-pill">{item.revisions[0]?.state ?? '—'}</span></td><td>EA</td></tr>)}{!items.length && <tr><td colSpan={6}><div className="table-empty"><Database size={22}/><span>No matching items</span></div></td></tr>}</tbody></table></div></section>
  </div>
}

function RevisionHistoryView({ items, initialItemId, onError, onUpdated }: {items: Item[]; initialItemId: string; onError: (message: string) => void; onUpdated: () => Promise<void>}) {
  const [selectedItemId, setSelectedItemId] = useState(initialItemId)
  const item = items.find((entry) => entry.id === selectedItemId) ?? null
  const revisions = item?.revisions ?? []
  const [leftId, setLeftId] = useState('')
  const [rightId, setRightId] = useState('')
  const [comparison, setComparison] = useState<{
    left: {revision_code: string; iteration: number; state: string}; right: {revision_code: string; iteration: number; state: string};
    metadata_changes: {field: string; left: unknown; right: unknown}[];
    bom_changes: {added: Record<string, unknown>[]; removed: Record<string, unknown>[]; changed: {left: Record<string, unknown>; right: Record<string, unknown>; differences: Record<string, {left: unknown; right: unknown}>}[]}
  } | null>(null)
  const [events, setEvents] = useState<AuditRow[]>([])
  const [loading, setLoading] = useState(false)
  const [loadedComparison, setLoadedComparison] = useState(false)
  const [newRevisionCode, setNewRevisionCode] = useState('')
  const [revisionBusy, setRevisionBusy] = useState(false)

  useEffect(() => { setSelectedItemId(initialItemId) }, [initialItemId])

  useEffect(() => {
    const newest = revisions[0]?.id ?? ''
    const previous = revisions[1]?.id ?? ''
    setLeftId(previous || newest)
    setRightId(newest)
    setComparison(null)
    setLoadedComparison(false)
    const latestCode = revisions[0]?.revision_code ?? ''
    setNewRevisionCode(/^[A-Z]$/i.test(latestCode) ? String.fromCharCode(latestCode.toUpperCase().charCodeAt(0) + 1) : '')
  }, [item?.id, revisions.map((revision) => revision.id).join('|')])

  useEffect(() => {
    if (!item) { setEvents([]); return }
    void request<AuditRow[]>('/audit?limit=200')
      .then(setEvents)
      .catch((reason) => onError(reason instanceof Error ? reason.message : 'Could not load change history'))
  }, [item?.id, onError])

  async function compare() {
    if (!leftId || !rightId || leftId === rightId) return
    setLoading(true)
    try {
      const data = await request<NonNullable<typeof comparison>>(`/revisions/compare?left=${encodeURIComponent(leftId)}&right=${encodeURIComponent(rightId)}`)
      setComparison(data); setLoadedComparison(true)
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not compare revisions') }
    finally { setLoading(false) }
  }

  async function createRevision() {
    if (!item || !newRevisionCode.trim()) return
    setRevisionBusy(true)
    try {
      await request(`/items/${item.id}/revisions`, { method: 'POST', body: JSON.stringify({ revision_code: newRevisionCode.trim(), change_reason: 'Engineering change' }) })
      await onUpdated()
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not create a working revision') }
    finally { setRevisionBusy(false) }
  }

  async function releaseWorkingRevision() {
    const latest = revisions[0]
    if (!latest || latest.state !== 'IN WORK') return
    if (!window.confirm(`Release ${item?.item_number} revision ${latest.revision_code}? Released revisions are locked. Assemblies can be released only after their child revisions.`)) return
    setRevisionBusy(true)
    try {
      await request(`/revisions/${latest.id}/release`, { method: 'POST' })
      await onUpdated()
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not release this revision') }
    finally { setRevisionBusy(false) }
  }

  return <div className="page-content revision-page">
    <div className="page-heading"><div><div className="eyebrow">DATA MANAGEMENT <span className="separator">/</span> VERSION CONTROL</div><h1>Revisions & changes</h1><p>Compare item revisions, release child revisions, and review local engineering edits.</p></div><label className="revision-item-picker">Item<select className="form-input" value={selectedItemId} onChange={(event) => setSelectedItemId(event.target.value)}><option value="" disabled>Select item</option>{items.map((entry) => <option key={entry.id} value={entry.id}>{entry.item_number} · {entry.name}</option>)}</select></label></div>
    {!item ? <div className="empty-workspace"><h2>Select an item</h2><p>Choose a product, assembly, or part to manage its revision history.</p></div> : <>
      <section className="panel revision-compare-panel"><div className="revision-panel-heading"><div><strong>{item.name}</strong><span>{item.item_number} · {revisions.length} revision{revisions.length === 1 ? '' : 's'}</span></div><span className="status-pill">{revisions[0]?.state ?? 'NO REVISION'}</span></div>
        <div className="revision-lifecycle-controls"><div><strong>Revision lifecycle</strong><span>New revisions copy the latest released properties and BOM links.</span></div>{revisions[0]?.state === 'IN WORK' && <button className="secondary-button" disabled={revisionBusy} onClick={() => void releaseWorkingRevision()}>{revisionBusy ? 'Working…' : `Release Rev ${revisions[0].revision_code}`}</button>}<label className="revision-code-input">New revision<input className="form-input" value={newRevisionCode} maxLength={20} onChange={(event) => setNewRevisionCode(event.target.value)} placeholder="e.g. B" /></label><button className="primary-button" disabled={revisionBusy || !newRevisionCode.trim() || revisions.some((revision) => revision.state === 'IN WORK')} onClick={() => void createRevision()}>{revisionBusy ? 'Working…' : 'Create working revision'}</button></div>
        <div className="revision-compare-controls"><label className="field-label">Compare from<select className="form-input" value={leftId} onChange={(event) => setLeftId(event.target.value)}>{revisions.map((revision) => <option key={revision.id} value={revision.id}>{revision.revision_code} · iteration {revision.iteration} · {revision.state}</option>)}</select></label><span className="revision-arrow">→</span><label className="field-label">Compare to<select className="form-input" value={rightId} onChange={(event) => setRightId(event.target.value)}>{revisions.map((revision) => <option key={revision.id} value={revision.id}>{revision.revision_code} · iteration {revision.iteration} · {revision.state}</option>)}</select></label><button className="primary-button" disabled={loading || revisions.length < 2 || !leftId || !rightId || leftId === rightId} onClick={() => void compare()}>{loading ? 'Comparing…' : 'Compare revisions'}</button></div>
        {revisions.length < 2 && <p className="revision-empty-note">A comparison becomes available when this product has at least two revisions.</p>}
        {loadedComparison && comparison && <div className="comparison-results"><h2>Rev {comparison.left.revision_code} → Rev {comparison.right.revision_code}</h2>
          {!comparison.metadata_changes.length && !comparison.bom_changes.added.length && !comparison.bom_changes.removed.length && !comparison.bom_changes.changed.length && <div className="import-success"><ShieldCheck size={14}/> No differences found.</div>}
          {comparison.metadata_changes.length > 0 && <section><h3>Revision data · {comparison.metadata_changes.length} change(s)</h3><div className="revision-diff-list">{comparison.metadata_changes.map((change) => <div className="revision-diff-row" key={change.field}><strong>{change.field.replace(/_/g, ' ')}</strong><span>{String(change.left ?? '—')}</span><b>→</b><span>{String(change.right ?? '—')}</span></div>)}</div></section>}
          {comparison.bom_changes.added.length > 0 && <RevisionDiffGroup title="Added BOM lines" rows={comparison.bom_changes.added} tone="added"/>}
          {comparison.bom_changes.removed.length > 0 && <RevisionDiffGroup title="Removed BOM lines" rows={comparison.bom_changes.removed} tone="removed"/>}
          {comparison.bom_changes.changed.length > 0 && <section><h3>Changed BOM lines · {comparison.bom_changes.changed.length}</h3><div className="revision-diff-list">{comparison.bom_changes.changed.map((change) => <div className="revision-diff-row" key={String(change.left.key)}><strong>{String(change.left.item_number)} · find {String(change.left.find_number)}</strong><span>{Object.entries(change.differences).map(([field, values]) => `${field}: ${String(values.left)} → ${String(values.right)}`).join(' · ')}</span></div>)}</div></section>}
        </div>}
      </section>
      <section className="panel audit-panel"><div className="revision-panel-heading"><div><strong>Change history</strong><span>Latest local engineering edits across the workspace</span></div><span className="status-pill">{events.length} events</span></div>{events.length ? <div className="audit-list">{events.map((event) => <article className="audit-event" key={event.id}><div className="audit-dot"/><div className="audit-event-body"><strong>{event.summary}</strong><span>{event.action}{event.item_number ? ` · ${event.item_number}` : ''}{event.field_name ? ` · ${event.field_name.replace(/_/g, ' ')}` : ''}{event.revision_code ? ` · Rev ${event.revision_code}` : ''}</span>{event.old_value !== undefined && event.new_value !== undefined && <small>{event.old_value || '—'} → {event.new_value || '—'}</small>}</div><time>{event.created_at ? new Date(event.created_at).toLocaleString() : ''}</time></article>)}</div> : <div className="revision-empty-note">No local changes have been recorded yet.</div>}</section>
    </>}
  </div>
}

function RevisionDiffGroup({ title, rows, tone }: {title: string; rows: Record<string, unknown>[]; tone: 'added' | 'removed'}) {
  return <section><h3>{title} · {rows.length}</h3><div className="revision-diff-list">{rows.map((row) => <div className={`revision-diff-row ${tone}`} key={String(row.key)}><strong>{String(row.item_number)} · {String(row.name)}</strong><span>{String(row.item_type)} · Rev {String(row.revision || '—')} · Qty {String(row.quantity)} {String(row.uom)}</span></div>)}</div></section>
}

function ChangeNoticesView({ items, onError }: {items: Item[]; onError: (message: string) => void}) {
  const [notices, setNotices] = useState<ChangeNotice[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [loading, setLoading] = useState(true)
  const [expandedId, setExpandedId] = useState('')
  const refreshNotices = useCallback(async () => {
    try { setNotices(await request<ChangeNotice[]>('/change-notices')) }
    catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not load change notices') }
    finally { setLoading(false) }
  }, [onError])
  useEffect(() => { void refreshNotices() }, [refreshNotices])

  async function createNotice(payload: {ecn_number: string; title: string; reason: string; affected_items: {item_id: string; change_description: string}[]}) {
    await request('/change-notices', { method: 'POST', body: JSON.stringify(payload) })
    setShowCreate(false)
    await refreshNotices()
  }
  async function transition(notice: ChangeNotice, status: string) {
    try {
      await request(`/change-notices/${notice.id}/transition`, { method: 'POST', body: JSON.stringify({ status }) })
      await refreshNotices()
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not update change notice') }
  }

  return <div className="page-content change-notices-page"><div className="page-heading"><div><div className="eyebrow">ENGINEERING CONTROL <span className="separator">/</span> CHANGE MANAGEMENT</div><h1>Engineering Change Notices</h1><p>Record the reason for a change, identify affected items, and track review through implementation.</p></div><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={15}/> New change notice</button></div>
    <div className="change-flow-hint"><GitBranch size={15}/><span><strong>Workflow:</strong> Draft → In Review → Approved → Implemented. Implementation requires a released revision newer than the recorded baseline for every affected item.</span></div>
    {loading ? <div className="loading-state"><div className="spinner"/>Loading change notices…</div> : notices.length ? <div className="change-notice-list">{notices.map((notice) => {
      const nextStatus = notice.status === 'DRAFT' ? 'IN REVIEW' : notice.status === 'IN REVIEW' ? 'APPROVED' : notice.status === 'APPROVED' ? 'IMPLEMENTED' : ''
      const nextLabel = notice.status === 'DRAFT' ? 'Submit for review' : notice.status === 'IN REVIEW' ? 'Approve notice' : notice.status === 'APPROVED' ? 'Mark implemented' : ''
      const expanded = expandedId === notice.id
      return <section className="panel change-notice-card" key={notice.id}><div className="change-notice-head"><div className="change-ecn-number">{notice.ecn_number}</div><div className="change-notice-title"><strong>{notice.title}</strong><span>{notice.affected_items.length} affected item{notice.affected_items.length === 1 ? '' : 's'} · {notice.created_at ? new Date(notice.created_at).toLocaleDateString() : ''}</span></div><span className={`change-status status-${notice.status.toLowerCase().replace(/ /g, '-')}`}>{notice.status}</span><button className="secondary-button" onClick={() => setExpandedId(expanded ? '' : notice.id)}>{expanded ? 'Hide details' : 'Details'}</button>{nextStatus && <button className="primary-button" onClick={() => void transition(notice, nextStatus)}>{nextLabel}</button>}{!['IMPLEMENTED', 'CANCELLED'].includes(notice.status) && <button className="text-button change-cancel" onClick={() => void transition(notice, 'CANCELLED')}>Cancel</button>}</div>
        {expanded && <div className="change-notice-details"><div><span>Reason</span><p>{notice.reason}</p></div><div className="affected-item-list"><strong>Affected items</strong>{notice.affected_items.map((affected) => <article key={affected.id}><span><b>{affected.item_number}</b> · {affected.item_name} <small>{affected.item_type} · baseline {affected.baseline_revision ?? 'not released'}</small></span><p>{affected.change_description}</p></article>)}</div></div>}
      </section>
    })}</div> : <div className="empty-workspace"><h2>No change notices yet</h2><p>Create a notice to document the reason and scope of an engineering change.</p><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={15}/> Create change notice</button></div>}
    {showCreate && <ChangeNoticeModal items={items} onClose={() => setShowCreate(false)} onCreate={createNotice}/>}
  </div>
}

function ChangeNoticeModal({ items, onClose, onCreate }: {items: Item[]; onClose: () => void; onCreate: (payload: {ecn_number: string; title: string; reason: string; affected_items: {item_id: string; change_description: string}[]}) => Promise<void>}) {
  const [ecn, setEcn] = useState('')
  const [title, setTitle] = useState('')
  const [reason, setReason] = useState('')
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<Record<string, string>>({})
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const matches = items.filter((item) => `${item.item_number} ${item.name} ${item.item_type}`.toLowerCase().includes(query.toLowerCase()))
  async function submit() {
    const affected_items = Object.entries(selected).filter(([, description]) => description.trim()).map(([item_id, change_description]) => ({ item_id, change_description: change_description.trim() }))
    if (!ecn.trim() || !title.trim() || !reason.trim()) { setError('Enter an ECN number, title, and reason.'); return }
    if (!affected_items.length) { setError('Select at least one item and describe the proposed change.'); return }
    setBusy(true); setError('')
    try { await onCreate({ ecn_number: ecn.trim(), title: title.trim(), reason: reason.trim(), affected_items }) }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Could not create change notice'); setBusy(false) }
  }
  return <Modal title="New Engineering Change Notice" subtitle="Capture the change rationale and affected item scope before review." onClose={onClose}>
    <div className="form-row"><label className="field-label">ECN number<input className="form-input" maxLength={40} placeholder="e.g. ECN-2026-001" value={ecn} onChange={(event) => setEcn(event.target.value)}/></label><label className="field-label">Change title<input className="form-input" maxLength={200} placeholder="Short change summary" value={title} onChange={(event) => setTitle(event.target.value)}/></label></div>
    <label className="field-label">Reason for change<textarea className="form-input change-reason-input" maxLength={5000} value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Why is this change needed? Include issue, risk, or customer need."/></label>
    <label className="field-label">Find affected items<input className="form-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Part number or name"/></label>
    <div className="change-item-picker">{matches.slice(0, 80).map((item) => <label className="change-item-choice" key={item.id}><input type="checkbox" checked={item.id in selected} onChange={(event) => setSelected((current) => { const next = {...current}; if (event.target.checked) next[item.id] = ''; else delete next[item.id]; return next })}/><span><strong>{item.item_number}</strong><small>{item.name} · {item.item_type}</small>{item.id in selected && <input className="form-input" value={selected[item.id]} onChange={(event) => setSelected((current) => ({...current, [item.id]: event.target.value}))} onClick={(event) => event.stopPropagation()} placeholder="Describe the proposed item change"/>}</span></label>)}{matches.length > 80 && <small>Search to narrow the item list.</small>}</div>
    {error && <div className="form-error">{error}</div>}<div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={busy} onClick={() => void submit()}>{busy ? 'Creating…' : 'Create Draft ECN'}</button></div>
  </Modal>
}

function WhereUsedView({ items, onError }: {items: Item[]; onError: (message: string) => void}) {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<Item | null>(null)
  const [result, setResult] = useState<WhereUsedResult | null>(null)
  const [loading, setLoading] = useState(false)
  const matches = items.filter((item) => `${item.item_number} ${item.name} ${item.item_type}`.toLowerCase().includes(query.toLowerCase())).slice(0, 50)

  async function selectItem(item: Item) {
    setSelected(item); setLoading(true); setResult(null)
    try { setResult(await request<WhereUsedResult>(`/items/${item.id}/where-used`)) }
    catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not find where this item is used') }
    finally { setLoading(false) }
  }

  return <div className="page-content where-used-page"><div className="page-heading"><div><div className="eyebrow">ENGINEERING IMPACT <span className="separator">/</span> ITEM RELATIONSHIPS</div><h1>Where used</h1><p>Trace a part or assembly upward through every BOM path and product that references it.</p></div></div>
    <section className="panel where-used-search-panel"><label className="field-label">Find an item<input className="form-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search item number, name, or type…"/></label>{query && <div className="where-used-picker">{matches.map((item) => <button key={item.id} onClick={() => { setQuery(''); void selectItem(item) }}><strong>{item.item_number}</strong><span>{item.name} · {item.item_type}</span></button>)}{!matches.length && <small>No matching items.</small>}</div>}{selected && <div className="where-used-selected"><Component size={17}/><span><strong>{selected.name}</strong><small>{selected.item_number} · {selected.item_type}</small></span><button className="secondary-button" onClick={() => { setSelected(null); setResult(null) }}>Clear</button></div>}</section>
    {loading && <div className="loading-state"><div className="spinner"/>Tracing BOM relationships…</div>}
    {result && <><div className="where-used-summary"><strong>{result.use_count}</strong><span>usage path{result.use_count === 1 ? '' : 's'} found for {result.item.item_number}</span></div>{result.uses.length ? <div className="where-used-results">{result.uses.map((use, index) => <section className="panel where-used-card" key={`${use.product.item_number}-${index}`}><div className="where-used-product"><Package size={17}/><span><strong>{use.product.name}</strong><small>{use.product.item_number} · Rev {use.product.revision} · {use.product.revision_state}</small></span><b>Qty {Number(use.quantity_per_product.toFixed(4))}</b></div><div className="where-used-path">{use.path.map((part, partIndex) => <div className="where-used-path-node" key={`${part.item_number}-${partIndex}`}><span className="where-used-path-line"/><div><strong>{part.item_number}</strong><span>{part.name}</span>{partIndex > 0 && <small>Find {part.find_number ?? '—'} · Qty {part.quantity ?? 1}{part.revision ? ` · Rev ${part.revision}` : ''}</small>}</div></div>)}</div></section>)}</div> : <div className="empty-workspace"><h2>No BOM usage found</h2><p>This item is not currently placed in a product assembly.</p></div>}</>}
    {!selected && !query && <div className="empty-workspace"><h2>Select a part or assembly</h2><p>Results include repeated placements and the quantity rolled up to each product.</p></div>}
  </div>
}

function BackupView({ onError, onRestored }: {onError: (message: string) => void; onRestored: () => Promise<void>}) {
  const [backups, setBackups] = useState<BackupInfo[]>([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [selectedRestore, setSelectedRestore] = useState<BackupInfo | null>(null)
  const refreshBackups = useCallback(async () => {
    try { setBackups(await request<BackupInfo[]>('/backups')) }
    catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not load local backups') }
    finally { setLoading(false) }
  }, [onError])
  useEffect(() => { void refreshBackups() }, [refreshBackups])

  async function createBackup() {
    setBusy(true)
    try { await request<BackupInfo>('/backups', { method: 'POST' }); await refreshBackups() }
    catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not create a database backup') }
    finally { setBusy(false) }
  }

  async function restore() {
    if (!selectedRestore) return
    setBusy(true)
    try {
      await request(`/backups/${encodeURIComponent(selectedRestore.name)}/restore`, { method: 'POST' })
      setSelectedRestore(null)
      await onRestored()
      await refreshBackups()
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not restore this database backup') }
    finally { setBusy(false) }
  }

  return <div className="page-content backups-page"><div className="page-heading"><div><div className="eyebrow">LOCAL DATA <span className="separator">/</span> RECOVERY</div><h1>Backup & restore</h1><p>Create verified copies of the SQLite database and restore a saved copy when needed.</p></div><button className="primary-button" disabled={busy} onClick={() => void createBackup()}><ShieldCheck size={15}/>{busy ? 'Working…' : 'Create backup now'}</button></div>
    <div className="backup-safety-note"><ShieldCheck size={17}/><span>Restoring replaces the current PLM database. Before restore, the app automatically creates a safety backup of the current database.</span></div>
    <section className="panel backup-list-panel"><div className="revision-panel-heading"><div><strong>Local database backups</strong><span>Saved alongside the database in its Backups folder</span></div><span className="status-pill">{backups.length} backups</span></div>{loading ? <div className="loading-state"><div className="spinner"/>Loading backups…</div> : backups.length ? <div className="backup-list">{backups.map((backup) => <article className="backup-row" key={backup.name}><div className="backup-file-icon"><FileSpreadsheet size={17}/></div><div className="backup-file-name"><strong>{backup.name}</strong><span>{new Date(backup.created_at).toLocaleString()} · {(backup.size_bytes / (1024 * 1024)).toFixed(2)} MB</span></div><button className="secondary-button" disabled={busy} onClick={() => setSelectedRestore(backup)}>Restore this backup</button></article>)}</div> : <div className="backup-empty"><strong>No backups created yet</strong><span>Make a backup before large imports or engineering changes.</span></div>}</section>
    {selectedRestore && <Modal title="Restore database backup?" subtitle="The current database will be replaced with this saved copy." onClose={() => setSelectedRestore(null)}><div className="delete-workspace-warning"><strong>{selectedRestore.name}</strong><p>This replaces the current products, item masters, BOMs, revisions, and change notices with the contents of the selected backup.</p><p>The app first creates a safety backup of the current database. The selected backup is checked for SQLite integrity and broken BOM references before restore.</p></div><div className="modal-actions"><button className="secondary-button" disabled={busy} onClick={() => setSelectedRestore(null)}>Cancel</button><button className="danger-button" disabled={busy} onClick={() => void restore()}><ShieldCheck size={14}/>{busy ? 'Restoring…' : 'Restore database'}</button></div></Modal>}
  </div>
}

function EngineeringDocumentsView({ items, onError, onNotice }: {
  items: Item[]; onError: (message: string) => void; onNotice: (message: string) => void
}) {
  const [itemId, setItemId] = useState('')
  const [revisionId, setRevisionId] = useState('')
  const [documents, setDocuments] = useState<EngineeringDocument[]>([])
  const [description, setDescription] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<EngineeringDocument | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const activeItem = items.find((item) => item.id === itemId) ?? null

  useEffect(() => {
    if (!items.length) { setItemId(''); return }
    if (!items.some((item) => item.id === itemId)) setItemId(items[0].id)
  }, [items, itemId])

  const refreshDocuments = useCallback(async () => {
    if (!itemId) { setDocuments([]); return }
    setLoading(true)
    try { setDocuments(await request<EngineeringDocument[]>(`/items/${itemId}/documents`)) }
    catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not load engineering documents') }
    finally { setLoading(false) }
  }, [itemId, onError])

  useEffect(() => { void refreshDocuments() }, [refreshDocuments])

  async function upload(file?: File) {
    if (!file || !itemId) return
    if (file.size > 100 * 1024 * 1024) { onError('Files must be 100 MB or smaller'); return }
    setBusy(true)
    try {
      const query = new URLSearchParams({ filename: file.name })
      if (revisionId) query.set('revision_id', revisionId)
      if (description.trim()) query.set('description', description.trim())
      const response = await fetch(`${api}/items/${itemId}/documents?${query}`, {
        method: 'POST', headers: { 'Content-Type': file.type || 'application/octet-stream' }, body: file,
      })
      if (!response.ok) {
        const body = await response.json().catch(() => null)
        throw new Error(body?.detail || `Upload failed (${response.status})`)
      }
      setDescription('')
      await refreshDocuments()
      onNotice(`${file.name} attached to ${activeItem?.item_number ?? 'item'}`)
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not upload this file') }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = '' }
  }

  async function download(entry: EngineeringDocument) {
    try {
      const response = await fetch(`${api}/documents/${entry.id}/download`)
      if (!response.ok) { const body = await response.json().catch(() => null); throw new Error(body?.detail || `Download failed (${response.status})`) }
      const url = URL.createObjectURL(await response.blob())
      const link = document.createElement('a')
      link.href = url
      link.download = entry.original_name
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not download document') }
  }

  async function remove() {
    if (!deleteTarget) return
    setBusy(true)
    try {
      const response = await fetch(`${api}/documents/${deleteTarget.id}`, { method: 'DELETE' })
      if (!response.ok) { const body = await response.json().catch(() => null); throw new Error(body?.detail || `Delete failed (${response.status})`) }
      onNotice(`${deleteTarget.original_name} removed`)
      setDeleteTarget(null)
      await refreshDocuments()
    } catch (reason) { onError(reason instanceof Error ? reason.message : 'Could not remove document') }
    finally { setBusy(false) }
  }

  const formatSize = (bytes: number) => bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / (1024 * 1024)).toFixed(2)} MB`
  return <div className="page-content engineering-documents-page">
    <div className="page-heading"><div><div className="eyebrow">DATA MANAGEMENT <span className="separator">/</span> CONTROLLED FILES</div><h1>Engineering documents</h1><p>Attach drawings, specifications, spreadsheets, and other engineering files to an item or a specific revision.</p></div></div>
    <section className="panel documents-toolbar"><label className="document-item-label">Item master<select className="form-input" value={itemId} onChange={(event) => { setItemId(event.target.value); setRevisionId('') }}><option value="" disabled>Select an item</option>{items.map((item) => <option key={item.id} value={item.id}>{item.item_number} · {item.name}</option>)}</select></label>
      <label className="document-item-label">Revision link <select className="form-input" value={revisionId} onChange={(event) => setRevisionId(event.target.value)}><option value="">General item document</option>{activeItem?.revisions.map((revision) => <option key={revision.id} value={revision.id}>Rev {revision.revision_code} · {revision.state}</option>)}</select></label>
      <label className="document-item-label document-description-label">Description <input className="form-input" maxLength={1000} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Optional context or document purpose" /></label>
      <input ref={fileRef} className="visually-hidden" type="file" accept=".pdf,.xlsx,.xls,.csv,.docx,.doc,.txt,.rtf,.png,.jpg,.jpeg,.tif,.tiff,.bmp,.step,.stp,.iges,.igs,.dxf,.dwg,.stl,.3mf,.zip" onChange={(event) => void upload(event.target.files?.[0])} />
      <button className="primary-button" disabled={!itemId || busy} onClick={() => fileRef.current?.click()}><Upload size={15}/>{busy ? 'Working…' : 'Attach document'}</button>
    </section>
    <div className="documents-storage-note"><ShieldCheck size={16}/><span>Files are stored inside the local SQLite database. Database backups include these attachments.</span><span className="document-size-limit">Up to 100 MB per file</span></div>
    <section className="panel document-list-panel"><div className="revision-panel-heading"><div><strong>{activeItem ? `${activeItem.item_number} · ${activeItem.name}` : 'Select an item'}</strong><span>Documents linked to the item or one of its revisions</span></div><span className="status-pill">{documents.length} files</span></div>
      {loading ? <div className="loading-state"><div className="spinner"/>Loading documents…</div> : documents.length ? <div className="document-list">{documents.map((entry) => <article className="document-row" key={entry.id}><div className="document-file-icon"><FileText size={17}/></div><div className="document-file-name"><strong>{entry.original_name}</strong><span>{formatSize(entry.size_bytes)} · {new Date(entry.created_at).toLocaleString()} · {entry.revision_code ? `Revision ${entry.revision_code}` : 'Item level'}</span>{entry.description && <small>{entry.description}</small>}<small className="document-checksum">SHA-256 · {entry.sha256}</small></div><button className="secondary-button" onClick={() => void download(entry)}><Download size={14}/>Download</button><button className="danger-icon-button" title="Remove attachment" onClick={() => setDeleteTarget(entry)}><Trash2 size={14}/></button></article>)}</div> : <div className="backup-empty"><strong>No documents attached</strong><span>Select an item and attach its drawing or supporting engineering files.</span></div>}
    </section>
    {deleteTarget && <Modal title="Remove engineering document?" subtitle="This removes the attachment from the local database." onClose={() => setDeleteTarget(null)}><div className="delete-workspace-warning"><strong>{deleteTarget.original_name}</strong><p>The file and its stored copy will be permanently removed. Database backups already created will continue to contain their saved copy.</p></div><div className="modal-actions"><button className="secondary-button" disabled={busy} onClick={() => setDeleteTarget(null)}>Cancel</button><button className="danger-button" disabled={busy} onClick={() => void remove()}><Trash2 size={14}/>{busy ? 'Removing…' : 'Remove document'}</button></div></Modal>}
  </div>
}

function ManualView() {
  return <div className="page-content user-manual-page">
    <div className="page-heading"><div><div className="eyebrow">HELP & GUIDANCE <span className="separator">/</span> PRODUCT GUIDE</div><h1>Scienaut product user manual</h1><p>Follow the workflow from launching the local app through building, reviewing, exporting, and protecting a product BOM.</p></div><div className="manual-download-actions"><a className="secondary-button" href="/manual/Scienaut-Engineering-PLM-User-Manual.docx" download>Download Word</a><a className="primary-button" href="/manual/Scienaut-Engineering-PLM-User-Manual.pdf" download>Download PDF</a></div></div>
    <div className="manual-help-note"><BookOpen size={16}/><span>Use the PDF reader below for the full visual guide. The Word file is available if you want to print, annotate, or adapt the manual.</span></div>
    <section className="panel manual-reader"><iframe title="Scienaut Engineering PLM Solutions user manual" src="/manual/Scienaut-Engineering-PLM-User-Manual.pdf" /></section>
  </div>
}

type MindMapPosition = { key: string; parentKey?: string; node: TreeNode; level: number; x: number; y: number }

function BOMMindMapView({ tree, loading }: {tree: TreeNode | null; loading: boolean}) {
  const [activeNode, setActiveNode] = useState<TreeNode | null>(null)
  const [orientation, setOrientation] = useState<'horizontal' | 'vertical'>('horizontal')
  const [zoom, setZoom] = useState(1)
  const frameRef = useRef<HTMLDivElement>(null)
  const layout = useMemo(() => {
    const nodeWidth = 190
    const nodeHeight = 88
    const left = 42
    const top = 50
    const levelGap = orientation === 'horizontal' ? 250 : 150
    const rowGap = orientation === 'horizontal' ? 124 : 230
    const positions: MindMapPosition[] = []
    let leafIndex = 0
    let maxLevel = 0

    if (tree) {
      function place(node: TreeNode, level: number, key: string, parentKey?: string): MindMapPosition {
        const children = node.children ?? []
        const childPositions = children.map((child, index) =>
          place(child, level + 1, child.occurrence_id ?? `${key}-${index}`, key))
        maxLevel = Math.max(maxLevel, level)
        let x: number
        let y: number
        if (orientation === 'horizontal') {
          y = childPositions.length
            ? childPositions.reduce((sum, child) => sum + child.y, 0) / childPositions.length
            : top + nodeHeight / 2 + leafIndex++ * rowGap
          x = left + level * levelGap
        } else {
          x = childPositions.length
            ? childPositions.reduce((sum, child) => sum + child.x + nodeWidth / 2, 0) / childPositions.length - nodeWidth / 2
            : left + leafIndex++ * rowGap
          y = top + level * levelGap
        }
        const position = { key, parentKey, node, level, x, y }
        positions.push(position)
        return position
      }
      place(tree, 0, `root-${tree.item.id}`)
    }

    positions.sort((a, b) => a.level - b.level || a.y - b.y)
    const byItem = new Map<string, MindMapPosition[]>()
    positions.forEach((position) => {
      const group = byItem.get(position.node.item.id) ?? []
      group.push(position)
      byItem.set(position.node.item.id, group)
    })
    const repeatedGroups = [...byItem.entries()]
      .filter(([, group]) => group.length > 1 && new Set(group.map((position) => position.parentKey)).size > 1)
      .map(([itemId, group], index) => ({ itemId, nodes: group, lane: orientation === 'horizontal'
        ? left + (maxLevel + 1) * levelGap + 28 + index * 18
        : top + (maxLevel + 1) * levelGap + 28 + index * 18 }))
    const width = orientation === 'horizontal'
      ? Math.max(850, left + (maxLevel + 1) * levelGap + 28 + repeatedGroups.length * 18 + 24)
      : Math.max(850, left + Math.max(1, leafIndex) * rowGap + 40)
    const height = orientation === 'horizontal'
      ? Math.max(380, top + Math.max(1, leafIndex) * rowGap + 35)
      : Math.max(380, top + (maxLevel + 1) * levelGap + 28 + repeatedGroups.length * 18 + 24)
    return { positions, repeatedGroups, width, height, nodeWidth, nodeHeight, orientation }
  }, [tree, orientation])

  if (loading) return <div className="loading-state"><div className="spinner"/>Loading BOM mind map…</div>
  if (!tree) return <div className="empty-workspace"><div className="empty-icon"><Package size={28}/></div><h2>No product BOM yet</h2><p>Create a product to see its assembly and part relationships.</p></div>

  const byKey = new Map(layout.positions.map((position) => [position.key, position]))
  const childrenByParent = new Map<string, MindMapPosition[]>()
  layout.positions.forEach((position) => {
    if (!position.parentKey) return
    const group = childrenByParent.get(position.parentKey) ?? []
    group.push(position)
    childrenByParent.set(position.parentKey, group)
  })
  function fitMap() {
    const frame = frameRef.current
    if (!frame) return
    const fitted = Math.min((frame.clientWidth - 36) / layout.width, (frame.clientHeight - 54) / layout.height, 1.5)
    setZoom(Math.max(.1, fitted))
  }
  function changeZoom(delta: number) { setZoom((current) => Math.max(.1, Math.min(2.5, Math.round((current + delta) * 100) / 100))) }
  function openOnKeyboard(event: React.KeyboardEvent<SVGGElement>, node: TreeNode) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      setActiveNode(node)
    }
  }
  const detailFields = activeNode ? ([
    ['Item number', activeNode.item.item_number],
    ['Part / assembly name', activeNode.item.name],
    ['Item type', activeNode.item.item_type],
    ['Revision', activeNode.revision],
    ['Lifecycle', activeNode.state],
    ['BOM level', layout.positions.find((position) => position.node === activeNode)?.level == null ? undefined : (layout.positions.find((position) => position.node === activeNode)!.level + 1)],
    ['Find number', activeNode.find_number],
    ['Quantity in parent', activeNode.quantity],
    ['Unit of measure', activeNode.uom],
    ['System', activeNode.system_name],
    ["COE's / owner", activeNode.coe_names || activeNode.engineering?.owner],
    ['Hierarchy path', activeNode.path],
    ['Scope', activeNode.engineering?.scope],
    ['Material', activeNode.engineering?.material_designation],
    ['Proprietary classification', activeNode.engineering?.proprietary_classification],
    ['Manufacturing methods', activeNode.engineering?.manufacturing_methods],
    ['PDM release level', activeNode.engineering?.pdm_release_level],
    ['CAD release status', activeNode.engineering?.cad_release_status],
    ['Unit cost', activeNode.engineering?.unit_cost],
    ['Mass (kg)', activeNode.engineering?.mass],
    ['Mass source', activeNode.engineering?.mass_source],
    ['Manufacturer part number', activeNode.engineering?.manufacturer_part_number],
    ['Purchase reference', activeNode.engineering?.purchase_reference_url],
    ['ECN reference', activeNode.engineering?.ecn_reference],
    ['Supplier', activeNode.engineering?.supplier_name],
    ['Lead time', activeNode.engineering?.lead_time],
    ['Remarks', activeNode.engineering?.remarks],
  ] as Array<[string, string | number | null | undefined]>).filter(([, value]) => value !== undefined && value !== null && value !== '') : []

  return <div className="page-content mindmap-page">
    <div className="page-heading"><div><div className="eyebrow">PRODUCT DEFINITION <span className="separator">/</span> BOM RELATIONSHIPS</div><h1>Product level mind map</h1><p>Explore each assembly level and open any item to see its BOM data.</p></div><div className="mindmap-heading-actions"><div className="mindmap-layout-switch" role="group" aria-label="Mind map orientation"><button className={orientation === 'horizontal' ? 'selected' : ''} onClick={() => { setOrientation('horizontal'); setZoom(1) }}>Horizontal</button><button className={orientation === 'vertical' ? 'selected' : ''} onClick={() => { setOrientation('vertical'); setZoom(1) }}>Vertical</button></div><div className="mindmap-product-chip"><strong>{tree.item.name}</strong><span>{tree.item.item_number} · Rev {tree.revision ?? '—'}</span></div></div></div>
    <div className="mindmap-legend"><span><i className="mindmap-legend-assembly"/>Assembly</span><span><i className="mindmap-legend-part"/>Part</span><span><i className="mindmap-legend-purchased"/>Purchased / fastener</span><span><i className="mindmap-legend-reuse"/>Same item used in multiple assemblies</span></div>
    <div className="mindmap-frame" ref={frameRef}><div className="mindmap-canvas-controls"><button type="button" title="Zoom out" aria-label="Zoom out" onClick={() => changeZoom(-.1)}>−</button><span>{Math.round(zoom * 100)}%</span><button type="button" title="Zoom in" aria-label="Zoom in" onClick={() => changeZoom(.1)}>＋</button><button type="button" title="Fit full map in view" onClick={fitMap}>Fit</button></div><svg className="bom-mindmap" width={layout.width * zoom} height={layout.height * zoom} viewBox={`0 0 ${layout.width} ${layout.height}`} role="group" aria-label={`BOM mind map for ${tree.item.name}`}>
      {[...childrenByParent.entries()].map(([parentKey, children]) => {
        const parent = byKey.get(parentKey)
        if (!parent || children.length === 0) return null
        const { nodeWidth, nodeHeight } = layout
        if (orientation === 'horizontal') {
          const parentRight = parent.x + nodeWidth
          const childLeft = Math.min(...children.map((child) => child.x))
          if (children.length === 1) {
            const child = children[0]
            const bend = Math.max(24, (child.x - parentRight) * .45)
            return <path key={`branch-${parentKey}`} className="mindmap-parent-edge" d={`M ${parentRight} ${parent.y} C ${parentRight + bend} ${parent.y}, ${child.x - bend} ${child.y}, ${child.x} ${child.y}`}/>
          }
          const spineX = (parentRight + childLeft) / 2
          const minY = Math.min(...children.map((child) => child.y))
          const maxY = Math.max(...children.map((child) => child.y))
          const stubs = children.map((child) => `M ${spineX} ${child.y} H ${child.x}`).join(' ')
          return <path key={`branch-${parentKey}`} className="mindmap-parent-edge" d={`M ${parentRight} ${parent.y} H ${spineX} M ${spineX} ${minY} V ${maxY} ${stubs}`}/>
        }
        const parentBottom = parent.y + nodeHeight / 2
        if (children.length === 1) {
          const child = children[0]
          const childTop = child.y - nodeHeight / 2
          return <path key={`branch-${parentKey}`} className="mindmap-parent-edge" d={`M ${parent.x + nodeWidth / 2} ${parentBottom} V ${childTop}`}/>
        }
        const childCenters = children.map((child) => child.x + nodeWidth / 2)
        const spineY = (parentBottom + Math.min(...children.map((child) => child.y - nodeHeight / 2))) / 2
        const stubs = children.map((child) => `M ${child.x + nodeWidth / 2} ${spineY} V ${child.y - nodeHeight / 2}`).join(' ')
        return <path key={`branch-${parentKey}`} className="mindmap-parent-edge" d={`M ${parent.x + nodeWidth / 2} ${parentBottom} V ${spineY} M ${Math.min(...childCenters)} ${spineY} H ${Math.max(...childCenters)} ${stubs}`}/>
      })}
      {layout.repeatedGroups.map((group) => <g key={`reuse-${group.itemId}`} className="mindmap-reuse-edge">
        {orientation === 'horizontal' ? <>
          {group.nodes.map((position) => <path key={`${group.itemId}-${position.key}`} d={`M ${position.x + layout.nodeWidth} ${position.y} H ${group.lane}`}/>)}
          <path d={`M ${group.lane} ${Math.min(...group.nodes.map((position) => position.y))} V ${Math.max(...group.nodes.map((position) => position.y))}`}/>
        </> : <>
          {group.nodes.map((position) => <path key={`${group.itemId}-${position.key}`} d={`M ${position.x + layout.nodeWidth / 2} ${position.y + layout.nodeHeight / 2} V ${group.lane}`}/>)}
          <path d={`M ${Math.min(...group.nodes.map((position) => position.x + layout.nodeWidth / 2))} ${group.lane} H ${Math.max(...group.nodes.map((position) => position.x + layout.nodeWidth / 2))}`}/>
        </>}
      </g>)}
      {layout.positions.map((position) => {
        const type = position.node.item.item_type
        const assembly = isAssembly(type)
        const purchased = type === 'BOUGHT-OUT COMPONENT' || type === 'FASTENER' || type === 'STANDARD COMPONENT'
        const cardClass = position.level === 0 ? 'mindmap-card-root' : assembly ? 'mindmap-card-assembly' : purchased ? 'mindmap-card-purchased' : 'mindmap-card-part'
        const lines = wrapMindMapName(position.node.item.name)
        const quantity = position.level === 0 ? 'PRODUCT ROOT' : `QTY ${position.node.quantity ?? 1} ${position.node.uom ?? 'EA'}`
        return <g key={position.key} className={`mindmap-node ${cardClass}`} role="button" tabIndex={0} aria-label={`Show details for ${position.node.item.item_number} ${position.node.item.name}`} onClick={() => setActiveNode(position.node)} onKeyDown={(event) => openOnKeyboard(event, position.node)}>
          <rect x={position.x} y={position.y - layout.nodeHeight / 2} width={layout.nodeWidth} height={layout.nodeHeight} rx="9"/>
          <text className="mindmap-node-name" x={position.x + layout.nodeWidth / 2} y={position.y - 16} textAnchor="middle">{lines[0]}</text>
          {lines[1] && <text className="mindmap-node-name" x={position.x + layout.nodeWidth / 2} y={position.y - 1} textAnchor="middle">{lines[1]}</text>}
          <text className="mindmap-node-number" x={position.x + layout.nodeWidth / 2} y={position.y + 17} textAnchor="middle">{position.node.item.item_number}</text>
          <text className="mindmap-node-meta" x={position.x + layout.nodeWidth / 2} y={position.y + 32} textAnchor="middle">{quantity}{position.node.revision ? ` · REV ${position.node.revision}` : ''}</text>
        </g>
      })}
    </svg></div>
    <div className="mindmap-footer">Click any node for its item master and occurrence details. Dotted connectors identify the same item used at multiple BOM locations.</div>
    {activeNode && <Modal title={activeNode.item.name} subtitle={`${activeNode.item.item_number} · ${activeNode.item.item_type}`} onClose={() => setActiveNode(null)}><div className="mindmap-detail-grid">{detailFields.map(([label, value]) => <div className="mindmap-detail" key={label}><span>{label}</span><strong>{String(value)}</strong></div>)}</div><div className="modal-actions"><button className="primary-button" onClick={() => setActiveNode(null)}>Close</button></div></Modal>}
  </div>
}

function wrapMindMapName(value: string) {
  const words = value.split(/\s+/)
  const lines: string[] = []
  let line = ''
  for (const word of words) {
    const next = line ? `${line} ${word}` : word
    if (next.length > 25 && line) { lines.push(line); line = word }
    else line = next
  }
  if (line) lines.push(line)
  return lines.slice(0, 2)
}

type FlatRow = { node: TreeNode; parentNode?: TreeNode; parentMultiplier: number; extendedQuantity: number; level: number; systemName: string }

function flattenForEntry(root: TreeNode): FlatRow[] {
  const rows: FlatRow[] = [{ node: root, parentMultiplier: 1, extendedQuantity: 1, level: 1, systemName: '' }]
  function walk(parent: TreeNode, parentMultiplier: number, level: number, system: string) {
    for (const node of parent.children ?? []) {
      const extendedQuantity = parentMultiplier * (node.quantity ?? 0)
      const systemName = node.system_name || (level === 2 ? node.item.name : system)
      rows.push({ node, parentNode: parent, parentMultiplier, extendedQuantity, level, systemName })
      walk(node, extendedQuantity, level + 1, systemName)
    }
  }
  walk(root, 1, 2, '')
  return rows
}

function BOMEntryView({ tree, loading, customClassifications, customSystemNames, onRememberCustomSystem, onAdd, onExport, onImport, onPatchOccurrence, onPatchRevision, onPatchItemNumber, onMoveOccurrence, onLevelError }: {
  tree: TreeNode | null; loading: boolean; onAdd: () => void; onExport: () => void; onImport: () => void;
  customClassifications: string[];
  customSystemNames: string[];
  onRememberCustomSystem: (value: string) => void;
  onPatchOccurrence: (node: TreeNode, patch: Record<string, unknown>) => Promise<void>;
  onPatchRevision: (revisionId: string, patch: Record<string, unknown>) => Promise<void>;
  onPatchItemNumber: (itemId: string, itemNumber: string) => Promise<void>;
  onMoveOccurrence: (node: TreeNode, parentRevisionId: string) => Promise<void>;
  onLevelError: (message: string) => void;
}) {
  const [filter, setFilter] = useState('')
  const [visibleLevels, setVisibleLevels] = useState(4)
  const [tableZoom, setTableZoom] = useState(1)
  const [pendingMove, setPendingMove] = useState<{node: TreeNode; level: number; candidates: TreeNode[]} | null>(null)
  const productId = tree?.item.id ?? ''
  useEffect(() => {
    if (!productId) return
    try {
      const saved = Number(localStorage.getItem(`engineering-plm-visible-levels-${productId}`))
      setVisibleLevels(Number.isInteger(saved) && saved >= 4 ? saved : 4)
    } catch { setVisibleLevels(4) }
  }, [productId])
  if (loading) return <div className="loading-state"><div className="spinner"/>Loading BOM table…</div>
  if (!tree) return <div className="empty-workspace"><h2>Create a product BOM first</h2><p>Use “New Product BOM” in the workspace selector.</p></div>
  function addLevel() {
    const next = visibleLevels + 1
    setVisibleLevels(next)
    try { localStorage.setItem(`engineering-plm-visible-levels-${productId}`, String(next)) } catch { /* Keep the added level for this session if storage is unavailable. */ }
  }
  function removeLastLevel() {
    if (visibleLevels <= 4) return
    const next = visibleLevels - 1
    setVisibleLevels(next)
    try { localStorage.setItem(`engineering-plm-visible-levels-${productId}`, String(next)) } catch { /* Keep the reduced count for this session if storage is unavailable. */ }
  }
  function changeTableZoom(delta: number) {
    setTableZoom((current) => Math.max(.3, Math.min(1.6, Math.round((current + delta) * 100) / 100)))
  }
  const allRows = flattenForEntry(tree)
  const normalized = filter.trim().toLowerCase()
  const rows = allRows.filter(({ node, systemName }) => !normalized || `${node.item.item_number} ${node.item.name} ${node.item.item_type} ${systemName}`.toLowerCase().includes(normalized))
  const depth = visibleLevels
  function chooseLevel(node: TreeNode, targetLevel: number) {
    if (targetLevel <= 1) {
      onLevelError('BOM components cannot be moved to Level 1; that level is the product root.')
      return
    }
    const candidates = allRows
      .filter((candidate) => candidate.level === targetLevel - 1
        && isAssembly(candidate.node.item.item_type)
        && candidate.node.revision_id
        && candidate.node.state === 'IN WORK'
        && candidate.node.occurrence_id !== node.occurrence_id
        && !(node.path && candidate.node.path?.startsWith(`${node.path}/`)))
      .map((candidate) => candidate.node)
    if (candidates.length === 0) {
      onLevelError(`To move this row to Level ${targetLevel}, first add an in-work assembly at Level ${targetLevel - 1}.`)
    } else if (candidates.length === 1) {
      void onMoveOccurrence(node, candidates[0].revision_id!)
    } else {
      setPendingMove({ node, level: targetLevel, candidates })
    }
  }
  const headers = ['Sr. No.', 'System', "COE's", ...Array.from({ length: depth }, (_, index) => `Level ${index + 1}`), 'Part Number', 'Revision#', 'Part Name', 'Quantity per Product', 'Scope', 'MATERIAL', 'Proprietary (Part/Assy), STD part, Software, Miscellaneous (Consumables)', 'Manufacturing Methods', 'PDM Release Level', 'Release/CAD Level Status', 'Price Rs.', 'MPN For BuyOut Items', 'Purchase Link for Ref.', 'CAD MASS [KG]', 'Price Rs. Extended', 'ECN No With Revision', 'Remarks', 'Supplier Name', 'Lead Time for Purchase']
  return <div className="page-content bom-entry-page">
    <div className="page-heading"><div><div className="eyebrow">DATA MANAGEMENT <span className="separator">/</span> ENGINEERING REGISTER</div><h1>Excel-style BOM entry</h1><p>Enter and review the product BOM across all hierarchy levels. Changes save to the local item revisions and occurrences.</p></div><div className="heading-actions"><button className="secondary-button" onClick={onImport}><Upload size={15}/> Import Excel BOM</button><button className="secondary-button" onClick={onExport}><FileSpreadsheet size={15}/> Export Excel</button><button className="primary-button" onClick={onAdd}><Plus size={16}/> Add part / assembly</button></div></div>
    <div className="bom-entry-meta"><div><span>PRODUCT</span><strong>{tree.item.name}</strong><small>{tree.item.item_number} · Rev {tree.revision ?? '—'} · {tree.state ?? 'IN WORK'}</small></div><div><span>ROWS</span><strong>{allRows.length}</strong><small>Root plus every BOM occurrence</small></div><div><span>EDITING</span><strong>In Work only</strong><small>Released revisions remain locked</small></div><div className="bom-entry-search"><Search size={15}/><input placeholder="Filter item number, name, system…" value={filter} onChange={(event) => setFilter(event.target.value)}/></div></div>
    <div className="spreadsheet-help">Four levels show by default. Use + or − in the last level heading to add or remove a level. To move an item, change its current level number; it moves under an in-work assembly at the previous level. Choose the assembly if several are available.</div>
    <div className="spreadsheet-frame"><div className="table-canvas-controls"><button type="button" title="Zoom out" aria-label="Zoom out" disabled={tableZoom <= .3} onClick={() => changeTableZoom(-.1)}>−</button><span>{Math.round(tableZoom * 100)}%</span><button type="button" title="Zoom in" aria-label="Zoom in" disabled={tableZoom >= 1.6} onClick={() => changeTableZoom(.1)}>＋</button></div><div className="spreadsheet-zoom-content" style={{ zoom: tableZoom }}><table className="spreadsheet-table"><thead><tr>{headers.map((header, index) => {
      const isLevel = index >= 3 && index < 3 + depth
      const isLastLevel = isLevel && index === 2 + depth
      const dataColumnClass = index >= 3 + depth ? `data-header ${index === 3 + depth ? 'part-number-header' : ''} ${index === 4 + depth ? 'revision-header' : ''} ${index === 5 + depth ? 'part-name-header' : ''} ${header === 'Quantity per Product' ? 'quantity-header' : ''} ${header.startsWith('Proprietary') ? 'classification-header' : ''}` : ''
      return <th key={`${header}-${index}`} className={`${index < 3 ? 'sticky-col' : ''} ${isLevel ? 'level-header' : ''} ${dataColumnClass}`}>{isLevel ? <span>{header}</span> : header}{isLastLevel && <div className="level-controls"><button className="add-level-button" type="button" title="Add another hierarchy level" aria-label="Add another hierarchy level" onClick={addLevel}>+</button><button className="remove-level-button" type="button" title={depth <= 4 ? 'Keep at least four levels' : 'Remove the last hierarchy level'} aria-label="Remove the last hierarchy level" disabled={depth <= 4} onClick={removeLastLevel}>−</button></div>}</th>
    })}</tr></thead><tbody>{rows.map((row, rowIndex) => <BOMEntryRow key={row.node.occurrence_id ?? row.node.item.id} row={row} serial={rowIndex} levelCount={depth} customClassifications={customClassifications} customSystemNames={customSystemNames} onRememberCustomSystem={onRememberCustomSystem} onPatchOccurrence={onPatchOccurrence} onPatchRevision={onPatchRevision} onPatchItemNumber={onPatchItemNumber} onChooseLevel={chooseLevel}/>)}</tbody></table></div></div>
    <div className="spreadsheet-footer"><span>{rows.length} of {allRows.length} rows · {depth} level columns shown</span><span>Rows appear automatically when items are added to an assembly.</span></div>
    {pendingMove && <Modal title={`Move ${pendingMove.node.item.name} to Level ${pendingMove.level}`} subtitle="Choose the in-work assembly that will own this BOM occurrence." onClose={() => setPendingMove(null)}>
      <div className="move-parent-list">{pendingMove.candidates.map((parent) => <button className="move-parent-choice" key={`${parent.occurrence_id ?? 'root'}-${parent.revision_id}`} onClick={() => { void onMoveOccurrence(pendingMove.node, parent.revision_id!); setPendingMove(null) }}><span><strong>{parent.item.name}</strong><small>{parent.item.item_number} · {parent.item.item_type} · Rev {parent.revision}</small></span><ChevronRight size={16}/></button>)}</div>
      <div className="modal-actions"><button className="secondary-button" onClick={() => setPendingMove(null)}>Cancel</button></div>
    </Modal>}
  </div>
}

function BOMEntryRow({ row, serial, levelCount, customClassifications, customSystemNames, onRememberCustomSystem, onPatchOccurrence, onPatchRevision, onPatchItemNumber, onChooseLevel }: {
  row: FlatRow; serial: number; levelCount: number; onPatchOccurrence: (node: TreeNode, patch: Record<string, unknown>) => Promise<void>;
  customClassifications: string[];
  customSystemNames: string[];
  onRememberCustomSystem: (value: string) => void;
  onPatchRevision: (revisionId: string, patch: Record<string, unknown>) => Promise<void>;
  onPatchItemNumber: (itemId: string, itemNumber: string) => Promise<void>;
  onChooseLevel: (node: TreeNode, targetLevel: number) => void;
}) {
  const { node } = row
  const editableOccurrence = Boolean(node.occurrence_id && row.parentNode?.state === 'IN WORK')
  const editableRevision = Boolean(node.revision_id && node.state === 'IN WORK')
  const eng = node.engineering ?? {}
  const typeDefault = node.item.item_type === 'MAIN PRODUCT' || node.item.item_type === 'MAIN ASSEMBLY' ? 'MAIN ASSY' : node.item.item_type === 'CHILD ASSEMBLY' ? 'CHILD ASSEMBLY' : node.item.item_type === 'SUB ASSEMBLY' ? 'ASSEMBLY' : node.item.item_type === 'FASTENER' || node.item.item_type === 'STANDARD COMPONENT' ? 'STD part' : row.level > 2 ? 'Child Part' : 'PARTS'
  const classification = normalizeClassification(eng.proprietary_classification || typeDefault)
  const classOptions = [...new Set([...proprietaryClassifications, ...customClassifications, ...(classification ? [classification] : [])])]
  const currentSystem = node.system_name || row.systemName || ''
  const systemOptions = [...new Set([...systemNames, ...customSystemNames, ...(currentSystem ? [currentSystem] : [])])]
  const levels = Array.from({ length: levelCount }, (_, index) => index + 1 === row.level ? row.level : '')
  const patchOcc = (patch: Record<string, unknown>) => { void onPatchOccurrence(node, patch) }
  const patchRev = (patch: Record<string, unknown>) => { if (node.revision_id) void onPatchRevision(node.revision_id, patch) }
  const directQuantity = (extended: number) => extended / Math.max(row.parentMultiplier, Number.EPSILON)
  const extendedCost = eng.unit_cost == null ? '' : (eng.unit_cost * row.extendedQuantity).toFixed(2)
  const levelClass = `entry-level-${Math.min(row.level, 9)}`
  const itemClass = isAssembly(node.item.item_type) ? 'entry-assembly' : node.item.item_type === 'BOUGHT-OUT COMPONENT' || node.item.item_type === 'FASTENER' || node.item.item_type === 'STANDARD COMPONENT' ? 'entry-purchased' : 'entry-part'
  return <tr className={`${node.occurrence_id ? '' : 'root-entry-row'} ${levelClass} ${itemClass}`}>
    <td className="sticky-col"><span className="serial-cell">{serial}</span></td>
    <td className="sticky-col"><GridSelect value={currentSystem} options={systemOptions} allowCustom disabled={!editableOccurrence} onChange={(value) => {
      if (value === '__custom__') {
        const custom = window.prompt('Enter a custom system name:')?.trim()
        if (custom) { onRememberCustomSystem(custom); patchOcc({ system_name: custom }) }
      } else patchOcc({ system_name: value })
    }}/></td>
    <td className="sticky-col"><GridInput value={node.coe_names || ''} placeholder="COE / owner" disabled={!editableOccurrence} onSave={(value) => patchOcc({ coe_names: value })}/></td>
    {levels.map((level, index) => {
      return <td key={index} className="level-cell">{level ? node.occurrence_id ? <select className="level-number-select" aria-label={`Edit ${node.item.name} BOM level`} title="Choose a level to move this item and update its assembly relationship" value={String(row.level)} disabled={!editableOccurrence} onChange={(event) => {
        const nextLevel = Number(event.target.value)
        if (nextLevel === row.level) return
        onChooseLevel(node, nextLevel)
      }}>{Array.from({ length: levelCount }, (_, levelIndex) => <option key={levelIndex + 1} value={levelIndex + 1}>{levelIndex + 1}</option>)}</select> : <span className="level-current">{level}</span> : null}</td>
    })}
    <td className="master-cell part-number-cell"><GridInput value={node.item.item_number} disabled={!editableRevision} onSave={(value) => { if (value.trim() && value.trim() !== node.item.item_number) void onPatchItemNumber(node.item.id, value.trim()) }}/></td><td className="master-cell revision-cell">{node.revision ?? '—'}</td><td className="master-cell item-name-cell" title={node.item.name}>{node.item.name}</td>
    <td className="quantity-cell"><GridInput value={String(row.extendedQuantity)} type="number" min="0.001" step="any" disabled={!editableOccurrence} onSave={(value) => { const qty = Number(value); if (qty > 0) patchOcc({ quantity: directQuantity(qty) }) }}/></td>
    <td><GridSelect value={eng.scope ?? ''} options={scopes} disabled={!editableRevision} onChange={(value) => patchRev({ scope: value })}/></td>
    <td><GridInput value={eng.material_designation ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ material_designation: value })}/></td>
    <td><GridSelect value={classification} options={classOptions} allowCustom disabled={!editableRevision} onChange={(value) => {
      if (value === '__custom__') {
        const custom = window.prompt('Enter a custom classification:')?.trim()
        if (custom) patchRev({ proprietary_classification: custom })
      } else patchRev({ proprietary_classification: value })
    }}/></td>
    <td><GridSelect value={eng.manufacturing_methods ?? ''} options={manufacturingMethods} disabled={!editableRevision} onChange={(value) => patchRev({ manufacturing_methods: value })}/></td>
    <td><GridSelect value={eng.pdm_release_level || node.state || ''} options={['Prototype', 'Beta', 'Pre Production', 'Production', 'IN WORK', 'RELEASED', 'OBSOLETE']} disabled={!editableRevision} onChange={(value) => patchRev({ pdm_release_level: value })}/></td>
    <td><GridInput value={eng.cad_release_status ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ cad_release_status: value })}/></td>
    <td><GridInput value={eng.unit_cost == null ? '' : String(eng.unit_cost)} type="number" min="0" step="any" disabled={!editableRevision} onSave={(value) => patchRev({ unit_cost: value === '' ? null : Number(value) })}/></td>
    <td><GridInput value={eng.manufacturer_part_number ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ manufacturer_part_number: value })}/></td>
    <td><GridInput value={eng.purchase_reference_url ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ purchase_reference_url: value })}/></td>
    <td><GridInput value={eng.mass_source === 'CAD_DERIVED' && eng.mass != null ? String(eng.mass) : ''} type="number" min="0" step="any" placeholder={eng.mass != null && eng.mass_source !== 'CAD_DERIVED' ? 'User mass' : ''} disabled={!editableRevision} onSave={(value) => patchRev({ mass: value === '' ? null : Number(value), mass_source: value === '' ? null : 'CAD_DERIVED' })}/></td>
    <td className="computed-cell">{extendedCost}</td>
    <td><GridInput value={eng.ecn_reference ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ ecn_reference: value })}/></td>
    <td><GridInput value={eng.remarks ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ remarks: value })}/></td>
    <td><GridInput value={eng.supplier_name ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ supplier_name: value })}/></td>
    <td><GridInput value={eng.lead_time ?? ''} disabled={!editableRevision} onSave={(value) => patchRev({ lead_time: value })}/></td>
  </tr>
}

function GridInput({ value, onSave, disabled, placeholder, type = 'text', min, step }: {
  value: string; onSave: (value: string) => void; disabled?: boolean; placeholder?: string;
  type?: string; min?: string; step?: string;
}) {
  const [draft, setDraft] = useState(value)
  useEffect(() => setDraft(value), [value])
  return <input className="grid-input" value={draft} type={type} min={min} step={step} placeholder={placeholder} disabled={disabled} onChange={(event) => setDraft(event.target.value)} onBlur={() => { if (!disabled && draft !== value) onSave(draft) }} onKeyDown={(event) => { if (event.key === 'Enter') event.currentTarget.blur() }}/>
}

function GridSelect({ value, options, disabled, allowCustom, onChange }: {value: string; options: string[]; disabled?: boolean; allowCustom?: boolean; onChange: (value: string) => void}) {
  return <select className="grid-input grid-select" value={value} disabled={disabled} onChange={(event) => onChange(event.target.value)}><option value=""></option>{options.map((option) => <option key={option} value={option}>{option}</option>)}{allowCustom && <option value="__custom__">＋ Custom…</option>}</select>
}

function AddMenu({ onExisting, onNew, onClose }: {onExisting: () => void; onNew: () => void; onClose: () => void}) {
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="add-menu" onMouseDown={(e) => e.stopPropagation()}><div className="modal-title-row"><div><h2>Add component</h2><p>Add a line to the selected assembly.</p></div><button className="icon-button" onClick={onClose}><X size={18}/></button></div><button className="add-choice" onClick={onExisting}><div className="choice-icon"><Database size={18}/></div><span><strong>Add existing item</strong><small>Reuse an item already in the item master.</small></span><ChevronRight size={17}/></button><button className="add-choice" onClick={onNew}><div className="choice-icon"><Plus size={18}/></div><span><strong>Create new item</strong><small>Create the item and place it in this assembly.</small></span><ChevronRight size={17}/></button></div></div>
}

function ExcelExportModal({ onClose, onStandard, onManagement }: {onClose: () => void; onStandard: () => void; onManagement: (title: string) => void}) {
  const [title, setTitle] = useState(() => {
    try { return localStorage.getItem('engineering-plm-template-title') || 'Retearn Engineering Management' }
    catch { return 'Retearn Engineering Management' }
  })
  function exportManagement() {
    const savedTitle = title.trim() || 'Retearn Engineering Management'
    try { localStorage.setItem('engineering-plm-template-title', savedTitle) } catch { /* Export can proceed when browser storage is disabled. */ }
    onManagement(savedTitle)
  }
  return <Modal onClose={onClose} title="Choose Excel format" subtitle="Keep the standard workbook, or use your engineering management register layout.">
    <button className="export-option" onClick={onStandard}><span className="export-option-icon"><FileSpreadsheet size={19}/></span><span><strong>Engineering PLM standard</strong><small>Product summary and expanded multi-level EBOM.</small></span><span className="option-arrow">›</span></button>
    <div className="export-option management-option"><div className="export-option-head"><span className="export-option-icon warm"><ClipboardList size={19}/></span><span><strong>Engineering Management template</strong><small>Series, Level 1–9, process, scope, PDM release, supplier and costing columns.</small></span></div><label className="field-label template-title-field">Workbook title <span className="field-hint">editable</span><input className="form-input" maxLength={100} value={title} onChange={(event) => setTitle(event.target.value)}/></label><button className="primary-button export-template-button" onClick={exportManagement}><FileSpreadsheet size={15}/> Export this format</button></div>
  </Modal>
}

function ExcelImportModal({ rootItemNumber, onClose, onImport }: {
  rootItemNumber: string; onClose: () => void; onImport: (rows: ExcelImportRow[]) => Promise<void>
}) {
  const [fileName, setFileName] = useState('')
  const [rows, setRows] = useState<ExcelImportRow[]>([])
  const [errors, setErrors] = useState<string[]>([])
  const [busy, setBusy] = useState(false)

  async function readFile(file?: File) {
    setRows([]); setErrors([]); setFileName(file?.name ?? '')
    if (!file) return
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: 'array', cellDates: false })
      const sheet = workbook.Sheets[workbook.SheetNames[0]]
      if (!sheet) throw new Error('The workbook has no worksheets.')
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: false, defval: '' })
      const normalize = (value: unknown) => String(value ?? '').toLowerCase().replace(/[^a-z0-9]/g, '')
      const headerIndex = matrix.findIndex((row) => {
        const values = row.map(normalize)
        return values.some((value) => ['partnumber', 'itemnumber'].includes(value))
          && values.some((value) => ['partname', 'itemname', 'description'].includes(value))
      })
      if (headerIndex < 0) throw new Error('Could not find a header row containing Part Number and Part Name.')
      const headers = matrix[headerIndex].map(normalize)
      const column = (...names: string[]) => headers.findIndex((header) => names.map(normalize).includes(header))
      const valueAt = (cells: unknown[], ...names: string[]) => {
        const index = column(...names)
        return index < 0 ? '' : String(cells[index] ?? '').trim()
      }
      const numberAt = (cells: unknown[], ...names: string[]) => {
        const value = valueAt(cells, ...names).replace(/,/g, '')
        if (!value) return null
        const parsed = Number(value)
        return Number.isFinite(parsed) ? parsed : Number.NaN
      }
      const levelColumns = headers.map((header, index) => {
        const match = header.match(/^level(\d+)$/)
        return match ? { level: Number(match[1]), index } : null
      }).filter((entry): entry is {level: number; index: number} => Boolean(entry))
      if (!levelColumns.length) throw new Error('No Level 1, Level 2, … columns were found in the first worksheet.')
      const rawRows = matrix.slice(headerIndex + 1).map((cells, offset) => {
        const itemNumber = valueAt(cells, 'Part Number', 'Item Number')
        const itemName = valueAt(cells, 'Part Name', 'Item Name', 'Description')
        const level = levelColumns.filter(({ index }) => Number(String(cells[index] ?? '').replace(/,/g, '')) > 0)
          .reduce((highest, current) => Math.max(highest, current.level), 0)
        return { cells, source_row: headerIndex + offset + 2, itemNumber, itemName, level }
      }).filter((row) => row.itemNumber || row.itemName || row.level)
      const rootPresent = rawRows.some((row) => row.itemNumber.toLowerCase() === rootItemNumber.toLowerCase())
      const minLevel = Math.min(...rawRows.filter((row) => row.level).map((row) => row.level), 2)
      const levelOffset = rootPresent ? 0 : minLevel === 1 ? 1 : 0
      const multiplierByLevel = new Map<number, number>([[1, 1]])
      const assemblyLevels = new Set<number>([1])
      const parsedRows: ExcelImportRow[] = []
      const parseErrors: string[] = []
      const quantityColumn = column('Quantity per Product', 'Quantity/Product', 'Extended Qty')
      const directQuantityColumn = column('Qty per Parent', 'Quantity per Parent', 'Quantity')
      for (const row of rawRows) {
        if (row.itemNumber.toLowerCase() === rootItemNumber.toLowerCase()) continue
        const level = row.level + levelOffset
        if (!row.itemNumber || !row.itemName) {
          parseErrors.push(`Row ${row.source_row}: both Part Number and Part Name are required.`)
          continue
        }
        if (level < 2) {
          parseErrors.push(`Row ${row.source_row}: a component needs a Level 2 or deeper marker.`)
          continue
        }
        if (!assemblyLevels.has(level - 1)) {
          parseErrors.push(`Row ${row.source_row}: Level ${level - 1} has no preceding assembly. Check row order and classifications.`)
          continue
        }
        const parentMultiplier = multiplierByLevel.get(level - 1)
        if (!parentMultiplier) {
          parseErrors.push(`Row ${row.source_row}: Level ${level - 1} parent is missing. Check row order and assembly levels.`)
          continue
        }
        const qValue = directQuantityColumn >= 0
          ? numberAt(row.cells, 'Qty per Parent', 'Quantity per Parent', 'Quantity')
          : quantityColumn >= 0
            ? numberAt(row.cells, 'Quantity per Product', 'Quantity/Product', 'Extended Qty')
            : 1
        if (qValue == null || Number.isNaN(qValue) || qValue <= 0) {
          parseErrors.push(`Row ${row.source_row}: quantity must be a number greater than zero.`)
          continue
        }
        const isExtended = directQuantityColumn < 0 && quantityColumn >= 0
        const quantity = isExtended ? qValue / parentMultiplier : qValue
        const extended = isExtended ? qValue : quantity * parentMultiplier
        for (const depth of [...multiplierByLevel.keys()]) if (depth >= level) multiplierByLevel.delete(depth)
        for (const depth of [...assemblyLevels]) if (depth >= level) assemblyLevels.delete(depth)
        multiplierByLevel.set(level, extended)
        const optionalNumber = (...names: string[]) => {
          const value = numberAt(row.cells, ...names)
          if (value != null && Number.isNaN(value)) parseErrors.push(`Row ${row.source_row}: ${names[0]} must be numeric.`)
          return value != null && !Number.isNaN(value) ? value : undefined
        }
        const itemType = valueAt(row.cells, 'Item Type')
        const classification = valueAt(row.cells, "Proprietary (Part/Assy), STD part, Software, Miscellaneous (Consumables)", 'Classification')
        parsedRows.push({
          source_row: row.source_row, level,
          find_number: valueAt(row.cells, 'Find No.', 'Find Number') || undefined,
          item_number: row.itemNumber, name: row.itemName,
          revision_code: valueAt(row.cells, 'Revision#', 'Revision') || undefined,
          item_type: itemType || undefined,
          classification: classification || undefined,
          quantity, uom: valueAt(row.cells, 'UOM') || 'EA',
          system_name: valueAt(row.cells, 'System') || undefined, coe_names: valueAt(row.cells, "COE's", 'COE', 'Owner') || undefined,
          scope: valueAt(row.cells, 'Scope') || undefined,
          material_designation: valueAt(row.cells, 'MATERIAL', 'Material') || undefined,
          manufacturing_methods: valueAt(row.cells, 'Manufacturing Methods', 'Manufacturing Method') || undefined,
          pdm_release_level: valueAt(row.cells, 'PDM Release Level') || undefined,
          cad_release_status: valueAt(row.cells, 'Release/CAD Level Status', 'CAD Release Status') || undefined,
          unit_cost: optionalNumber('Price Rs.', 'Unit Cost'),
          manufacturer_part_number: valueAt(row.cells, 'MPN For BuyOut Items', 'Manufacturer Part Number') || undefined,
          purchase_reference_url: valueAt(row.cells, 'Purchase Link for Ref.', 'Purchase Reference URL') || undefined,
          mass: optionalNumber('CAD MASS [KG]', 'Mass'),
          ecn_reference: valueAt(row.cells, 'ECN No With Revision', 'ECN Reference') || undefined,
          remarks: valueAt(row.cells, 'Remarks') || undefined,
          supplier_name: valueAt(row.cells, 'Supplier Name') || undefined,
          lead_time: valueAt(row.cells, 'Lead Time for Purchase', 'Lead Time') || undefined,
        })
        const assemblyRow = /assembly/i.test(itemType)
          || /^(assy|assembly|main assy|main assembly|child assembly|sub assembly)$/i.test(classification)
        if (assemblyRow) assemblyLevels.add(level)
      }
      if (!parsedRows.length && !parseErrors.length) parseErrors.push('No component rows were found to import.')
      setRows(parsedRows); setErrors(parseErrors)
    } catch (reason) {
      setErrors([reason instanceof Error ? reason.message : 'Could not read this workbook.'])
    }
  }

  async function submit() {
    if (!rows.length || errors.length) return
    setBusy(true)
    try { await onImport(rows) }
    catch (reason) { setErrors([reason instanceof Error ? reason.message : 'Import was rejected. No rows were saved.']); setBusy(false) }
  }

  return <Modal title="Import Excel BOM" subtitle="Preview and validate the first worksheet before its rows are linked to the selected Product BOM." onClose={onClose}>
    <label className="field-label">Engineering management or standard BOM workbook<input className="form-input" type="file" accept=".xlsx,.xls,.csv" onChange={(event) => void readFile(event.target.files?.[0])}/></label>
    {fileName && <div className="import-file-summary"><FileSpreadsheet size={15}/><span>{fileName}</span><strong>{rows.length} rows</strong></div>}
    {errors.length > 0 && <div className="import-errors"><strong>Needs attention</strong>{errors.slice(0, 8).map((error) => <span key={error}>{error}</span>)}{errors.length > 8 && <span>and {errors.length - 8} more issue(s)</span>}</div>}
    {rows.length > 0 && errors.length === 0 && <><div className="import-success"><ShieldCheck size={14}/> Preview is structurally valid. Parent-child links will follow the level columns and row order.</div><div className="import-preview-scroll"><table className="import-preview-table"><thead><tr><th>Excel row</th><th>Level</th><th>Part number</th><th>Part name</th><th>Qty / parent</th></tr></thead><tbody>{rows.slice(0, 12).map((row) => <tr key={`${row.source_row}-${row.item_number}`}><td>{row.source_row}</td><td>{row.level}</td><td>{row.item_number}</td><td>{row.name}</td><td>{Number(row.quantity.toFixed(4))}</td></tr>)}</tbody></table>{rows.length > 12 && <small>Showing 12 of {rows.length} rows</small>}</div><p className="import-note">Matching part numbers reuse their item master. New item masters are created only at commit. The importer will not overwrite existing item data. Import is all-or-nothing.</p></>}
    <div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={busy || !rows.length || errors.length > 0} onClick={() => void submit()}>{busy ? 'Importing…' : `Import ${rows.length || ''} BOM rows`}</button></div>
  </Modal>
}

function NewProjectModal({ onClose, onCreate }: {onClose: () => void; onCreate: (itemNumber: string, name: string) => Promise<void>}) {
  const [itemNumber, setItemNumber] = useState('')
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  async function submit() {
    if (!itemNumber.trim() || !name.trim()) { setError('Enter a product item number and project name.'); return }
    setBusy(true); setError('')
    try { await onCreate(itemNumber.trim(), name.trim()) }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not create Product BOM'); setBusy(false) }
  }
  return <Modal onClose={onClose} title="Create new Product BOM / Project" subtitle="Creates a new main product with revision A in work and an empty engineering BOM.">
    <label className="field-label">Product item number<input className="form-input" autoFocus placeholder="e.g. DEMO-002" value={itemNumber} onChange={(event) => setItemNumber(event.target.value)}/></label>
    <label className="field-label">Project / product name<input className="form-input" placeholder="e.g. Compact Conveyor" value={name} onChange={(event) => setName(event.target.value)}/></label>
    <div className="revision-hint"><Package size={15}/> Creates a separate product workspace. The item master and BOM are saved locally.</div>
    {error && <div className="form-error">{error}</div>}
    <div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={busy} onClick={() => void submit()}>{busy ? 'Creating…' : 'Create Product BOM'}</button></div>
  </Modal>
}

function ExistingModal({ items, onClose, onAdd }: {items: Item[]; onClose: () => void; onAdd: (item: Item, rev: string, qty: number) => Promise<void>}) {
  const [query, setQuery] = useState('')
  const [chosen, setChosen] = useState<Item | null>(null)
  const [revisionId, setRevisionId] = useState('')
  const [quantity, setQuantity] = useState('1')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const matches = items.filter((item) => `${item.item_number} ${item.name}`.toLowerCase().includes(query.toLowerCase()))
  async function submit() {
    if (!chosen || !revisionId) {setError('Choose an item and revision.'); return}
    setBusy(true); setError('')
    try {await onAdd(chosen, revisionId, Number(quantity))} catch(reason) {setError(reason instanceof Error ? reason.message : 'Could not add item'); setBusy(false)}
  }
  return <Modal onClose={onClose} title="Add existing item" subtitle="Reuse an item master record in this assembly.">
    <label className="field-label">Find item<input className="form-input" placeholder="Item number or name" value={query} onChange={(e) => setQuery(e.target.value)}/></label>
    <div className="item-picker">{matches.map((item) => <button className={chosen?.id === item.id ? 'picker-row chosen' : 'picker-row'} key={item.id} onClick={() => {setChosen(item); setRevisionId(item.revisions[0]?.id ?? '')}}><span className="mini-item-icon blue"><Component size={15}/></span><span><strong>{item.name}</strong><small>{item.item_number} · {item.item_type}</small></span><span className="picker-rev">{item.revisions[0]?.revision_code ?? '—'}</span></button>)}{!matches.length && <div className="picker-empty">No items match the search.</div>}</div>
    {chosen && <div className="form-row"><label className="field-label">Revision<select className="form-input" value={revisionId} onChange={(e) => setRevisionId(e.target.value)}>{chosen.revisions.map((rev) => <option key={rev.id} value={rev.id}>{rev.revision_code} · {rev.state}</option>)}</select></label><label className="field-label">Quantity<input className="form-input" type="number" min="0.001" step="any" value={quantity} onChange={(e) => setQuantity(e.target.value)}/></label></div>}
    {error && <div className="form-error">{error}</div>}<div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={busy || !chosen} onClick={() => void submit()}>{busy ? 'Adding…' : 'Add to assembly'}</button></div>
  </Modal>
}

function CreateItemModal({ onClose, onCreate, onCreateOnly, asChild }: {onClose: () => void; onCreate: (payload: Record<string, unknown>, quantity: number) => Promise<void>; onCreateOnly: (payload: Record<string, unknown>) => Promise<void>; asChild: boolean}) {
  const [itemNumber, setItemNumber] = useState('')
  const [name, setName] = useState('')
  const [itemType, setItemType] = useState('PART')
  const [scope, setScope] = useState('In-house Manufacturing')
  const [process, setProcess] = useState('Machining')
  const [quantity, setQuantity] = useState('1')
  const [mass, setMass] = useState('')
  const [cost, setCost] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const payload = () => ({ item_number: itemNumber.trim(), name: name.trim(), item_type: itemType, revision_code: 'A', scope, manufacturing_process: process, mass: mass ? Number(mass) : null, mass_source: mass ? 'USER_ENTERED' : null, unit_cost: cost ? Number(cost) : null })
  async function submit(addToParent: boolean) {
    if (!itemNumber.trim() || !name.trim()) {setError('Item number and name are required.'); return}
    setBusy(true); setError('')
    try { if(addToParent && asChild) await onCreate(payload(), Number(quantity)); else await onCreateOnly(payload()) }
    catch(reason) {setError(reason instanceof Error ? reason.message : 'Could not create item'); setBusy(false)}
  }
  return <Modal onClose={onClose} title={asChild ? 'Create and add item' : 'Create engineering item'} subtitle="This creates a new item identity with its first working revision.">
    <div className="form-row"><label className="field-label">Item number<input className="form-input" autoFocus placeholder="e.g. DEMO-PRT-012" value={itemNumber} onChange={(e) => setItemNumber(e.target.value)}/></label><label className="field-label">Item type<select className="form-input" value={itemType} onChange={(e) => setItemType(e.target.value)}>{kinds.map((kind) => <option key={kind}>{kind}</option>)}</select></label></div>
    <label className="field-label">Item name<input className="form-input" placeholder="Component or assembly name" value={name} onChange={(e) => setName(e.target.value)}/></label>
    <div className="form-row"><label className="field-label">Scope<select className="form-input" value={scope} onChange={(e) => setScope(e.target.value)}>{scopes.map((value) => <option key={value}>{value}</option>)}</select></label><label className="field-label">Manufacturing method<select className="form-input" value={process} onChange={(e) => setProcess(e.target.value)}><option value="">Not assigned</option>{processes.map((value) => <option key={value}>{value}</option>)}</select></label></div>
    <div className="form-row"><label className="field-label">Mass <span className="field-hint">kg · optional</span><input className="form-input" type="number" min="0" step="any" value={mass} onChange={(e) => setMass(e.target.value)}/></label><label className="field-label">Unit cost <span className="field-hint">optional</span><input className="form-input" type="number" min="0" step="any" value={cost} onChange={(e) => setCost(e.target.value)}/></label></div>
    {asChild && <label className="field-label short-field">Quantity in selected assembly<input className="form-input" type="number" min="0.001" step="any" value={quantity} onChange={(e) => setQuantity(e.target.value)}/></label>}
    <div className="revision-hint"><GitBranch size={15}/> First revision will be <strong>A · IN WORK</strong></div>
    {error && <div className="form-error">{error}</div>}<div className="modal-actions"><button className="secondary-button" onClick={onClose}>Cancel</button><button className="primary-button" disabled={busy} onClick={() => void submit(asChild)}>{busy ? 'Saving…' : asChild ? 'Create and add' : 'Create item'}</button></div>
  </Modal>
}

function Modal({ title, subtitle, onClose, children }: {title: string; subtitle: string; onClose: () => void; children: React.ReactNode}) {
  return <div className="modal-backdrop" onMouseDown={onClose}><section className="modal-card" onMouseDown={(e) => e.stopPropagation()}><div className="modal-title-row"><div><h2>{title}</h2><p>{subtitle}</p></div><button className="icon-button" onClick={onClose}><X size={18}/></button></div>{children}</section></div>
}

export default App
