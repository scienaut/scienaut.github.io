Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
projectFolder = files.GetParentFolderName(WScript.ScriptFullName)
launcher = Chr(34) & projectFolder & "\start_application.bat" & Chr(34)
shell.Run launcher, 0, False
