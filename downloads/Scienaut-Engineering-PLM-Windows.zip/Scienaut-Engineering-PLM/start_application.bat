@echo off
setlocal
cd /d "%~dp0"
if not defined ENGINEERING_PLM_DATA_ROOT set "ENGINEERING_PLM_DATA_ROOT=%~dp0local_data"

if not exist "backend\.venv\Scripts\python.exe" (
    py -m venv backend\.venv
    if errorlevel 1 goto :failed
)
backend\.venv\Scripts\python.exe -c "import fastapi, openpyxl"
if errorlevel 1 (
    backend\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
    if errorlevel 1 goto :failed
)
if not exist "frontend\node_modules\vite" (
    pushd frontend
    call npm install --no-audit --no-fund
    if errorlevel 1 goto :failed_pop
    popd
)

pushd backend
.venv\Scripts\python.exe -m alembic upgrade head
if errorlevel 1 goto :failed_pop
.venv\Scripts\python.exe -m scripts.seed_demo
if errorlevel 1 goto :failed_pop
popd

echo.
echo Starting Engineering PLM local workspace...
echo Your browser will open at http://127.0.0.1:5173
echo Keep this window open. Press Ctrl+C here to stop the application.
echo.
backend\.venv\Scripts\python.exe backend\scripts\run_local.py
goto :eof

:failed_pop
popd
:failed
echo.
echo Startup failed. Review the message above, then try again.
pause
exit /b 1
