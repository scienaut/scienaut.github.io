# Engineering PLM/PDM — local workspace

Scienaut Engineering PLM Solutions is a free, open-source, local-first engineering workspace. It provides a browser-based PLM interface backed by a local Python service and SQLite database. The API documentation is a developer aid; the application is the browser interface.

## Run on Windows 10/11

1. On this computer, open the project folder and double-click **Open Engineering PLM.lnk**. It calls [`Open_Engineering_PLM.vbs`](Open_Engineering_PLM.vbs) and opens the app in your browser. The `.lnk` is a computer-specific shortcut and is excluded from the public source. After downloading the source elsewhere, double-click `Open_Engineering_PLM.vbs` instead. You can run [`start_application.bat`](start_application.bat) directly to see startup messages.
2. On first launch it creates the Python environment, installs the frontend packages, runs database migrations, and adds a synthetic demo BOM only when no product exists yet. Allow the dependency installation to finish.
3. The engineering workspace opens in your browser at a local address (normally `http://127.0.0.1:5173`).
4. The local API and browser UI run while you use the app. Keep the launcher window open; press **Ctrl+C** there to stop the app. The `.lnk` shortcut starts the launcher with a hidden console.

If a default port is already in use, the launcher selects the next available local port and opens that address. API and UI logs are stored in `local_data/Logs/`.

The local API docs are a secondary developer tool at `http://127.0.0.1:<api-port>/api/v1/docs`.

## Local data location

The app stores data locally at `local_data/Database/engineering_plm.sqlite3`. Engineering document attachments are stored as SQLite blobs, so database backups include files and their item/revision links. It does not currently have user accounts or role-based access control; the intended setup is a single local computer.

To use another local drive, set `ENGINEERING_PLM_DATA_ROOT` before launching, for example:

```powershell
$env:ENGINEERING_PLM_DATA_ROOT = 'D:\EngineeringPLM\Data'
& 'C:\path\to\project\start_application.bat'
```

The database is stored in `Database/engineering_plm.sqlite3`. Startup checks for a complete existing PLM schema and records it with Alembic without deleting its engineering data.

## Current engineering workspace

- **Overview:** local item, assembly, and occurrence counts.
- **Product structure:** searchable hierarchical tree, selected item properties, direct EBOM table, live quantity updates, component reuse, safe occurrence removal, two Excel layouts, and browser print-to-PDF.
- **BOM data entry:** Excel-style full BOM register, hierarchy-level editing, Excel import with preview, and export.
- **BOM mind map:** vertical/horizontal layouts, zoom and pan, item details, and repeated-use links.
- **Item master and where-used:** searchable item identities and every parent/product path where an item is used.
- **Revisions & changes:** compare revision properties and BOM structure, review the audit history, create a working revision by copying the latest released data and BOM links, and release it under child-before-parent rules.
- **Change notices:** create scoped change notices and move them through review/approval/implementation. Implementation requires the affected items to have newer released revisions.
- **Engineering documents:** attach/download/remove common engineering file types for an item or revision. Files are limited to 100 MB each and store a SHA-256 checksum.
- **Backup & restore:** create verified SQLite backups and restore with an automatic pre-restore safety copy. Restoring an older supported backup applies current database migrations.
- **User manual:** step-by-step illustrated guide available from the left navigation, with Word and PDF downloads.

In **Product structure**, choose **Export Excel** and select either **Engineering PLM standard** (product summary and expanded multi-level EBOM) or **Engineering Management template** (the alternate register with Level 1–9 and the provided engineering columns). The alternate template title defaults to “Retearn Engineering Management”; edit the title in the export dialog, and it will be remembered in this browser. Its metadata cells remain editable in Excel. Choose **Save as PDF** and select the browser's **Save as PDF** destination in the print dialog; the print layout contains the selected assembly BOM.

Items are shared identities; BOM placements are separate occurrences. Removing an occurrence preserves the item master. A parent must be an in-work product or assembly to accept BOM changes. Demo mass and cost entries are illustrative inputs and are not engineering reference data. Releasing an assembly requires all referenced child revisions to be released first.

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE).

## Developer commands

```powershell
cd backend
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

```powershell
cd frontend
npm run build
```

See [the implementation plan](docs/implementation-plan.md) for architecture, delivered features, and deferred scope. Native CAD viewing/parsing, multi-user accounts and permissions, MBOM/procurement/service BOM workflows, and cloud hosting remain future work.

The illustrated [Scienaut Product User Manual](docs/Scienaut-Engineering-PLM-User-Manual.pdf) is available as a PDF and editable Word file in `docs/`. The same files are bundled into the app so the **User manual** link in the left navigation opens the guide in the browser.
