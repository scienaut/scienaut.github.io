from pathlib import Path
from html import escape
from docx import Document
from docx.oxml.ns import qn
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
DOCX = ROOT / "docs" / "Scienaut-Engineering-PLM-User-Manual.docx"
PDF = ROOT / "docs" / "Scienaut-Engineering-PLM-User-Manual.pdf"
ASSETS = ROOT / "docs" / "user-manual-assets"

pdfmetrics.registerFont(TTFont("Arial", r"C:\Windows\Fonts\arial.ttf"))
pdfmetrics.registerFont(TTFont("Arial-Bold", r"C:\Windows\Fonts\arialbd.ttf"))
pdfmetrics.registerFont(TTFont("Arial-Italic", r"C:\Windows\Fonts\ariali.ttf"))
pdfmetrics.registerFontFamily("Arial", normal="Arial", bold="Arial-Bold", italic="Arial-Italic", boldItalic="Arial-Bold")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="BodyPLM", parent=styles["BodyText"], fontName="Arial", fontSize=9.7, leading=13.2, spaceAfter=5, textColor=colors.HexColor("#1F2937")))
styles.add(ParagraphStyle(name="TitlePLM", parent=styles["Title"], fontName="Arial-Bold", fontSize=29, leading=34, textColor=colors.black, alignment=TA_LEFT, spaceAfter=7))
styles.add(ParagraphStyle(name="SubtitlePLM", parent=styles["BodyText"], fontName="Arial", fontSize=14, leading=19, textColor=colors.HexColor("#40536D"), spaceAfter=13))
styles.add(ParagraphStyle(name="H1PLM", parent=styles["Heading1"], fontName="Arial-Bold", fontSize=18, leading=22, textColor=colors.black, spaceBefore=4, spaceAfter=8, keepWithNext=True))
styles.add(ParagraphStyle(name="H2PLM", parent=styles["Heading2"], fontName="Arial-Bold", fontSize=12, leading=15, textColor=colors.black, spaceBefore=8, spaceAfter=4, keepWithNext=True))
styles.add(ParagraphStyle(name="CaptionPLM", parent=styles["BodyText"], fontName="Arial-Italic", fontSize=8, leading=10, textColor=colors.HexColor("#64748B"), alignment=TA_CENTER, spaceAfter=8))
styles.add(ParagraphStyle(name="BrandPLM", parent=styles["BodyText"], fontName="Arial-Bold", fontSize=10, leading=14, textColor=colors.HexColor("#426EAF"), spaceAfter=4))
styles.add(ParagraphStyle(name="ListPLM", parent=styles["BodyText"], fontName="Arial", fontSize=9.6, leading=13, leftIndent=19, firstLineIndent=-14, spaceAfter=3, textColor=colors.HexColor("#1F2937")))

doc = Document(DOCX)
story = []
image_files = ["product-structure.png", "product-structure.png", "bom-data-entry.png", "bom-level-editing.png", "bom-mind-map.png"]
image_index = 0
number_index = 0
bullet_index = 0

def run_markup(paragraph):
    parts = []
    for run in paragraph.runs:
        text = escape(run.text).replace("\n", "<br/>")
        if not text:
            continue
        if run.bold:
            text = f"<b>{text}</b>"
        if run.italic:
            text = f"<i>{text}</i>"
        parts.append(text)
    return "".join(parts)

for p in doc.paragraphs:
    ppr = p._p.pPr
    page_break = bool(p._p.xpath('.//w:br[@w:type="page"]'))
    if page_break:
        story.append(PageBreak())
        number_index = bullet_index = 0
        continue
    has_drawing = bool(p._p.xpath('.//w:drawing'))
    if has_drawing:
        if image_index < len(image_files):
            image_path = ASSETS / image_files[image_index]
            image_index += 1
            img = Image(str(image_path))
            max_w, max_h = 7.0 * inch, 4.75 * inch
            scale = min(max_w / img.imageWidth, max_h / img.imageHeight, 1)
            img.drawWidth = img.imageWidth * scale
            img.drawHeight = img.imageHeight * scale
            img.hAlign = "CENTER"
            story.append(Spacer(1, 4))
            story.append(KeepTogether([img]))
        continue
    text = run_markup(p)
    if not text.strip():
        continue
    style_name = p.style.name if p.style else "Normal"
    if style_name == "Title":
        story.append(Paragraph(text, styles["TitlePLM"]))
    elif style_name == "Subtitle":
        story.append(Paragraph(text, styles["SubtitlePLM"]))
    elif style_name.startswith("Heading 1"):
        story.append(Paragraph(text, styles["H1PLM"]))
        number_index = bullet_index = 0
    elif style_name.startswith("Heading 2"):
        story.append(Paragraph(text, styles["H2PLM"]))
    elif style_name == "Caption":
        story.append(Paragraph(text, styles["CaptionPLM"]))
    elif style_name.startswith("List Number"):
        number_index += 1
        story.append(Paragraph(f"{number_index}.&nbsp;&nbsp;{text}", styles["ListPLM"]))
    elif style_name.startswith("List Bullet"):
        bullet_index += 1
        marker = "[ ]" if "☐" in text else "•"
        clean = text.replace("☐ ", "")
        story.append(Paragraph(f"{marker}&nbsp;&nbsp;{clean}", styles["ListPLM"]))
    elif text.startswith("SCIENAUT ENGINEERING PLM SOLUTIONS"):
        story.append(Paragraph(text, styles["BrandPLM"]))
    else:
        story.append(Paragraph(text, styles["BodyPLM"]))

def draw_footer(canvas, document):
    canvas.saveState()
    canvas.setFont("Arial", 7.5)
    canvas.setFillColor(colors.HexColor("#64748B"))
    canvas.drawString(0.72 * inch, 0.42 * inch, "SCIENAUT ENGINEERING PLM SOLUTIONS  |  PRODUCT USER MANUAL")
    canvas.drawRightString(7.78 * inch, 0.42 * inch, f"Page {document.page}")
    canvas.restoreState()

pdf = SimpleDocTemplate(str(PDF), pagesize=letter, rightMargin=0.72 * inch, leftMargin=0.72 * inch,
                        topMargin=0.63 * inch, bottomMargin=0.68 * inch,
                        title="Scienaut Engineering PLM Solutions Product User Manual",
                        author="Scienaut Engineering PLM Solutions")
pdf.build(story, onFirstPage=draw_footer, onLaterPages=draw_footer)
print(PDF)
