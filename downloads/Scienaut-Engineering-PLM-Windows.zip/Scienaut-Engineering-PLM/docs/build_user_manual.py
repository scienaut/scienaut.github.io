from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "Scienaut-Engineering-PLM-User-Manual.docx"
ASSETS = ROOT / "docs" / "user-manual-assets"

doc = Document()
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
section.top_margin = Inches(0.68)
section.bottom_margin = Inches(0.68)
section.left_margin = Inches(0.72)
section.right_margin = Inches(0.72)

NAVY = "1B2A3B"
BLUE = "426EAF"
MUTED = "64748B"
number_counter = 0

styles = doc.styles
normal = styles["Normal"]
normal.font.name = "Aptos"
normal.font.size = Pt(10.5)
normal.font.color.rgb = RGBColor(31, 41, 55)
normal.paragraph_format.space_after = Pt(6)
normal.paragraph_format.line_spacing = 1.12
for name, size in (("Title", 30), ("Subtitle", 14), ("Heading 1", 20), ("Heading 2", 13), ("Heading 3", 11)):
    style = styles[name]
    style.font.name = "Aptos Display" if name != "Subtitle" else "Aptos"
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor(0, 0, 0)
    if name.startswith("Heading"):
        style.font.bold = True
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(11 if name == "Heading 1" else 7)
        style.paragraph_format.space_after = Pt(4)


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), fill)
    tc_pr.append(shading)


def footer_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run("Page ")
    run.font.size = Pt(8)
    run.font.color.rgb = RGBColor.from_string(MUTED)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    paragraph._p.append(field)


footer = section.footer.paragraphs[0]
footer.text = "SCIENAUT ENGINEERING PLM SOLUTIONS  |  PRODUCT USER MANUAL"
footer.runs[0].font.name = "Aptos"
footer.runs[0].font.size = Pt(8)
footer.runs[0].font.color.rgb = RGBColor.from_string(MUTED)
footer_page_number(section.footer.add_paragraph())


def para(text="", bold_prefix=None, style=None):
    p = doc.add_paragraph(style=style)
    if bold_prefix and text.startswith(bold_prefix):
        p.add_run(bold_prefix).bold = True
        p.add_run(text[len(bold_prefix):])
    else:
        p.add_run(text)
    return p


def bullet(text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(3)
    p.add_run(text)
    return p


def numbered(text):
    global number_counter
    number_counter += 1
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.28)
    p.paragraph_format.first_line_indent = Inches(-0.22)
    p.paragraph_format.space_after = Pt(4)
    p.add_run(f"{number_counter}. ").bold = True
    p.add_run(text)
    return p


def image(filename, caption, width=7.0, alt="Scienaut Engineering PLM Solutions screen"):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(2)
    run = p.add_run()
    picture = run.add_picture(str(ASSETS / filename), width=Inches(width))
    picture._inline.docPr.set("descr", alt)
    cap = doc.add_paragraph(caption, style="Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(7)
    for r in cap.runs:
        r.font.name = "Aptos"
        r.font.size = Pt(8.5)
        r.font.italic = True
        r.font.color.rgb = RGBColor.from_string(MUTED)


def h1(text):
    global number_counter
    number_counter = 0
    doc.add_heading(text, level=1)


def h2(text):
    global number_counter
    number_counter = 0
    doc.add_heading(text, level=2)


# Cover
p = doc.add_paragraph()
p.paragraph_format.space_before = Pt(26)
p.paragraph_format.space_after = Pt(5)
r = p.add_run("SCIENAUT ENGINEERING PLM SOLUTIONS")
r.bold = True
r.font.name = "Aptos"
r.font.size = Pt(11)
r.font.color.rgb = RGBColor.from_string(BLUE)

title = doc.add_paragraph(style="Title")
title.paragraph_format.space_after = Pt(7)
title.add_run("Product User Manual")
subtitle = doc.add_paragraph(style="Subtitle")
subtitle.paragraph_format.space_after = Pt(14)
subtitle.add_run("A practical guide to creating and managing your local engineering BOM")
para("Start the application, create a product, build its assembly and part relationships, review revisions, attach engineering files, export reports, and protect your local data.")
image("product-structure.png", "Product structure example. This earlier screen capture uses the former Forge brand name; the current application is branded Scienaut.", 6.95,
      "Product structure screen showing an assembly tree, selected assembly BOM, and item properties")
para("Version 1.0  |  20 November 2026", bold_prefix="Version 1.0")
para("Screenshots are included to help locate controls. Their displayed product names and values belong to the captured workspace; use your own approved engineering data.")
doc.add_page_break()

# Getting started
h1("1. Start the application")
para("Scienaut runs as a browser interface connected to a local service and a SQLite database on this computer. Keep the launcher running while you use the application.")
h2("Open Scienaut")
numbered("Double-click Open Engineering PLM.lnk in the project folder. If you downloaded the source on another computer and the shortcut is missing, double-click Open_Engineering_PLM.vbs or run start_application.bat.")
numbered("On first run, allow the launcher to prepare Python and frontend dependencies and apply database updates. Keep the launcher window open until the browser opens.")
numbered("The app normally opens at http://127.0.0.1:5173. The page should show the LOCAL badge and a green Local database status.")
numbered("To stop the version started from start_application.bat, return to its window and press Ctrl+C. Start it again with the same shortcut when you need it.")
para("If the browser says it cannot connect, check that the launcher is still running. Review local_data/Logs/backend.log if startup failed. A different port may be chosen when the usual port is already occupied.", bold_prefix="If the browser says it cannot connect,")
h2("Understand the workspace")
bullet("The left column opens the product structure, BOM data entry, BOM mind map, item master, revisions, change notices, where-used, backups, engineering documents, and this manual.")
bullet("The workspace selector chooses which main Product BOM is active. The + button beside it creates another Product BOM / project.")
bullet("Data is stored on this computer. The app does not sync data to GitHub, a website, or another computer.")

doc.add_page_break()
h1("2. Create a Product BOM")
para("A Product BOM is the top-level product identity and its engineering structure. Create one for each distinct product project.")
numbered("In the left workspace panel, click +. If no product exists yet, use Create main product in the empty Product structure page.")
numbered("Enter a unique Product item number and a clear project or product name.")
numbered("Click Create Product BOM. The app creates the main product at revision A in work and opens its workspace.")
numbered("Use the workspace selector to switch between Product BOMs later. Check the selected product name and number in the top bar before editing.")
para("Choose item numbers that match your drawing and company conventions. Item numbers identify shared items across every assembly that uses them.", bold_prefix="Choose item numbers")
h2("Create or reuse components")
bullet("Use Add part / assembly in BOM data entry or Add component / Add line in Product structure to add a child.")
bullet("Create a new item when it is a new part or assembly. Reuse an existing item when the same physical/design item appears in another assembly.")
bullet("Choose the appropriate item type, such as MAIN ASSEMBLY, SUB ASSEMBLY, CHILD ASSEMBLY, PART, FASTENER, or BOUGHT-OUT COMPONENT.")
bullet("For custom classifications or system names, enter the text when the UI offers a custom option. Confirm the value before saving.")
para("A shared item has one item master record and may have many BOM occurrences. Each occurrence stores its own parent, find number, quantity, and system assignment.")

doc.add_page_break()
h1("3. Build the assembly structure")
para("Build from the top product downward. Select the assembly that should own a component before adding that component. This establishes the parent-child BOM relationship.")
numbered("Open Product structure and select the target product or assembly in the tree.")
numbered("Click Add component / Add line. Choose an existing item or create a new component, then choose its revision, find number, and quantity where requested.")
numbered("Repeat inside each subassembly to add its own children. A part, fastener, or bought-out component is normally a leaf and does not contain children.")
numbered("Use the tree and the selected assembly's direct BOM table to confirm where each component was added.")
image("product-structure.png", "The assembly tree shows parent and child items. The center table lists only the selected assembly's direct components.", 6.9,
      "Product structure page with nested assembly tree and direct component table")
h2("How levels work")
para("In BOM data entry, Level 1 is the main product. Level 2 is directly under the product, Level 3 is under an assembly at Level 2, and so on. A component placed at Level 3 is linked to the nearest applicable in-work assembly at the preceding level.")
para("To move a row, edit its level number in that row. The app moves the occurrence under the appropriate assembly and keeps the BOM relationship in sync. If more than one parent assembly could apply, follow the app's prompt or choose the intended assembly in Product structure.")
para("Only assemblies can own child occurrences. The app blocks invalid circular relationships and protects released revisions from edits.", bold_prefix="Only assemblies")

doc.add_page_break()
h1("4. Enter and correct BOM data in the table")
para("Open BOM data entry from the left navigation for a full Excel-style register. Each row is a BOM occurrence; shared parts may therefore appear on more than one row.")
image("bom-data-entry.png", "Excel-style BOM entry screen with editable levels and engineering columns.", 6.95,
      "BOM data entry spreadsheet with hierarchy level columns, part number, revision, quantity, and engineering fields")
h2("Work in the register")
numbered("Use Add part / assembly to add an item. A row is created for each occurrence in the structure.")
numbered("Edit cells and leave the cell to save. Check the displayed success message and confirm the row still appears under the expected parent.")
numbered("Use the filter to find a part number, item name, or system. Use the horizontal and vertical scrollbars to reach additional columns and rows.")
numbered("Change a level cell to move an occurrence. The stored parent-assembly relation updates with the level. Four levels are shown initially; add or remove trailing level columns with the + and - controls in the last level heading.")
numbered("Correct a wrong part number directly in the Part Number field. This changes the shared item identity everywhere that item is used, so verify the row and item before saving.")
h2("Important quantity distinction")
para("The table can show Quantity per Product, which is a roll-up through the structure. The parent occurrence quantity is stored on the BOM line. If a rolled-up quantity looks wrong, inspect the quantities and parent levels in the assembly tree instead of editing a calculated total as if it were a direct quantity.")
doc.add_page_break()
h2("Adjust the visible level columns")
para("Use + in the last visible level heading to add a deeper level when the product needs it. Use - in that same final heading to remove one trailing level column. The setting is remembered per product. Remove a column only when the rows no longer need that depth, then verify the part-to-assembly links in Product structure.")
para("The level cells remain editable even when a level column is added or removed. Changing a row's level updates its parent relationship; adding a column only changes how many hierarchy depths are shown in the table.")
image("bom-level-editing.png", "Hierarchy level cells and controls for adding or removing level columns.", 6.85,
      "BOM table showing the plus and minus controls on the last visible level column")

doc.add_page_break()
h1("5. Explore the BOM mind map")
para("Choose BOM mind map from the left navigation to view parent-child relationships visually. Use the orientation control to switch between vertical and horizontal layouts. Scroll or pan across a large BOM, and use zoom controls to fit more of the structure on screen.")
numbered("Click a node to open its details, including its item data and BOM occurrence context.")
numbered("Follow solid connectors to see the parent-child structure in the selected product BOM.")
numbered("A thin dotted connector marks a reused item that also occurs in another assembly. It is a reuse reference; it does not replace the solid parent-child BOM links.")
image("bom-mind-map.png", "Mind map example. Red arrows are annotations on the shared capture; dotted links in the app indicate item reuse.", 5.45,
      "Dark mind map view showing product and component nodes connected by level relationships")
para("If the map seems too crowded, zoom out, pan to the product root, and check the active product selector. The map reflects the selected product's current BOM relationships. Solid connectors show direct parent-child occurrences; thin dotted connectors identify the same item used in more than one assembly.")

doc.add_page_break()
h1("6. Revisions and controlled release")
para("Use Revisions & changes to compare revisions, review the audit history, create a working revision, and release items. Select a product, assembly, or part using the item selector on that page.")
h2("Release an existing working revision")
numbered("Select a child part or component and click Release when its data is ready.")
numbered("Release child components before their parent assembly. An assembly release is blocked until every BOM child points to a released revision.")
numbered("Select the parent assembly and release it after its children. Continue upward until the product can be released.")
h2("Create the next revision")
numbered("Select an item whose current revision is released, enter the next revision code, and choose Create working revision.")
numbered("The new revision copies the latest released engineering properties and exact BOM occurrence links. Edit the new in-work revision, then compare it to the prior revision.")
numbered("Release the updated child revisions first, then release the assemblies that reference them.")
para("Released revisions are locked. Do not release a revision until its item data, children, quantities, and attached documents have been checked. If a release is blocked, read the message and release or correct the listed child first.", bold_prefix="Released revisions are locked.")

doc.add_page_break()
h1("7. Manage change notices")
para("A change notice records why a change is needed, which items are affected, and the status of review and implementation.")
numbered("Open Change notices and create a notice with a unique ECN number, a concise title, a reason, and a description for each affected item.")
numbered("Move the notice from DRAFT to IN REVIEW and then APPROVED when your engineering review is complete.")
numbered("Create and release the affected item revisions. The released revisions must be newer than the baseline captured on the notice.")
numbered("Move the approved notice to IMPLEMENTED only after the app confirms the released revision gate is met. Cancel a notice only before implementation if it is no longer needed.")
para("The software records the local workflow state. It does not provide user accounts, electronic signatures, or multi-person approval permissions.", bold_prefix="The software records")
h1("8. Attach engineering documents")
para("Open Engineering documents in the left navigation. Select the item, optionally link a revision, add a short description, and attach a supported file. Files are limited to 100 MB each.")
bullet("Supported examples include PDF, Excel, CSV, Word, images, STEP/STP, IGES/IGS, DXF/DWG, STL, 3MF, and ZIP.")
bullet("Use Download to retrieve the stored copy. The app records the name, type, size, checksum, item/revision association, and attachment/removal audit events.")
bullet("Delete an attachment only when it should be removed from the active local database. Previously created backups retain their own saved copy.")
para("Document bytes are stored inside SQLite, so a database backup includes the files and their item/revision links.")

doc.add_page_break()
h1("9. Find, export, and protect data")
h2("Find where an item is used")
para("Open Where used, search for an item number or name, and select the item. Review each parent path and its rolled-up quantity before changing a shared part or assembly.")
h2("Export or print")
bullet("From Product structure, use Export Excel to choose the standard engineering layout or the Engineering Management template. The template title can be renamed in the export dialog.")
bullet("Use Save as PDF and choose the browser's Save as PDF destination to print the selected assembly BOM.")
bullet("An exported workbook is a separate file. Editing it does not change the local database. To bring spreadsheet data into the app, use the BOM import flow, review the preview and validation messages, then import.")
h2("Create a backup and restore")
numbered("Open Backup & restore and choose Create backup now before a large import, revision release, or workspace change.")
numbered("To restore, select a listed backup and read the warning. The app creates a safety copy of the current database before replacing it.")
numbered("After restore, check the product selector and inspect a few BOM paths, revisions, and attachments.")
para("Backups are local SQLite copies. Copy them to a separate safe drive if you need protection against computer or disk failure. A backup stored only on the same disk is not an off-device backup.", bold_prefix="Backups are local SQLite copies.")

doc.add_page_break()
h1("10. Warnings and things to avoid")
h2("Protect item and BOM relationships")
bullet("Do not create a duplicate item master for a component that is already in the database. Search first, then reuse the existing item.")
bullet("Do not change a shared part number unless you intend to correct it everywhere it is used. Check Where used before global corrections.")
bullet("Do not remove a whole Product BOM to remove one component. Remove the component occurrence from its parent assembly; the shared item master remains.")
bullet("Deleting a Product BOM is permanent for that product's top-level workspace and occurrence structure. Read the confirmation dialog before proceeding.")
bullet("Do not edit released revisions. Create a new working revision and preserve the old released record.")
h2("Understand local-only operation")
bullet("This build is for one local computer. It has no account system, shared online database, remote backup, or concurrent multi-user protection.")
bullet("Do not put the active SQLite database in a cloud-synced folder or open the same database from multiple computers.")
bullet("CAD vault navigation is not a full CAD viewer or CAD file parser. Attach and download supported documents in Engineering documents instead.")
bullet("Do not treat demo values as engineering authority. Verify all dimensions, materials, quantities, costs, and released revisions against your controlled source data.")
h2("Quick troubleshooting")
para("Request failed or the page does not load: make sure the launcher is still running, wait for startup to finish, then reload the browser page. If the problem remains, check local_data/Logs/backend.log and restart with the launcher.", bold_prefix="Request failed or the page does not load:")
para("A component appears at the wrong level: return to BOM data entry, edit its level cell, and confirm its parent assembly in Product structure.", bold_prefix="A component appears at the wrong level:")
para("Release is blocked: select the referenced child item in Revisions & changes, release it first, then retry the parent.", bold_prefix="Release is blocked:")
para("Restore is blocked: choose a backup shown in the app's local list and retain the safety backup for recovery.", bold_prefix="Restore is blocked:")
h2("Before you finish an engineering update")
for entry in [
    "Confirm the active Product BOM and item numbers.",
    "Check each component's parent assembly, level, find number, and quantity.",
    "Review shared items in Where used before global edits.",
    "Compare the working revision and verify attached drawing files.",
    "Create a local backup before releasing or importing major changes.",
]:
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(3)
    r = p.add_run("☐ " + entry)
    r.font.name = "Aptos"

doc.core_properties.title = "Scienaut Engineering PLM Solutions Product User Manual"
doc.core_properties.subject = "Start-to-finish guide to the local engineering PLM application"
doc.core_properties.author = "Scienaut Engineering PLM Solutions"
doc.save(OUT)
print(OUT)
