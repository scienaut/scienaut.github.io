# Scienaut Engineering PLM Solutions: implementation status

## Product shape

The first release is a single-computer Windows application with a browser interface, a local Python API process, and a SQLite database. A user starts it from the project shortcut or launcher. Product records and attachments remain on that computer unless the user exports or copies a backup. The local API docs are for development and are not the intended product UI.

## Delivered capabilities

1. **Engineering BOM workspace:** shared item identities and revisions, assembly occurrence relationships, quantity roll-up, Excel-style BOM data entry, level editing, hierarchical structure and mind map, export/import, and PDF print layout.
2. **Engineering change visibility:** item and occurrence audit events, revision-to-revision comparison, working revision creation from the latest released revision, and controlled release with child-before-parent validation.
3. **Change notices:** scoped ECNs with draft, review, approval, implementation, and cancel transitions. Implementation checks that affected items have a released revision newer than the captured baseline.
4. **Impact analysis:** where-used walks every parent path and reports rolled-up quantities for reused parts and assemblies.
5. **Data recovery:** verified SQLite backups, safety backup before restore, and migration of restored older databases to the current schema.
6. **Engineering documents:** local item/revision attachments with file name, type, size, description, checksum, download and deletion. SQLite storage means each backup captures the matching attachment data as well as metadata.

## Data and relationship rules

- `Item` is the stable identity; `ItemRevision` contains revision-specific engineering properties.
- `AssemblyOccurrence` represents a placement under a specific parent revision. The same item can be used at multiple locations without duplicating its identity.
- Revision creation copies the latest released revision's engineering metadata and occurrence links, including exact child revision references, find numbers, quantities, and system labels.
- Released revisions are immutable through service validation and SQLite guards. Assemblies can be released only after every BOM child points to a released revision.
- Imported rows are validated and linked by their hierarchy level. A conflicting number or invalid relationship rolls back the import transaction.
- Engineering document bytes live in SQLite with their item/revision association, checksum, and audit event. Backups therefore preserve their file snapshot.

## Validation performed

- Backend workflow tests cover multilevel BOM links, reuse/quantity roll-up, cycle rejection, revision release, revision cloning, imports and rollback, comparisons/audit, ECN release gate, where-used, backup/restore, and document attachment lifecycle.
- Frontend production build checks TypeScript and bundles the complete browser UI.
- Python modules and migrations compile before delivery.

## Deferred work

- Native CAD parsing, 3D viewing, drawing markups, and automatic metadata extraction.
- Multi-user accounts, permissions, remote collaboration, and cloud hosting.
- Dedicated manufacturing/procurement/service BOM authoring and ERP integrations.
- A packaged signed installer. The current Windows launcher uses the installed Python and Node tooling to prepare and run the project.

## Local development checks

```powershell
cd backend
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

```powershell
cd frontend
npm run build
```
